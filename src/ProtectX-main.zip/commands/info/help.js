// Кнопки блять
const { Message, Client, MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");
const client = require("../../index");

// БД
const Database = require("@replit/database");
const db = new Database();

// Параметры
const Settings = require('../../files/settings.js');
const prefix = Settings.bot.prefix;

// Комманда
module.exports = {
  name: "help",
  aliases: ['h'],
  run: async (client, message, args) => {
    const button = new MessageActionRow().addComponents(
      new MessageButton()
        .setLabel("Пригласить бота.")
        .setStyle("LINK")
        .setURL(`${Settings.bot.invLink}`),
    )
    const help = new MessageEmbed()
      .setColor("GREEN")
      .setDescription(`**__:green_book: | ПОМОЩЬ__**\n\n*:star_struck: | Благодарю за использование бота! Создателю бота важен каждый сервер и крепко жмёт вам руку, а в случае чего вас обязательно тепло встретят на нашем сервер тех. поддержки.*\n\n***:shield: | Анти краш***\n> px!enable - включить анти краш защиту\n> px!disable - отключить анти краш защиту\n> px!wl - добавить в белый список пользователя (если участник в белом списке, то боту будет всё равно на его действия)\n> px!uwl - убрать пользователя из белого списка (бот снова станет реагировать на действия пользователя и выдавать за это наказания)\n> px!list - список пользователей которые в белом списке\n\n***:hammer_pick: | Модерация***\n> px!ban - забанить пользователя\n> px!kick - кикнуть пользователя\n> px!nick - удалить ник для участника (очень полезная вещь если ник пользователя содержит в себе запрещенное слово или оскорбляет кого-либо вместо ника будет установлен ID нарушителя это уникальный набор цифр который присваевается дискордом для каждого пользователя и его никак не изменить он навсегда)\n\n***:wrench: | Утилиты***\n> px!autorole - установить роль которая будет выдаваться всем новым участникам (бот начнет выдавать указаную вами роль всем новым участникам) \n> px!welcome - установить канал добро-пожаловать (бот начнет приветствовать всех новых участников)\n\n***:scroll: | Информация***\n> px!help - помощь\n> px!about - информация о боте.\n> px!ping - узнать задержку бота.`)
    // Отпрвка
    message.channel.send({ embeds: [help], components: [button] });
  },
};