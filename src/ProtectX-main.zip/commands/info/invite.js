// Кнопки блять
const { Message, Client, MessageActionRow, MessageButton } = require("discord.js");
const client = require("../../index");

const Settings = require("../../files/settings");

// Комманда сама
module.exports = {
  name: "invite",
  aliases: ['i'],
  run: async (client, message, args) => {
    const button = new MessageActionRow().addComponents(
      new MessageButton()
        .setLabel("Пригласить бота")
        .setStyle("LINK")
        .setURL(`${Settings.bot.invLink}`)
    )
    
    // Отпрвка
    message.reply({
      content: "Нажми на кнопку!)", 
      components: [button] });
  },
};