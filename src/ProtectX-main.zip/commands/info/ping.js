const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "a",
  aliases: ['p'],
  run: async (client, message, args) => {;
    const ping = new MessageEmbed()
      .setColor("GREEN")
      .setDescription(`**БЛЯТЬ!** ПОМОГИИИИИИТЕЕЕЕЕЕЕ!!! МУЧАЮТ!!!!!!!!!!!! НАСИЛУЮТ!!!!!!!!!!`)
    // отпрвка
    message.channel.send({ embeds: [ping]});
  },
};