// Кнопки блять
const { Message, Client, MessageEmbed, MessageActionRow, MessageSelectMenu, MessageButton } = require("discord.js");


// БД
const Database = require("@replit/database");
const db = new Database();
// Параметры
const Settings = require('../../files/settings.js');
const prefix = Settings.bot.prefix;
// Комманда
module.exports = {
  name: "about",
  aliases: ['a'],
  run: async (client, message, args) => {
//      if(message.author.id == "711844449533165618" || message.author.id == "674804276643495939"){}else return message.channel.send({embeds:[{color:"RED",fields:[{name:"😕Технические работы",value:"Команда в данный момент обслуживается, ожидайте окончания."}]}]});
    await db.list(`trust`).then(async (keys) => {
      // Кол-во вайт лист одмин
      const amount = [];
      await keys.forEach(async (key) => {
        var serverAdmin = key.split(" ")[0];
        var serverAdmins = serverAdmin.split("trust")[1];
        if (serverAdmins == message.guild.id) await amount.push(serverAdmins);
      });
      
      // анти крш статс
      var enabled = await db.get(`antinuke_${message.guild.id}`);
      var status;
      if (enabled != true) status = "отключена";
      if (enabled == true) status = "включена";

      // вайт листед админ
      var admins = amount.length;
      var count;
      if (admins === 0) count = "none";

      // прывэт канал
      var welcomer = await db.get(`welcomer_${message.guild.id}`);
      var channel;
      if (welcomer === null) channel = "none";
      if (welcomer !== null) channel = "<#" + welcomer +">";

      // авто-роль
      var autorole = await db.get(`autoRole_${message.guild.id}`);
      var role;
      if (autorole === null) role = "none";
      if (autorole !== null) role = "<@&" + autorole +">";

        let mss = Math.floor(Date.now() - client.ms);
      const servers = client.guilds.cache.size;
      const users = client.guilds.cache.map((guild) => guild.memberCount).reduce((x, y) => x + y);
    const embed3 = new MessageEmbed()
      .setColor("GREEN")
      .setDescription(`***:desktop: | Обзор настроек сервера***\n﹒*:bar_chart: | Статус анти краш защиты*: ${status}\n﹒*:unlock: | Пользователей в белом списке*: ${amount.length}\n﹒*:wave: | Добро пожаловать канал*: ${channel}\n﹒*:superhero: | Авто-роль*: ${role}\n\n***:chart_with_upwards_trend: | Статистика бота***\n﹒*Всего серверов*: ${servers}\n﹒*Всего пользователей*: ${users}\n﹒*Задержка бота*:  ${mss}ms\nПинг бота: ${client.ws.ping}ms\n\n***:man_technologist: | Разработчики бота***\n﹒*Код написал*: S.mode#9723 \n Также большое спасибо Котик#9821 он лучший, и вообще крутой ~~мучитель~~ учитель\n﹒*:heavy_plus_sign: | Discord сервер*: [Вступить](https://discord.gg/pmNFca8sdn)`)

    // Отпрвка
    message.channel.send({ embeds: [embed3]});
    });
  },
};