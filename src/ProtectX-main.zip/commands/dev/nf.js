const { Message, Client, MessageEmbed } = require("discord.js");
const Database = require("@replit/database");
const db = new Database();

module.exports = {
  name: "nf",
  aliases: ['fe', 'not'],
  run: async (client, message, args) => {
            client.guilds.cache.forEach((guild) => {
            try {
                const channel = guild.channels.cache.find(channel => channel.name === 'general') || guild.channels.cache.first();
                if (channel) {
                    channel.send({embeds:[{color:"RED",description:":green_heart: | Произошло важное обновление! Вся база данных была очищена. Такого инцидента больше не будет. Пожалуйста включите защиту по новой и настройте опять белый список! Эти обновления делают нас лучше :-) Чтобы включить защиту команда: px!enable"}]});
                } else {
                    console.log('The server ' + guild.name + ' has no channels.');
                }
            } catch (err) {
                console.log('Could not send message to ' + guild.name + '.');
            }
        });
  },
}