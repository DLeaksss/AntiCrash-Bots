const { Message, Client, MessageEmbed } = require("discord.js");
const Database = require("@replit/database");
const db = new Database();

module.exports = {
  name: "enable",
  aliases: ['e', 'antinuke enable'],
  run: async (client, message, args) => {
    var antinuke = await db.get(`antinuke_${message.guild.id}`);
    if (message.author.id !== message.guild.ownerId) {
      const guide = new MessageEmbed()
        .setColor("GREEN")
        .setDescription("***:shield: | АНТИ КРАШ***\n*Если анти краш включен, то ваш сервер будет в безопасности и все пользователи / боты которых нету в белом списке будут наказаны при попытке внести в него серьезные изменения.*\n\n﹒*Используйте*: px!enable *или* px!e\n﹒*эта команда доступна только для создателя сервера!*")
      message.channel.send({ embeds: [guide] });
    } else {
      if (antinuke === true) {
        message.channel.send({ content: `УПС! Анти краш уже и так был включен для этого сервера.` });
      } else {
        await db.set(`antinuke_${message.guild.id}`, true);
        await message.channel.send({ content: `УСПЕХ! Анти краш был включен. Ваш сервер в безопасности :shield:` });
      }
    }
  },
};