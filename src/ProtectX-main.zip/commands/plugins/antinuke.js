// Кнопки блять
const { Message, Client, MessageEmbed } = require("discord.js");
const client = require("../../index");

// БД
const Database = require("@replit/database");
const db = new Database();

// Параметры
const Settings = require('../../files/settings.js');
const prefix = Settings.bot.prefix;

// Комманда
module.exports = {
  name: "antinuke",
  aliases: ['an'],
  run: async (client, message, args) => {
    if (message.author.id !== message.guild.ownerId) {
      message.channel.send({
        content: "This command is for owner only."
        })
    } else {
    var status;
    const antinuke = await db.get(`antinuke_${message.guild.id}`);
    if (antinuke === true) status = "включена";
    if (antinuke !== true) status = "отключена";
    
    const guide = new MessageEmbed()
      .setColor("GREEN")
      .setDescription(`**__:shield: | АНТИ КРАШ__**\n\n*Анти кращ защита, если она включена, устанавливает строгие ограничения на выполнение действий на вашем сервере. Только администратор, который в белом списке, может выполнять действия на вашем сервере. Выполните любую команду, чтобы получить более большие знания. Это как учится вождению машины :)*\n\n***:zap: | АКТИВАЦИЯ***\n \`${prefix}antinuke enable\`\n \`${prefix}antinuke disable\`\n\n***:toolbox: | КОМАНДЫ***\n﹒*px!wl*
 *px!uwl*\n *px!list*\n\n***:bar_chart: | СТАТУС***\n﹒*Статус защиты ${status} для этого сервера.*`)

    const option = args[0];
    if (option === "enable"||
       option === "true") {
      if (antinuke === true) {
        message.channel.send({ content: "УПС! Анти краш защита уже была включена." });
      } else {
        await db.set(`antinuke_${message.guild.id}`, true);
        message.channel.send({ content: "Успех! Анти кращ защита была включена." });
      }
    } else if (option === "disable"||
       option === "false") {
      if (antinuke === false) {
        message.channel.send({ content: "УПС! Анти краш защита уже была выключена." });
      } else {
        await db.set(`antinuke_${message.guild.id}`, false);
        message.channel.send({ content: "Успех! Анти кращ защита была выключена." });
      }
    } else {
      message.channel.send({ embeds: [guide] })
      }
    }
  },
};