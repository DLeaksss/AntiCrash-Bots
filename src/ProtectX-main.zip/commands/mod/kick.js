module.exports = {
    name: "kick",
    aliases: [],
    run: async (client, message, args) => {
     if (!message.member.permissions.has("KICK_MEMBERS")) {
       message.channel.send({ content: `*${message.author.username},* Тебе нельзя :) Тебе нужны права **кикать участников**` });
     } else {
       const person = message.mentions.members.first();
       if (!person) {
         message.channel.send({ content: `*${message.author.username},* укажите участника которого хотите кикнуть.` });
       }
       if (!person.kickable) {
         message.channel.send({ content: `*${message.author.username},* Я не могу его забанить :C` });
       } else {
         var reason = args.slice(1).join(" ");
         if (!reason) reason = `кикнут пользователем ${message.author.tag}`
         person.kick({ reason: `${reason}` });
         message.channel.send({ content: `кикнут!` });
       }
     }
  },
};