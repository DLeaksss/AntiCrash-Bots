const { MessageEmbed } = require("discord.js");
const client = require('../../index');
const chalk = require("chalk");
const Database = require("@replit/database");
const db = new Database();
const { bot } = require('../../files/settings.js');
const prefix = bot.prefix;

const Settings = require('../../files/settings');
const isPrivate = Settings.options.privateMode;

client.on("guildCreate", async (guild) => {
  if (isPrivate === true) {
    let allowed = await db.get(`allowed ${guild.id}`);
    if (allowed !== true) {
      await guild.leave();
      console.log(`${chalk.cyanBright(`{!} :: Left Guild : ${guild.name}`)}\n${chalk.yellowBright(`{!} :: The Guild Was'nt Whitelisted.\n`)}`)
    }
  } else {
    console.log(`${chalk.cyanBright(`{!} :: Joined Guild : ${guild.name}`)}\n${chalk.red(`{!} :: Antinuke Isn't Enabled There.\n`)}`);
    const intro = new MessageEmbed()
      .setColor("GREEN")
      .setFooter({ text: `Префикс: ${prefix} `})
      .setDescription(`***:green_apple: | ProtectX***\n*Это лучший бот для защиты ваших серверов у нас праздник в честь полной верификации бота ^_^ наш бот теперь может находится больше чем на 100 серверов. Данный бот был создан, чтоб защитить сервера от уничтожения! IST понимает, что в мире анти крашерства сейчас довольно трудные времена поэтому надеюсь, что вам данная разработка понравится и поблагодарите разработчика бота добрым словом также не забудьте включить защиту прописав команду px!enable :green_heart: \n **Discord сервер: [Вступить](https://discord.gg/pmNFca8sdn)**`)
    
    const channel = guild.channels.cache.find(channel => 
      channel.type == "GUILD_TEXT" &&
      channel.permissionsFor(guild.me).has("SEND_MESSAGES")
      );
    if (channel) {
      channel.send({ embeds: [intro ] });
    }
  }
});