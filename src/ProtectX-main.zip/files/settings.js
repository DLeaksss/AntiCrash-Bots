module.exports = {
  bot: {
    prefix: "px!",
    token: process.env.token,
    invLink: `https://discord.com/api/oauth2/authorize?client_id=915512472457318410&permissions=8&scope=bot`
  },
  presence: {
    status: 'idle',
    activity: 'PLAYING'
  },
  options: {
    founders: ["711844449533165618"],
    privateMode: false
  },
  credits: {
    developerId: "711844449533165618",
    developer: "S.mode#9723"
  }
}