const { Client, CommandInteraction } = require("discord.js");

module.exports = {
    name: "ping",
    description: "ping",
    type: 'CHAT_INPUT',
    run: async (client, interaction, args) => {
        await interaction.followUp({ content: `Pong! \n ${client.ws.ping}ms` });
    },
};