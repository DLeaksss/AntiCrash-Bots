import os


    
class Color:
    primary = 000000
    transparent = 0x2F3136
    blurple_old = 0x7289DA
    blurple = 0x5865F2
    danger = 0xE92323
    warning = 0xE9B623
    success = 0x44E923

class Auth:
    discord_auth = {
        "debug": "OTg2NzAwNDY3NzQyNTgwNzQ2.GMehHN.fSUPoJk8XcAmKoPff_2F72R4nuVd4lDHysyT0A",
        "release": "OTg2NzAwNDY3NzQyNTgwNzQ2.GMehHN.fSUPoJk8XcAmKoPff_2F72R4nuVd4lDHysyT0A",
    }
    mongo_auth = {
        "url":"cluster0.jmevxrj.mongodb.net",
        "username":"space-protect",
        "auth":{
            "debug":"Fl23iSorAbNgwfSX",
            "release": "Fl23iSorAbNgwfSX"
        }
    }
    qiwi_auth = "9cadfa523265dc01aeb66de6fa763422"

class Other:
    shard_count = 2
    slash = None
    premium_cost = 99
    invoice_lifetime = 360 # в минутах
    p2p = None
    uptime = 0 
