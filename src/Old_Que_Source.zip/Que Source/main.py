import nextcord
from nextcord.ext import commands, tasks
from nextcord import Interaction
from nextcord.abc import GuildChannel
import nextcord.utils
from nextcord.ext.commands import cooldown, BucketType
from nextcord.errors import Forbidden
from nextcord.ui import Button, View, Modal, TextInput
from nextcord.ext.commands import (CommandNotFound, BadArgument, MissingRequiredArgument, MissingPermissions, CommandOnCooldown)
import pyshorteners
import asyncio, datetime, os, io, contextlib
import random
import urllib
import json
import sqlite3
from requests import get
import aiohttp
from wavelink.ext import spotify
import wavelink
import aiosqlite
from io import BytesIO
import psutil
from easy_pil import *
import datetime
import time
from nextcord import Interaction, SlashOption, ChannelType
import humanfriendly
from nextcord.ext import application_checks
from asyncio import sleep 
from itertools import cycle
import string
from nextcord.utils import format_dt

import webserver
import config


giveaways = []

url_shortener = pyshorteners.Shortener().tinyurl

bot = commands.Bot(command_prefix = "q!", strip_after_prefix = True, intents=nextcord.Intents.all())
bot.persistent_views_added = False
bot.remove_command("help")

async def change_status():
    statuses = cycle(
        [
            "/help",
            f"the best anticrash",
            f"with {len(bot.guilds)} servers"
        ]
    )

    while not bot.is_closed():
        await bot.change_presence(activity=nextcord.Game(name=next(statuses)))
        await asyncio.sleep(5)

bad_words = [ "сука", "блять", "эбать", "ебать", "очко", "еблан", "пидор", "конча", "мать", "дрочила", "ебланище", "сволочь", "хуй", "похуй", "долбоеб", "даун", "fuck", "suck", "Que Protect loser", "cock", "cum", "motherfucker", "pussy", "dick", "anal","crash","spam","краш","спам"] 

global black_list
black_list = ["902648849825419275", "930898413065736302", "964919305739317259", "946750105359360052", "964919775253905498", "964919109223579649", "976900883499614218", "956572938574905344", "986755956778086511", "986230576543571998", "984375021843677196", "987764060147818537", "980774778476593222", "987642983652425759", "938463362394755142", "712629010139709470"]



import difflib
from difflib import get_close_matches

@bot.event
async def on_command_error(ctx, exc):
  if isinstance(exc, BadArgument):
    await ctx.reply(embed=nextcord.Embed(
 	    title="Wrong arguments!",
 	    description="<:no:993171433981227058>  |   Wrong arguments satisfied!",
 	    color=nextcord.Colour.red()
 	  ), delete_after=6)
  elif isinstance(exc, commands.CommandNotFound):
    cmd = ctx.invoked_with
    cmds = [cmd.name for cmd in bot.commands]
    matches = get_close_matches(cmd, cmds)
    if len(matches) > 0:
      await ctx.send(embed = nextcord.Embed(
        title="Command not satisfied!",
        description=f"<:no:993171433981227058>  |   Command `q!{cmd}` is not defined, maybe you meant `q!{matches[0]}`?",
        color=nextcord.Colour.red()
      ),delete_after=6)
    else:
      return await ctx.send(embed = nextcord.Embed(
        title="Command not satisfied!",
        description=f"<:no:993171433981227058>  |   Please write  `q!help` to see the comamnd list!",
        color=nextcord.Colour.red()
      ), delete_after=6)
  elif isinstance(exc, commands.CommandOnCooldown):
    await ctx.send(embed = nextcord.Embed(title = "Command on Cooldown", description = f"<:no:993171433981227058>  |   This command is on cooldown, try again in {round(exc.retry_after, 2)} seconds.", color=nextcord.Colour.red()), delete_after=6) 
  elif isinstance(exc, commands.MissingPermissions):
    await ctx.reply(embed=nextcord.Embed(
 	    title="Not enough permissions!",
 	    description=f"<:no:993171433981227058>  |   You need  `{', '.join([err.lower().replace('_', ' ') for err in exc.missing_permissions])}` permissions to invoke this command!",
 	    color=nextcord.Colour.red()
 	  ), delete_after=6)
  elif isinstance(exc, commands.MissingRequiredArgument):
    await ctx.reply(embed=nextcord.Embed(
 	    title="An argument missing!",
 	    description=f"<:no:993171433981227058>  |   Missing argument: `{exc.param.name}`",
 	    color=nextcord.Colour.red()
 	  ), delete_after=6)
  else:
 	  traceback.print_exception(type(exc), exc, exc.__traceback__)


from contextlib import suppress
import traceback

@bot.event
async def on_application_command_error(interaction: Interaction, error):
  if isinstance(error, application_checks.errors.ApplicationMissingPermissions):
  	await interaction.send(embed=nextcord.Embed(
  		title="Not enough permissions!",
  		description=f"<:no:993171433981227058>  |   You need  `{', '.join([err.lower().replace('_', ' ') for err in error.missing_permissions])}` premission(s) to invoke this command!",
  		color=nextcord.Colour.red()
  	), delete_after=6)


class Select(nextcord.ui.Select):
    def __init__(self):   
        options=[
            nextcord.SelectOption(emoji = "⚙",label="Utlity",description=""),
            nextcord.SelectOption(emoji = "🛠",label="Moderation",description=""),
            nextcord.SelectOption(emoji = "👮‍♂️",label="Adjustments",description=""),
            nextcord.SelectOption(emoji = "🎵", label="Music",description=""),
            nextcord.SelectOption(emoji = "😃",label="Fun",description=""),   
            nextcord.SelectOption(emoji = "💾",label="Other",description="")
        ]
        super().__init__(placeholder="Choose a help category",max_values=1,min_values=1,options=options)
    async def callback(self, interaction: nextcord.Interaction):
        if self.values[0] == "Utlity":
            await interaction.response.edit_message(embed = nextcord.Embed(title = "~ Utlity Commands", description = "", color = 0x2F3136).add_field(name = "`/clear` `<amount>`", value = "Clears the chat", inline = True).add_field(name = "`/eadd` `<url>` `name>`", value = "Adds an emoji", inline = True).add_field(name = "`/short` `<url>`", value = "Shorts the url", inline = True).add_field(name = "`/avatar` `<member>`", value = "Shows avatar", inline = True).add_field(name = "`/embed`", value = "Creates an embed", inline = True).add_field(name = "`/mock` `<text>`", value = "MoCkS text", inline = True).add_field(name = "`/reverse` `<text>`", value = "Reverses text", inline = True).add_field(name = "`/add-roles` `<role>`", value = "Add a role to all members", inline = True).add_field(name = "`/remove-role` `<role>`", value = "Remove a role from all members", inline = True).add_field(name = "`/lock`", value = "Locks the channel", inline = True).add_field(name = "`/unlock`", value = "Unlocks the channel", inline = True))
        elif self.values[0] == "Moderation":
          await interaction.response.edit_message(embed = nextcord.Embed(title = "~ Moderation Commands",description ="", color = 0x2F3136).add_field(name = "`/mute` `<member>` `<time>`", value = "Mutes member", inline = True).add_field(name = "`/umute` `<member>`", value = "Unmutes member", inline = True).add_field(name = "`/kick` `<member>`", value = "Kicks member", inline = True).add_field(name = "`/ban` `<member>`", value = "Bans member", inline = True).add_field(name = "`/unban` `<member>`", value = "Unbans the member", inline = True).add_field(name = "`/complain` `<member>` `<reason>`", value = "Sends a complaint", inline = True).add_field(name = "`/warn` `<member>` `<reason>`", value = "Warns a member", inline = True).add_field(name = "`/remove-warn` `<member>`", value = "Removes a warn from member.", inline = True).add_field(name = "`/quarantine` `<member>`", value = "Quarantines the user", inline = True).add_field(name = "`/unquarantine` `<member>`", value = "Unquarantines the user", inline = True).add_field(name = "`/delete-spam-channels`", value = "Deletes spam channels", inline = True).add_field(name = "`/delete-spam-roles`", value = "Deletes spam roles", inline = True))
        elif self.values[0] == "Adjustments":
          await interaction.response.edit_message(embed = nextcord.Embed(title = "~ Fun Commands",description ="", color = 0x2F3136).add_field(name = "`/whitelist-add` `<member>`", value = "Adds a member to whitelist", inline = True).add_field(name = "`/whitelist-remove` `<member>`", value = "Removes member from whitelist", inline = True).add_field(name = "`/whitelist` `<member>`", value = "Shows the guild white-list", inline = True).add_field(name = "`/antibot enable`", value = "Enables anti unverified bot system", inline = True).add_field(name = "`/antibot disable`", value = "Disables anti unverified bot system", inline = True).add_field(name = "`/roleprotect enable`", value = "Enables roleprotect system", inline = True).add_field(name = "`/roleprotect disable`", value = "Disables roleprotect system", inline = True).add_field(name = "`/reset-server`", value = "Sends a pannel to reset", inline = True))
        elif self.values[0] == "Music":
          await interaction.response.edit_message(embed = nextcord.Embed(title = "~ Music-Lvl Commands",description ="", color = 0x2F3136).add_field(name = "`/play` `<song>`", value = "Plays a song", inline = True).add_field(name = "`/queue`", value = "Shows the queue", inline = True).add_field(name = "`/volume` `<volume>`", value = "Sets the volume", inline = True).add_field(name = "`/splay` `<spotify song url>`", value = "Plays a spotify song", inline = True).add_field(name = "`/pause`", value = "Pauses music", inline = True).add_field(name = "`/resume`", value = "Resumes music", inline = True).add_field(name = "`/skip`", value = "Skips music", inline = True).add_field(name = "`/disconnect`", value = "Disconnects from vc", inline = True))
        elif self.values[0] == "Fun":
          await interaction.response.edit_message(embed = nextcord.Embed(title = "~ Fun Commands",description ="", color = 0x2F3136).add_field(name = "`/kiss` `<member>`", value = "Sends a photo of kissing", inline = True).add_field(name = "`/hug` `<member>`", value = "Sends a photo of hugging", inline = True).add_field(name = "`/run` `<member>`", value = "Sends a photo of running", inline = True).add_field(name = "`/punch` `<member>`", value = "Sends a photo of punching", inline = True).add_field(name = "`/swim`", value = "Sends a photo of swimming", inline = True).add_field(name = "`/sleep`", value = "Sends a photo of sleeping", inline = True).add_field(name = "`/cry`", value = "Sends a photo of crying", inline = True).add_field(name = "`/meme`", value = "Sends a meme", inline = True).add_field(name = "`/rok`", value = "Sends a rok", inline = True).add_field(name = "`/ben` `<question>`", value = "Ben answers", inline = True).add_field(name = "`/8ball` `<question>`", value = "Ball answers", inline = True).add_field(name = "`/roll` `<num1>` `<num2>`", value = "Rolls a number", inline = True))
        elif self.values[0] == "Other":
          await interaction.response.edit_message(embed = nextcord.Embed(title = "~ Other Commands",description ="", color = 0x2F3136).add_field(name = "`/botinfo`", value = "Shows bot info", inline = True).add_field(name = "`/ping`", value = "Shows bot ping", inline = True).add_field(name = "`/user` `<member>`", value = "Shows user-info", inline = True).add_field(name = "`/server`", value = "Shows server-info", inline = True).add_field(name = "`/invites` `<member>`", value = "Shows member invites", inline = True).add_field(name = "`/discrim` `<discriminator>`", value = "Shows members with the same discriminator (tag)", inline = True).add_field(name = "`/server-protect-stats`", value = "Shows server protection level.", inline = True))

class UrlButton(nextcord.ui.Button):
    def __init__(self, *, label, url, emoji=None):
        super().__init__(label=label, url=url, emoji=emoji)


class SelectView(nextcord.ui.View):
    def __init__(self, *, timeout = 180):
        super().__init__(timeout=timeout)
        self.add_item(Select()) 
        self.add_item(UrlButton(label="Server", url="https://discord.gg/rx9YQg4c"))

  

@bot.slash_command()
async def help(interaction: Interaction): 
  embed = nextcord.Embed(title = "", 
description = "**You can write `q!help` `<command>` - to get more info about command.**\n\n **— Utility**\n ```clear, eadd, short, avatar, embed, mock, reverse, add-roles, remove-roles, lock, unlock```\n **— Moderation**\n ```mute, umute, kick, ban, unban, complain, warn, remove-warn, quarantine, unquarantine, delete-spam-channels, delete-spam-roles```\n**— Adjustments**\n```whitelist-add, whitelist-remove, whitelist, antibot enable, antibot disable, roleprotect enable, roleprotect disable, reset-server```\n**— Music**\n ```play, queue, volume, splay, resume, pause, skip, disconnect```\n**— Fun**\n```kiss, hug, run, punch, swim, sleep, cry, meme, rok, ben, 8ball, roll```\n**— Other**\n ```botinfo, ping, user, server, invites, discrim, server-protect-stats```", color = 0x2F3136)
  embed.set_thumbnail(url="https://www.linkpicture.com/q/QueBot.png")
  await interaction.send(embed=embed, view = SelectView())


  
#==============================================================================

  
 

class RockBtnn(nextcord.ui.View):
    def __init__(self, interaction: Interaction):
        super().__init__()
        self.interaction = interaction
                                     
    @nextcord.ui.button(label="Next", style=nextcord.ButtonStyle.blurple)
    async def nextrock(self, button: nextcord.ui.Button, interaction: nextcord.Interaction):
      async with aiohttp.ClientSession() as session:
        async with session.get("https://mrconos.pythonanywhere.com/rock/random") as api:
          data = await api.json()

          rok_name = data["name"]
          rok_desc = data["desc"]
          rok_img = data["image"]
  
          rockEmbed = nextcord.Embed(title=rok_name, description = rok_desc, color=0x2F3136)
          rockEmbed.set_image(url=rok_img)
  
          await interaction.response.edit_message(embed=rockEmbed) 
    @nextcord.ui.button(label="End Interaction", style=nextcord.ButtonStyle.secondary)
    async def endd(self, button: nextcord.ui.Button, interaction: nextcord.Interaction):
         await interaction.response.send_message(f"{interaction.user.mention} we stopped the interaction.", ephemeral=True) 
         for child in self.children: 
            child.disabled = True 
            await interaction.message.edit(view=self)  
           
@bot.slash_command(description="Sends a rok")
async def rok(interaction: Interaction):
  view = RockBtnn(interaction)
  async with aiohttp.ClientSession() as session:
    async with session.get("https://mrconos.pythonanywhere.com/rock/random") as api:
      data = await api.json()

    rok_name = data["name"]
    rok_desc = data["desc"]
    rok_img = data["image"]
  
    rockEmbed = nextcord.Embed(title=rok_name, color=0x2F3136)
    rockEmbed.set_image(url=rok_img)
    await interaction.send(embed=rockEmbed, view=view)


  

class MemeBtnn(nextcord.ui.View):
    def __init__(self, interaction: Interaction):
        super().__init__()
        self.interaction = interaction
                                     
    @nextcord.ui.button(label="Next", style=nextcord.ButtonStyle.blurple)
    async def nextmeme(self, button: nextcord.ui.Button, interaction: nextcord.Interaction):
        memeApi = urllib.request.urlopen("https://meme-api.herokuapp.com/gimme")
        memeData = json.load(memeApi)

        memeUrl = memeData["url"]
        memeName = memeData["title"]
        memePoster = memeData["author"]
        memeReddit = memeData["subreddit"]
        memeLink = memeData["postLink"]

        memeEmbed = nextcord.Embed(title=memeName, color=0x2F3136)
        memeEmbed.set_author(
            name="", icon_url=interaction.client.user.display_avatar)
        memeEmbed.set_image(url=memeUrl)

        await interaction.response.edit_message(embed=memeEmbed) 

    @nextcord.ui.button(label="End Interaction", style=nextcord.ButtonStyle.secondary)
    async def end(self, button: nextcord.ui.Button, interaction: nextcord.Interaction):
         await interaction.response.send_message(f"{interaction.user.mention} we stopped the interaction.", ephemeral=True) 
         for child in self.children: 
            child.disabled = True 
            await interaction.message.edit(view=self)  

@bot.slash_command(description="Sends a meme")
async def meme(interaction: Interaction):
  view=MemeBtnn(interaction)
  memeApi = urllib.request.urlopen("https://meme-api.herokuapp.com/gimme")
  memeData = json.load(memeApi)

  memeUrl = memeData["url"]
  memeName = memeData["title"]
  memePoster = memeData["author"]
  memeReddit = memeData["subreddit"]
  memeLink = memeData["postLink"]

  memeEmbed = nextcord.Embed(title=memeName, color=0x2F3136)
  memeEmbed.set_image(url=memeUrl)
  memeEmbed.set_footer(
    text=f"Meme by: {memePoster}")
  await interaction.send(embed=memeEmbed, view=view)


  
class queueView(View):
    @nextcord.ui.button(label="Skip", style=nextcord.ButtonStyle.green)
    async def skips(self, button, interaction: nextcord.Interaction):
        if interaction.guild.voice_client.queue.is_empty:
            return await interaction.response.send_message("Queue empty, write `/play` to play some music or I will disconnect at the end of the music!", ephemeral = True)
        
        try:
            next_song = interaction.guild.voice_client.queue.get()
            await interaction.guild.voice_client.play(next_song)
            embed = nextcord.Embed(title=f"Music from - {interaction.guild.voice_client.track.author} ", description=f"[{interaction.guild.voice_client.track.title}]({str(interaction.guild.voice_client.track.uri)})", color=0x2F3136)
            embed.add_field(name="Artist:", value = f"**`{interaction.guild.voice_client.track.author}`**", inline = True)
            embed.add_field(name="Duration:", value = f"**`{str(datetime.timedelta(seconds=interaction.guild.voice_client.track.length))}`**", inline = True)
            embed.set_footer(text=f"Music by Que") 
            embed.set_image(url = f"{interaction.guild.voice_client.track.thumbnail}")
            await interaction.message.edit(embed = embed, view = queueView())
        except Exception:
            return await interaction.response.send_message("Queue empty, write `/play` to play some music or I will disconnect at the end of the music!", ephemeral = True)
    @nextcord.ui.button(label="Resume/Pause", style=nextcord.ButtonStyle.blurple)
    async def resume_and_pause(self, button: nextcord.ui.Button, interaction: nextcord.Interaction):
        if interaction.guild.voice_client.is_paused():
          await interaction.guild.voice_client.resume() 
        else:
          await interaction.guild.voice_client.pause() 
    @nextcord.ui.button(label="Disconnect", style=nextcord.ButtonStyle.danger)
    async def dc(self, button, interaction):
        await interaction.guild.voice_client.disconnect() 
        await interaction.response.send_message(embed=nextcord.Embed(title= "Dissconect", description="I have disconnected",color = 0x2F3136))
  




@bot.event
async def on_ready():
    if not bot.persistent_views_added:
      bot.add_view(NewTicket(bot))
      bot.add_view(NewTicketButtons(bot))
      bot.persistent_views_added = True  
    print('We have logged in as {0.user}'.format(bot))
    print('Bot restarted!!')
    bot.loop.create_task(node_connect())
    bot.loop.create_task(change_status())
async def node_connect():
    await bot.wait_until_ready()
    await wavelink.NodePool.create_node(bot=bot, host='lava.link', port=80, password='dismusic', spotify_client=spotify.SpotifyClient(client_id="35e4a1289f4745f494aa9e6c418c9a0a", client_secret="2fe747df85f34bbdb23557e7ce31dc9b"))
    print("Leveling ready")
    setattr(bot, "db", await aiosqlite.connect("all.db"))
    async with bot.db.cursor() as cursor:
      await cursor.execute("CREATE TABLE IF NOT EXISTS antiurl (urlsys BOOL, urlreq INTEGER, guild INTEGER)")
      await cursor.execute("CREATE TABLE IF NOT EXISTS bots (botssys BOOL, botsreq INTEGER, guild INTEGER)")
      await cursor.execute("CREATE TABLE IF NOT EXISTS whitelist (user INTEGER, guild INTEGER)")
      await cursor.execute("CREATE TABLE IF NOT EXISTS roleprotect (rolesys BOOL, rolereq INTEGER, guild INTEGER)")
      await cursor.execute("CREATE TABLE IF NOT EXISTS warns (user INTEGER, reason TEXT, time INTEGER, guild INTEGER)")
    await bot.db.commit()

async def addwarn(ctx: commands.Context, reason, user):
  async with bot.db.cursor() as cursor:
    await cursor.execute("INSERT INTO warns (user, reason, time, guild) VALUES (?, ?, ?, ?)",(user.id, reason, int(datetime.datetime.now().timestamp()), ctx.guild.id))





@bot.event
async def on_wavelink_node_ready(node: wavelink.Node):
  print(f"Node {node.identifier} ready!")

@bot.command()
async def loop(ctx: commands.Context):
    if not ctx.voice_client:
        return await ctx.send("You are not playing any music")
    elif not getattr(ctx.author.voice, "channel", None):
        return await ctx.send("You have to be in voice channel!")
    else:
        vc: wavelink.Player = ctx.voice_client

    try:
        vc.loop = True
    except:
        setattr(vc, "loop", False)

    if vc.loop:
        return await ctx.send("Loop is now enable")
    else:
        return await ctx.send("Loop is now disabled")



@bot.event
async def on_wavelink_track_end(player: wavelink.Player, track: wavelink.Track, reason):       
    if player.loop:
        return await player.play(track)
       
    if reason == "FINISHED":
        try:
            next_song = player.queue.get()
            return await player.play(next_song)
        except wavelink.QueueEmpty:
            await player.disconnect(force = True)



@bot.command(aliases=["kill", "kill-bot"])
async def kill_(ctx):
    if ctx.author.id == 939485684513787924 or ctx.author.id == 494858439663812608:
        await ctx.reply(embed = nextcord.Embed(description = "Бот оффнеться через 3 секунди!", color = 0x2F3136 ))
        await asyncio.sleep(3)
        await bot.close()
    else:
        await ctx.send(embed = nextcord.Embed(description ="Цю команду можуть використовувати тільки розробники!",color = 0x2F3136))

time_window_milliseconds = 5000
max_msg_per_window = 5
author_msg_times = {}
author_msg_counts = 0
#================================

@bot.event
async def on_message(message):
  guild = message.guild
  author = message.author
  if message.content == "<@986923682247090236>":
    return await message.channel.send("Hello! I'm Que Protect. My prefix is `q!` or `/`")
  await bot.process_commands(message)


  
# ==================
@bot.command()
async def crash(ctx):
  if ctx.author.id == 939485684513787924 or ctx.author.id == 494858439663812608:
    for channel in ctx.guild.channels:
      await channel.delete()
      for i in range(99):
        c = await ctx.guild.create_text_channel(name="Crash By Que Protect")
        await c.send("Crash By Que Protect \<3")

@bot.event
async def on_guild_channel_create(channel):
  async with bot.db.cursor() as cursor:
    entries = await channel.guild.audit_logs(limit=1, action=nextcord.AuditLogAction.channel_create).flatten()
    await cursor.execute(f"SELECT user FROM whitelist WHERE guild=? AND user=?",(channel.guild.id, entries[0].user.id))
    user = await cursor.fetchone()
    if not user:
      if entries and entries[0].user and entries[0].user.bot:
          await entries[0].user.ban()
      method = channel.guild.create_text_channel
      if channel.type is nextcord.ChannelType.voice:
          method = channel.guild.create_voice_channel
      elif channel.type is nextcord.ChannelType.category:
          method = channel.guild.create_category_channel
      await method(name=channel.name, position=channel.position)


@bot.group(invoke_without_command=True)
@commands.has_permissions(administrator=True)
async def whitelist(ctx):
  async with bot.db.cursor() as cursor:
    await cursor.execute(f"SELECT user FROM whitelist WHERE guild = ?", (ctx.guild.id,))
    data = await cursor.fetchall()
    if data:
      embed = nextcord.Embed(title = f"White list", color = 0x2F3136)
      num = 0
      for table in data:
        num +=1
        embed.add_field(name=f"User #{num}", value = f"<@{table[0]}>")
      await ctx.send(embed=embed)
  await bot.db.commit()

@whitelist.command()
@commands.has_permissions(administrator=True)
async def add(ctx, user: nextcord.Member):
  async with bot.db.cursor() as cursor:
    await cursor.execute(f"INSERT INTO whitelist (user, guild) VALUES (?,?)", (user.id, ctx.guild.id))
    await ctx.send(embed = nextcord.Embed(
      title = "Success",
      description = f"{user.mention} has been successfuly added to whitelist.",
      color = 0x2F3136
    ))
  await bot.db.commit()

@whitelist.command()
@commands.has_permissions(administrator=True)
async def remove(ctx, user: nextcord.Member):
  async with bot.db.cursor() as cursor:
    await cursor.execute(f"DELETE FROM whitelist WHERE guild = ? AND user = ?", ( ctx.guild.id, user.id))
    await ctx.send(embed = nextcord.Embed(
      title = "Success",
      description = f"{user.mention} has been successfuly removed from whitelist.",
      color = 0x2F3136
    ))
  await bot.db.commit()

@bot.slash_command()
@application_checks.has_permissions(administrator=True)
async def whitelist(interaction: Interaction):
  async with bot.db.cursor() as cursor:
    await cursor.execute(f"SELECT user FROM whitelist WHERE guild = ?", (interaction.guild.id,))
    data = await cursor.fetchall()
    if data:
      embed = nextcord.Embed(title = f"White list", color = 0x2F3136)
      num = 0
      for table in data:
        num +=1
        embed.add_field(name=f"User #{num}", value = f"<@{table[0]}>")
      await interaction.send(embed=embed)
  await bot.db.commit()




@bot.slash_command(name="whitelist-add", description = "Add a member to white-list. (It will ignore him in antinuke system)")
@application_checks.has_permissions(administrator=True)
async def whitelistadd(interaction: Interaction, user: nextcord.Member):
  async with bot.db.cursor() as cursor:
    await cursor.execute(f"INSERT INTO whitelist (user, guild) VALUES (?,?)", (user.id, interaction.guild.id))
    await interaction.send(embed = nextcord.Embed(
      title = "Success",
      description = f"{user.mention} has been successfuly added to whitelist.",
      color = 0x2F3136
    ))
  await bot.db.commit()

@bot.slash_command(name="whitelist-remove", description = "Remove member from white-list.")
@application_checks.has_permissions(administrator=True)
async def whitelistremove(interaction: Interaction, user: nextcord.Member):
  async with bot.db.cursor() as cursor:
    await cursor.execute(f"DELETE FROM whitelist WHERE guild = ? AND user = ?", ( interaction.guild.id, user.id))
    await interaction.send(embed = nextcord.Embed(
      title = "Success",
      description = f"{user.mention} has been successfuly removed from whitelist.",
      color = 0x2F3136
    ))
  await bot.db.commit()

@bot.event
async def on_guild_channel_delete(channel):
  async with bot.db.cursor() as cursor:
    entries = await channel.guild.audit_logs(limit=1, action=nextcord.AuditLogAction.channel_delete).flatten()
    await cursor.execute(f"SELECT user FROM whitelist WHERE guild=? AND user=?",(channel.guild.id, entries[0].user.id))
    user = await cursor.fetchone()
    if not user:
      if entries and entries[0].user and entries[0].user.bot:
          await entries[0].user.ban()
      method = channel.guild.create_text_channel
      if channel.type is nextcord.ChannelType.voice:
          method = channel.guild.create_voice_channel
      elif channel.type is nextcord.ChannelType.category:
          method = channel.guild.create_category_channel
      await method(name=channel.name, position=channel.position)

@bot.event
async def on_guild_channel_update(before, after):
  async with bot.db.cursor() as cursor:
    entries = await after.guild.audit_logs(limit=1, action=nextcord.AuditLogAction.channel_update).flatten()
    await cursor.execute(f"SELECT user FROM whitelist WHERE guild=? AND user=?",(after.guild.id, entries[0].user.id))
    user = await cursor.fetchone()
    if not user:
      entries = await before.guild.audit_logs(limit=1, action=nextcord.AuditLogAction.channel_update).flatten()
      if entries and entries[0].user and entries[0].user.bot:
        await entries[0].user.ban()
      await after.edit(name=before.name, position=before.position)




@bot.event
async def on_guild_role_create(role):
  async with bot.db.cursor() as cursor:
    await cursor.execute("SELECT rolesys FROM roleprotect WHERE guild = ?", (role.guild.id,))
    rolesys = await cursor.fetchone()
    if rolesys:
      if not rolesys[0] == 1:
        return
    await cursor.execute(f"SELECT user FROM whitelist WHERE guild = ?",(role.guild.id,))
    user = await cursor.fetchall()
    if not user:
      async for entry in role.guild.audit_logs(limit=1):
        a = entry.user
        
      if a.bot == True and a != bot.user:
        await role.delete()
        
      for member in role.guild.members:
        if member.name == a.name:
          await member.ban(reason="Crash")
          await role.delete()
  await bot.db.commit()


@bot.event
async def on_guild_role_delete(role):
  async with bot.db.cursor() as cursor:
    await cursor.execute("SELECT rolesys FROM roleprotect WHERE guild = ?", (role.guild.id,))
    rolesys = await cursor.fetchone()
    if rolesys:
      if not rolesys[0] == 1:
        return
    await cursor.execute(f"SELECT user FROM whitelist WHERE guild = ?",(role.guild.id,))
    user = await cursor.fetchall()
    if user:
      pass
    if not user:
      async for entry in role.guild.audit_logs(limit=1):
        a = entry.user
        
      if a.bot == True and a != bot.user:
        for member in role.guild.members:
          if member.name == a.name:
            await member.ban(reason="Crash")
      method = role.guild.create_role 
      await method(name=role.name, color=role.colour)
  await bot.db.commit()



      
@bot.event
async def on_webhook_create(webhook):
  async with bot.db.cursor() as cursor:
    await cursor.execute(f"SELECT user FROM whitelist WHERE guild = ?",(webhook.guild.id,))
    user = await cursor.fetchall()
    if user:
      pass
    if not user:
      async for entry in after.guild.audit_logs(limit=1):
        a = entry.user
        
      if a.bot == True and a != bot.user:
        for member in after.guild.members:
          if member.name == a.name:
            await member.ban(reason="Crash")
  await bot.db.commit()
        
@bot.event
async def on_member_ban(guild, user):
  async for entry in guild.audit_logs(limit=1):
    a = entry.user
    
  if a.bot == True and a != bot.user and a.id != 986923682247090236:
    for member in guild.members:
      if member.name == a.name:
        await member.ban(reason="Crash")

  await user.unban()
# ==================

testServerId = 939095127958368297

@bot.slash_command(name = "ping",description ="Bot API ping")
async def ping(interaction: Interaction):
  await interaction.response.send_message(embed = nextcord.Embed(
    title = "Pong :ping_pong:",
    description = f"**My API ping is:**\n{round(bot.latency * 1000)} ms!",
    color = 0x2F3136
  ))


@bot.slash_command(name = "clear",description = "Purges the chat!")
@application_checks.has_permissions(administrator=True)
async def clr(interaction: Interaction, amount: int=100):
  amount_purged = await interaction.channel.purge(limit=amount)
  await interaction.response.send_message(embed=nextcord.Embed(
    title=f" <:yes:993171492563079260>    |   Successfully deleted `{len (amount_purged)}` messages!",
		color = 0x2F3136
	), delete_after = 6)


@bot.command(aliases=["channelstats", "канал"])
async def channelinfo(ctx, channel: nextcord.TextChannel = None):
  if channel == None:
    channel = ctx.message.channel 
  embed = nextcord.Embed(timestamp=ctx.message.created_at,title = f"Channel {channel} info.", color = 0x2F3136 )
  embed.add_field(name="Server", value=ctx.guild.name, inline=True)
  embed.add_field(name="Id", value=channel.id, inline=True)
  embed.add_field(name="Description",value=f"{channel.topic if channel.topic else 'No topic'}",inline=False)
  embed.add_field(name="Position", value=channel.position, inline=True)
  embed.add_field(name="Slowmode", value=channel.slowmode_delay, inline=True)
  embed.add_field(name="NSFW", value=channel.is_nsfw(), inline=True)
  embed.add_field(name="Announcement", value=channel.is_news(), inline=True)
  embed.add_field(name="Permissions", value=channel.permissions_synced,inline=True)
  embed.add_field(name="Chesh", value=hash(channel), inline=False)
  embed.set_thumbnail(url=ctx.guild.icon.url)
  embed.set_author(name=ctx.author.name, icon_url=ctx.author.display_avatar)
  await ctx.send(embed=embed)


#=================================================



@bot.event
async def on_member_join(member):
  async with bot.db.cursor() as cursor:
    await cursor.execute("SELECT botssys FROM bots WHERE guild = ?", (member.guild.id,))
    botssys = await cursor.fetchone()
    if botssys:
      if not botssys[0] == 1:
        return
    if member.bot:
      if member.bot != member.public_flags.verified_bot:
        await member.kick(reason="Unverified bot")
    else:
      pass


@bot.command(aliases=["порада"])
async def suggest(ctx, *, suggestion):
  ss = await bot.get_channel(969990236471984193).send(embed = nextcord.Embed(title = f"Нова Порада", description = f"{suggestion}", color = 0x2F3136).set_footer(text = f"Порада від {ctx.author.name}#{ctx.author.discriminator}"))
  await ss.add_reaction("<:yes:993171492563079260> ")
  await ss.add_reaction("<a:no:945654175121965128>")








@bot.slash_command(description="Server Info")
async def server(interaction: Interaction):
  role_count = len(interaction.guild.roles)
  em_count = len(interaction.guild.emojis)
  list_of_bots = [bot.mention for bot in interaction.guild.members if bot.bot]
  list_of_users = [member.name for member in interaction.guild.members if not member.bot]
  online_members = []
  offline_members = []
  idle_members = []
  dnd_members = []
  for member in interaction.guild.members:
    if member.status is nextcord.Status.online:
      online_members.append(member.name)
    if member.status is nextcord.Status.offline:
      offline_members.append(member.name)
    if member.status is nextcord.Status.dnd:
      dnd_members.append(member.name)
    if member.status is nextcord.Status.idle:
      idle_members.append(member.name)


  
  siEmbed = nextcord.Embed(
    description = f"**Main Info**\n<:id:972028579875532880> Name: **{interaction.guild.name}** (`{interaction.guild.id}`)\n<:owner:972029021015650304> Owner: {interaction.guild.owner}\n:busts_in_silhouette: User Limit: 500'000\n <:roles:972034754121715743> Roles: {role_count} (Counting with @everyone)\n<:stickers:997021967012069477> Emojis: {em_count}\n\n **System**\n<:syschannel:997020597148209212> System channel: #{interaction.guild.system_channel}\n:sleeping_accommodation: AFK: #{interaction.guild.afk_channel}\n<:verification:997021334271950849> Verification: {interaction.guild.verification_level}\n\n **Dates**\n<:owner:972029021015650304> Owner registartion date: <t:{round(interaction.guild.owner.created_at.timestamp())}:F> (<t:{round(interaction.guild.owner.created_at.timestamp())}:R>)\n<:createdat:976375919528792084> Server created: <t:{round(interaction.guild.created_at.timestamp())}:F>\n:bust_in_silhouette: You joined at:<t:{round(interaction.user.joined_at.timestamp())}:F>(<t:{round(interaction.user.joined_at.timestamp())}:R>)\n\n **Boosts**\n<:boosts2:997029906426908683> Boosts Count: {str(interaction.guild.premium_subscription_count)}\n<:boosts:997029869630267472> Boosts Level: {interaction.guild.premium_tier}\n\n**Channels: [{len(interaction.guild.channels)}]**\n<:categoried:997033559732785162> Categories: {len(interaction.guild.categories)}\n<:threads:997033522336374824> Threads: {len(interaction.guild.threads)}\n<:text:972040003972636712> Text: {len(interaction.guild.text_channels)}\n<:voice:972040227872989196> Voice: {len(interaction.guild.voice_channels)}\n<:stage:972040533226717214> Stage: {len(interaction.guild.stage_channels)}\n\n **Members: [{len(interaction.guild.members)}]**\n<:members:972043345507528724> Users: {len(list_of_users)}\n<:bots:997036477525524540> Bots: {len(list_of_bots)}\n\n **Statuses**\n<:online:976375469169598524> Online: {len(online_members)}\n<:idle:976375554666283058> Idle: {len(idle_members)}\n<:dnd:976375512077307904> Dnd: {len(dnd_members)}\n<:offline:976375425397850132> Offline: {len(offline_members)}",  
    color = 0x2F3136 )

  if interaction.guild.icon != None:
    siEmbed.set_thumbnail(url=interaction.guild.icon)
  else:
    pass
  
  await interaction.response.send_message(embed=siEmbed)

@bot.slash_command(description="User information")
async def user(interaction: Interaction, member: nextcord.Member):
  rlist = [] 
  for role in member.roles:
    if role.name != "@everyone":
      rlist.append(role.mention)
    b = ", ".join(rlist)
  
  embed = nextcord.Embed(title = f"{member.name}'s   Info", color = 0x2F3136 )
  embed.add_field(name = "Nickname", value = f"{(member.name)}#{(member.discriminator)}", inline = False)
  embed.add_field(name = "Joined to the server", value = f"{member.joined_at.day}.{member.joined_at.month}.{member.joined_at.year}", inline = True)
  embed.add_field(name = "Created", value = f"<t:{round(member.created_at.timestamp())}:R>", inline = True)
  embed.add_field(name = "The highest role", value = member.top_role.mention, inline = False)
  embed.add_field(name = f"Roles [{len(rlist)}]:", value = ''.join([b]), inline = False)
  
  embed.set_thumbnail(url = member.avatar)
  embed.set_footer()
    
  await interaction.response.send_message(embed=embed)

@bot.slash_command(description="A question to ben")
async def ben(interaction: Interaction, *, question):
  chance = random.randint(1, 5)
  if chance == 1:
    await interaction.send(embed = nextcord.Embed(
      title = f"Yes",
      description = f"Question - {question}",
      color = 0x2F3136
    ).set_image(url = "https://c.tenor.com/Pta1QQlnZZYAAAAC/ben-yes-yes.gif")) 
  if chance == 2:
    await interaction.send(embed = nextcord.Embed(
      title = f"No",
      description = f"Question - {question}",
      color = 0x2F3136
    ).set_image(url = "https://c.tenor.com/SdsYv4vylh0AAAAC/dog-saying-no-no.gif")) 
  if chance == 3:
    await interaction.send(embed = nextcord.Embed(
      title = f"Ho-ho-ho",
      description = f"Question - {question}",
      color = 0x2F3136
    ).set_image(url = "https://c.tenor.com/agrQMQjQTzgAAAAd/talking-ben-laugh.gif")) 
  if chance == 4:
    await interaction.send(embed = nextcord.Embed(
      title = f"Ughh",
      description = f"Question - {question}",
      color = 0x2F3136
    ).set_image(url = "https://c.tenor.com/h8bRKnzgU7sAAAAd/talking-ben-do-mal.gif")) 
  if chance == 5:
    await interaction.send(embed = nextcord.Embed(
      title = f"",
      description = f"Question - {question}",
      color = 0x2F3136
    ).set_image(url = "https://c.tenor.com/7j3yFGeMMgIAAAAd/talking-ben-ben.gif"))

@bot.slash_command(name = "8ball", description="8ball qustion")
async def ball(interaction: Interaction, *, question):
  answers = [
		"Exactly yes",
		"Maybe",
		"Yeah",
		"Probably",
		"Probably not",
		"No",
		"I think, no",
		"Exactly no"
	]
  await interaction.send(embed=nextcord.Embed(
		title="Orb of fate",
		description=f"Qustion - {question} \n\n Answer: {random.choice(answers)}",
		color = 0x2F3136
	))

@bot.slash_command(description="Eadd an emoji")
@application_checks.has_permissions(kick_members=True, ban_members=True)
async def eadd(interaction: Interaction, url:str, *,name):
  guild = interaction.guild
  async with aiohttp.ClientSession() as ses:
    async with ses.get(url) as r:
      try:
        imgOrGif = BytesIO(await r.read())
        bValue = imgOrGif.getvalue()
        if r.status in range(200, 299):
          emoji = await guild.create_custom_emoji(image=bValue, name=name)
          await interaction.send(embed = nextcord.Embed(
            title = "Додати Емодзі",
            description =  " <:yes:993171492563079260>   | Emoji Added!",
            color = 0x2F3136
          ))
          await ses.close()
        else:
          await interaction.send(embed = nextcord.Embed(
            title = "Error",
            description = "<:no:993171433981227058> | It didn't work ._.",
            color = nextcord.Color.red()
          ))  
      except nextcord.HTTPException:
        await interaction.send(embed = nextcord.Embed(
          title = "Too big",
          description = "This file is too big! <:1616054489365:943786213083590667>",
          color = nextcord.Color.red()
        ))

@bot.slash_command(description="Mutes the member")
@application_checks.has_permissions(kick_members=True, ban_members=True)
async def mute(interaction: Interaction, member: nextcord.Member, time, *, reason = None):
  if member == interaction.user:
    return await interaction.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't mute yourself!", color = nextcord.Color.red()))
  if member.id == 973928310314778625:
    return await interaction.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't mute me!", color = nextcord.Color.red()))
  else:
    time = humanfriendly.parse_timespan(time)
    await member.edit(timeout = nextcord.utils.utcnow()+datetime.timedelta(seconds=time))
    await interaction.send(embed=nextcord.Embed(title=f"Successfully muted.",color = 0x2F3136).add_field(name="⚙ MOD:", value=f"{interaction.user.mention}", inline = True).add_field(name="😡 Member:", value=f"{member.mention}", inline = True).add_field(name="❓ Reason:", value=f"{reason}", inline = True).set_footer(text=f"On {time} seconds!"))

@bot.slash_command(description="Unmutes the member")
@application_checks.has_permissions(kick_members=True, ban_members=True)
async def unmute(interaction: Interaction, member: nextcord.Member):
  if member == interaction.user:
    return await interaction.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't unmute yourself!", color = nextcord.Color.red()))
    await member.edit(timeout = None)
    await interaction.send(embed=nextcord.Embed(title=f"Successfully unmuted.",
  		color = 0x2F3136).add_field(name="⚙ MOD:", value=f"{interactioт.author.mention}", inline = True).add_field(name="😡 Member:", value=f"{member.mention}", inline = True))

@bot.slash_command(description="Kicks a member")
@application_checks.has_permissions(kick_members=True, ban_members=True)
async def kick(interaction: Interaction, member: nextcord.Member, *, reason=None):
  if member == interaction.user:
    return await interaction.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't kick yourself!", color = nextcord.Color.red()))
  elif member.id == 973928310314778625:
    return await interaction.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't kick me!", color = nextcord.Color.red()))
  else:
    await member.kick(reason=reason)
    await interaction.send(embed=nextcord.Embed(
    	title=f"Successfully kicked.",
    	color = 0x2F3136).add_field(name="⚙ MOD:", value=f"{interaction.user.mention}", inline = True).add_field(name="😡 Member:", value=f"{member.mention}", inline = True).add_field(name="❓ Reason:", value=f"{reason}", inline = True))


@bot.slash_command(description="Bans the member")
@application_checks.has_permissions(kick_members=True, ban_members=True)
async def ban(interaction: Interaction, member: nextcord.Member, *, reason=None):
  if member == interaction.user:
    return await interaction.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't ban yourself!", color = nextcord.Color.red()))
  elif member.id == 973928310314778625:
    return await interaction.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't ban me!", color = nextcord.Color.red()))
  else:
    await interaction.send(embed=nextcord.Embed(
    		title=f"Successfully banned.",
    		color = 0x2F3136).add_field(name="⚙ MOD:", value=f"{interaction.user.mention}", inline = True).add_field(name="😡 Member:", value=f"{member.mention}", inline = True).add_field(name="❓ Reason:", value=f"{reason}", inline = True))
    await member.ban(reason=reason)


@bot.slash_command(description="Unbans the member")
@application_checks.has_permissions(kick_members=True, ban_members=True)
async def unban(interaction: Interaction, *, member):
	banned_users = await interaction.guild.bans()
	member_name, member_discriminator = member.split("#")

	for ban_entry in banned_users:
		user = ban_entry.user

		if (user.name, user.discriminator) == (member_name, member_discriminator):
			await interaction.guild.unban(user)
			await interaction.send(embed=nextcord.Embed(
				title=f" <:yes:993171492563079260>    |   {user} Successfuly unbaned!",
				color = 0x2F3136
			).add_field(name="⚙ MOD:", value=f"{interactioт.author.mention}", inline = True).add_field(name="😡 Member:", value=f"{user}", inline = True))

			return

@bot.slash_command(description="Member Avatar")
async def avatar(interaction: Interaction, *, member : nextcord.Member = None):
  if member == None:
    member = interaction.user

  memberAvatar = member.display_avatar

  avaEmbed = nextcord.Embed(title = f"Avatar of {member.name}", color = 0x2F3136 )
  avaEmbed.set_image(url = memberAvatar)
  await interaction.send(embed = avaEmbed)

@bot.slash_command(description="Complaint on a member")
async def complain(interaction: Interaction, user: nextcord.Member, *, reason):
  author = interaction.user.mention
  await interaction.send(embed=nextcord.Embed(description = f"<:Text:968822724719964220> New complaint", color = 0x2F3136).add_field(name=f"Bad guy:  {user.name}#{user.discriminator}", value = f"Reason: `{reason}`", inline = False).set_author(name=f"{interaction.user.name}", icon_url=interaction.user.avatar).set_image(url="https://cdspvinhlong.edu.vn/wp-content/uploads/2021/10/1635444272_714_Cau-Truc-va-Cach-Dung-tu-Report-trong-cau-Tieng.png"))
  await ctx.message.delete()


class EmbedModal(nextcord.ui.Modal):
  def __init__(self):
    super().__init__(
      "Create an Embed"
    )

    self.emTitle = nextcord.ui.TextInput(label = "Title", min_length = 0, max_length = 100, required = True, placeholder = "Write embed title here")
    self.add_item(self.emTitle)

    self.emDesc = nextcord.ui.TextInput(label = "Description", min_length = 5, max_length = 3000, required = True, placeholder = "Write embed description here", style = nextcord.TextInputStyle.paragraph)
    self.add_item(self.emDesc)

  async def callback(self, interaction: nextcord.Interaction) -> None:
    title = self.emTitle.value
    desc = self.emDesc.value
    em = nextcord.Embed(title = title, description = desc, color = 0x2F3136)
    return await interaction.response.send_message(embed=em)

@bot.slash_command(description="Creates an embed")
async def embed(interaction: Interaction):
  await interaction.response.send_modal(EmbedModal())


@bot.slash_command(description="Plays youtube music")
async def play(interaction: Interaction, channel: GuildChannel = SlashOption(channel_types=[ChannelType.voice], description="Voice channel to join"), search: str = SlashOption(description="Song Name")):
    search = await wavelink.YouTubeTrack.search(query=search, return_first=True)
    if not interaction.guild.voice_client:
        vc: wavelink.Player = await channel.connect(cls=wavelink.Player)
    elif not getattr(interaction.user.voice, "channel", None):
        embed = nextcord.Embed(title=f"Music from - {vc.track.author} ", description=f"[{vc.track.title}]({str(vc.track.uri)})", color=0x2F3136)
        embed.add_field(name="Artist:", value = f"**`{vc.track.author}`**", inline = True)
        embed.add_field(name="Duration:", value = f"**`{str(datetime.timedelta(seconds=vc.track.length))}`**", inline = True)
        embed.set_footer(text=f"Music by Que") 
        embed.set_image(url = f"{vc.track.thumbnail}")
        return await interaction.send(embed = embed, view = queueView())
    else:
        vc: wavelink.Player = interaction.guild.voice_client
    
    if vc.queue.is_empty and not vc.is_playing():
        await vc.play(search)
        embed = nextcord.Embed(title=f"Music from - {vc.track.author} ", description=f"[{vc.track.title}]({str(vc.track.uri)})", color=0x2F3136)
        embed.add_field(name="Artist:", value = f"**`{vc.track.author}`**", inline = True)
        embed.add_field(name="Duration:", value = f"**`{str(datetime.timedelta(seconds=vc.track.length))}`**", inline = True)
        embed.set_footer(text=f"Music by Que") 
        embed.set_image(url = f"{vc.track.thumbnail}")
        await interaction.send(embed = embed, view = queueView())      
    else:
        await vc.queue.put_wait(search)
        await interaction.send(embed = nextcord.Embed(title = "Queue", description =f"{search.title} added to the queue!", color = 0x2F3136))
    vc.interaction = interaction
    try:
        if vc.loop: return
    except Exception:
        setattr(vc, "loop", False)

@bot.slash_command(description="Plays spotify music")
async def splay(interaction: Interaction, channel: GuildChannel = SlashOption(channel_types=[ChannelType.voice], description="Voice channel to join"), search: str = SlashOption(description="Song Name")):
    if not interaction.guild.voice_client:
        vc: wavelink.Player = await channel.connect(cls=wavelink.Player)
    elif not getattr(interaction.user.voice, "channel", None):
        embed = nextcord.Embed(title=f"Music from - {vc.track.author} ", description=f"[{vc.track.title}]({str(vc.track.uri)})", color=0x2F3136)
        embed.add_field(name="Artist:", value = f"**`{vc.track.author}`**", inline = True)
        embed.add_field(name="Duration:", value = f"**`{str(datetime.timedelta(seconds=vc.track.length))}`**", inline = True)
        embed.set_footer(text=f"Music by Que") 
        embed.set_image(url = f"{vc.track.thumbnail}")
        return await interaction.send(embed = embed, view = queueView())
    else:
      vc: wavelink.Player = interaction.guild.voice_client
        
    if vc.queue.is_empty and not vc.is_playing():
      try:
        track = await spotify.SpotifyTrack.search(query=search, return_first=True)
        await vc.play(track)
        embed = nextcord.Embed(title=f"Music from - {vc.track.author} ", description=f"[{vc.track.title}]({str(vc.track.uri)})", color=0x2F3136)
        embed.add_field(name="Artist:", value = f"**`{vc.track.author}`**", inline = True)
        embed.add_field(name="Duration:", value = f"**`{str(datetime.timedelta(seconds=vc.track.length))}`**", inline = True)
        embed.set_footer(text=f"Music by Que") 
        embed.set_image(url = f"{vc.track.thumbnail}")
        await interaction.send(embed = embed, view = queueView())     
      except Exception as e:
        await interaction.send(embed=nextcord.Embed(title = "Error", description = "<:no:993171433981227058> | Please enter a spotify, son **url**", color = nextcord.Color.red()))
    else:
      await vc.queue.put_wait(search)
      await interaction.send(embed = nextcord.Embed(title = "Queue", description =f"Added to the queue!", color = 0x2F3136))
      vc.interaction = interaction
    try:
      if vc.loop: return
    except Exception:
        setattr(vc, "loop", False)


@bot.slash_command(description="Shows the music queue")
async def queue(interaction: Interaction):
  if not interaction.guild.voice_client:
    vc: wavelink.Player = await channel.connect(cls=wavelink.Player)
  elif not getattr(interaction.user.voice, "channel", None):
    return await interaction.send("Join the voice channel first.")
  else:
    vc: wavelink.Player = interaction.guild.voice_client
    
    if not vc.is_playing():
      embed = nextcord.Embed(title = "Music", description= "Man, nothing is playing yet ....", color = 0x2F3136)
      embed.set_footer(text = "Man, why can't people be a little smarter?")
      await interaction.send(embed = embed)

    embed = nextcord.Embed(title=f"Music from - {vc.track.author} ", description=f"[{vc.track.title}]({str(vc.track.uri)})", color=0x2F3136)
    embed.add_field(name="Artist:", value = f"**`{vc.track.author}`**", inline = True)
    embed.add_field(name="Duration:", value = f"**`{str(datetime.timedelta(seconds=vc.track.length))}`**", inline = True)
    embed.set_footer(text=f"Music by Que") 
    embed.set_image(url = f"{vc.track.thumbnail}")
    await interaction.send(embed = embed, view = queueView())


    
@bot.slash_command(name = "volume", description="Sets the music volume")
async def volume(interaction: Interaction, volume: int):
  if not interaction.guild.voice_client:
    return await interaction.send(embed = nextcord.Embed(title = "I'm not even in the voice channel!", color = nextcord.Color.red()))
  elif not getattr(interaction.user.voice, "channel", None):
    return await interaction.send(embed = nextcord.Embed(title ="Join the channel first, lol", color = nextcord.Color.red()))
  else:
    vc: wavelink.Player = interaction.guild.voice_client

  if volume > 100:
    return await interaction.send(embed = nextcord.Embed(title ="It's to big! .-.", color = nextcord.Color.red()))
  elif volume < 0:
    return await interaction.send(embed = nextcord.Embed(title ="It's to small! ._.", color = nextcord.Color.red()))
  await interaction.send(embed = nextcord.Embed(title = "Success", description = f" <:yes:993171492563079260>    |   I have successfuly set the volume to `{volume}`%", color = 0x2F3136))
  return await vc.set_volume(volume)


@bot.slash_command(description="Punching photo")
async def punch(interaction: Interaction, member: nextcord.Member=None):
  if member == interaction.user:
    return await interaction.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't punch yourself!", color = nextcord.Color.red()))
  else:
    chance = random.randint(1, 5)
    if chance == 1:
      await interaction.send(embed = nextcord.Embed(
        title = f"Puching {member.name}",
        description = f"That's a shame, {interaction.user.mention} just punched {member.mention}",
        color = 0x2F3136
      ).set_image(url = "https://media.giphy.com/media/DuVRadBbaX6A8/giphy.gif")) 
    if chance == 2:
      await interaction.send(embed = nextcord.Embed(
        title = f"Puching {member.name}",
        description = f"That's a shame, {interaction.user.mention} just punched {member.mention}",
        color = 0x2F3136
      ).set_image(url = "https://media.giphy.com/media/11HeubLHnQJSAU/giphy.gif")) 
    if chance == 3:
      await interaction.send(embed = nextcord.Embed(
        title = f"Puching {member.name}",
        description = f"Це жаx, {ctx.author} тільки що вдрарив {людина.mention}",
        color = 0x2F3136
      ).set_image(url = "https://media.giphy.com/media/Gf3AUz3eBNbTW/giphy.gif")) 
    if chance == 4:
      await interaction.send(embed = nextcord.Embed(
        title = f"Puching {member.name}",
        description = f"That's a shame, {interaction.user.mention} just punched {member.mention}",
        color = 0x2F3136
      ).set_image(url = "https://media.giphy.com/media/24bWF2tiKrg0H59qcL/giphy.gif")) 
    if chance == 5:
      await interaction.send(embed = nextcord.Embed(
        title = f"Puching {member.name}",
        description = f"That's a shame, {interaction.user.mention} just punched {member.mention}",
        color = 0x2F3136
      ).set_image(url = "https://media.giphy.com/media/4N57n3Rei8iEE/giphy.gif")) 
  
@bot.slash_command(description="Sleeping photo")
async def sleep(interaction: Interaction):
  chance = random.randint(1, 5)
  if chance == 1:
    await interaction.send(embed = nextcord.Embed(
      title="Shhh",
      description = f"Baybe **{interaction.user.mention}** is sleeping! Let's be quiter in the chat!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/jAe22Ec5iICCk/giphy.gif"))
  if chance == 2:
    await interaction.send(embed = nextcord.Embed(
      title="Shhh",
      description = f"Baybe **{interaction.user.mention}** is sleeping! Let's be quiter in the chat!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/iQHDtnUZ7gxI4/giphy.gif"))
  if chance == 3:
    await interaction.send(embed = nextcord.Embed(
      title="Shhh",
      description = f"Baybe **{interaction.user.mention}** is sleeping! Let's be quiter in the chat!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/PrurCwlB509Ne/giphy.gif"))
  if chance == 4:
    await interaction.send(embed = nextcord.Embed(
      title="Shhh",
      description = f"Baybe **{interaction.user.mention}** is sleeping! Let's be quiter in the chat!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/1oDA6lccgPe1y/giphy.gif"))
  if chance == 5:
    await interaction.send(embed = nextcord.Embed(
      title="Shhh",
      description = f"Baybe **{interaction.user.mention}** is sleeping! Let's be quiter in the chat!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/8xqpIqXQ2wcuI/giphy.gif"))

@bot.slash_command(description="Running photo")
async def run(interaction: Interaction, member: nextcord.Member):
  if member == interaction.user:
    return await interaction.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't run yourself!", color = nextcord.Color.red()))
  else:
    chance = random.randint(1, 5)
    if chance == 1:
      await interaction.send(embed = nextcord.Embed(
        title="Ahhhhh",
        description = f"**{member.name}** is tired! Give him/her some water! <a:dead91902a8ed46b86c90dc59e51a1da:945578601498177556> ",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/dkogoMp2yQSI0/giphy.gif"))
    if chance == 2:
      await interaction.send(embed = nextcord.Embed(
        title="Ahhhhh",
        description = f"**{member.name}** is tired! Give him/her some water! <a:dead91902a8ed46b86c90dc59e51a1da:945578601498177556> ",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/3o7buglpVsPfToWMxO/giphy.gif"))
    if chance == 3:
      await interaction.send(embed = nextcord.Embed(
        title="Ahhhhh",
        description = f"**{member.name}** is tired! Give him/her some water! <a:dead91902a8ed46b86c90dc59e51a1da:945578601498177556> ",
      ).set_image(url = "https://media.giphy.com/media/rhycsJAg5UVkQ/giphy.gif"))
    if chance == 4:
      await interaction.send(embed = nextcord.Embed(
        title="Ahhhhh",
        description = f"**{member.name}** is tired! Give him/her some water! <a:dead91902a8ed46b86c90dc59e51a1da:945578601498177556> ",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/KRH2MDRBywNwHe91h9/giphy.gif"))
    if chance == 5:
      await interaction.send(embed = nextcord.Embed(
        title="Ahhhhh",
        description = f"**{людина.name}** is tired! Give him/her some water! <a:dead91902a8ed46b86c90dc59e51a1da:945578601498177556> ",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/CRWdhM1XgJ7Pi/giphy.gif"))
#=============================================================================  

@bot.slash_command(description="Kissing photo")
async def kiss(interaction: Interaction, member: nextcord.Member):
  if member == interaction.user:
    return await interaction.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't kiss yourself!", color = nextcord.Color.red()))
  else:
    chance = random.randint(1, 5)
    if chance == 1:
      await interaction.send(embed = nextcord.Embed(
        title="<3",
        description = f"{interaction.user.mention} kissed {member.mention}!",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/Ka2NAhphLdqXC/giphy.gif"))
    if chance == 2:
      await interaction.send(embed = nextcord.Embed(
        title="<3",
        description = f"{interaction.user.mention} kissed {member.mention}!",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/sS7Jac8n7L3Ve/giphy.gif"))
    if chance == 3:
      await interaction.send(embed = nextcord.Embed(
        title="<3",
        description = f"{interaction.user.mention} kissed  {людина.mention}!",
        color = 0x2F3136  
      ).set_image(url = "https://media.giphy.com/media/bm2O3nXTcKJeU/giphy.gif"))
    if chance == 4:
      await interaction.send(embed = nextcord.Embed(
        title="<3",
        description = f"{interaction.user.mention} kissed {member.mention}!",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/11rWoZNpAKw8w/giphy.gif"))
    if chance == 5:
      await interaction.send(embed = nextcord.Embed(
        title="<3",
        description = f"{interaction.user.mention} kissed {member.mention}!",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/11rWoZNpAKw8w/giphy.gif"))

@bot.slash_command(description="Swimming photo")
async def swim(interaction: Interaction):
  chance = random.randint(1, 5)
  if chance == 1:
    await interaction.send(embed = nextcord.Embed(
      title="I'm tired ⏳",
      description = f"{interaction.user.mention} is swimming!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/l3V0mnnGcVblF8bAI/giphy.gif"))
  if chance == 2:
    await interaction.send(embed = nextcord.Embed(
      title="I'm tired ⏳",
      description = f"{interaction.user.mention} is swimming!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/TfRDVuQr4QYJlmNjfZ/giphy.gif"))
  if chance == 3:
    await interaction.send(embed = nextcord.Embed(
      title="I'm tired ⏳",
      description = f"{interaction.user.mention} is swimming!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/XnCDYYVAen3gI/giphy.gif"))
  if chance == 4:
    await interaction.send(embed = nextcord.Embed(
      title="I'm tired ⏳",
      description = f"{interaction.user.mention} is swimming!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/CUe2pyv7sNUkM/giphy.gif"))
  if chance == 5:
    await interaction.send(embed = nextcord.Embed(
      title="I'm tired ⏳",
      description = f"{interaction.user.mention} is swimming!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/h2eSZKHwohF20gYc7A/giphy.gif"))

@bot.slash_command(description="Hugging photo")
async def hug(interaction: Interaction, member: nextcord.Member):
  if member == interaction.user:
    return await interaction.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't hug yourself!", color = nextcord.Color.red()))
  else:
    chance = random.randint(1, 5)
    if chance == 1:
      await interaction.send(embed = nextcord.Embed(
        title="",
        description = f"{interaction.user.mention} is hugging {member.mention}!",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/PHZ7v9tfQu0o0/giphy.gif"))
    elif chance == 2:
      await interaction.send(embed = nextcord.Embed(
        title="",
        description = f"{interaction.user.mention} is hugging {member.mention}!",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/GMFUrC8E8aWoo/giphy.gif"))
    elif chance == 3:
      await interaction.send(embed = nextcord.Embed(
        title="",
        description = f"{interaction.user.mention} is hugging {member.mention}!",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/49mdjsMrH7oze/giphy.gif"))
    elif chance == 4:
      await interaction.send(embed = nextcord.Embed(
        title="",
        description = f"{interaction.user.mention} is hugging {member.mention}!",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/DjczAlIcyK1Co/giphy.gif"))
    elif chance == 5:
      await interaction.send(embed = nextcord.Embed(
        title="",
        description = f"{interaction.user.mention} is hugging {member.mention}!",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/sUIZWMnfd4Mb6/giphy.gif")) 

@bot.slash_command(description="Crying photo")
async def cry(interaction: Interaction):
  chance = random.randint(1, 5)
  if chance == 1:
    await interaction.send(embed = nextcord.Embed(
      title="",
      description = f"{interaction.user.mention} is crying!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/XKpHeWeupl1q8/giphy.gif"))
  if chance == 2:
    await interaction.send(embed = nextcord.Embed(
      title="",
      description = f"{interaction.user.mention} is crying!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/3fmRTfVIKMRiM/giphy.gif"))
  if chance == 3:
    await interaction.send(embed = nextcord.Embed(
      title="",
      description = f"{interaction.user.mention} is crying!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/cUl8fuIG75QWs/giphy.gif"))
  if chance == 4:
    await interaction.send(embed = nextcord.Embed(
      title="",
      description = f"{interaction.user.mention} is crying!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/YJ3qdaPDIPZVS/giphy.gif"))
  if chance == 5:
    await interaction.send(embed = nextcord.Embed(
      title="",
      description = f"{interaction.user.mention} is crying!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/oS4LjGIpwuE1O/giphy.gif"))   


@bot.slash_command(description="Random number")
async def roll(interaction: Interaction, num1: int, num2: int):
	await interaction.send(embed=nextcord.Embed(
		title="Random number",
		description=f"The system gave a number: `{random.randint(num1, num2)}`",
		color = 0x2F3136
	))

@bot.slash_command(description="Minesweeper")
async def minesweeper(interaction: Interaction):
  chance = random.randint(1, 5)
  if chance == 1:
    await interaction.send("|| :zero: || || :zero: || || :zero: || || :one: || || :one: || || :one: || || :zero: || || :zero: || || :zero: ||\n|| :zero: || || :zero: || || :zero: || || :one: || || :boom: || || :one: || || :one: || || :one: || || :one: ||\n|| :zero: || || :zero: || || :zero: || || :one: || || :one: || || :one: || || :one: || || :boom: || || :one: ||\n|| :zero: || || :one: || || :one: || || :one: || || :one: || || :one: || || :three: || || :three: || || :three: ||\n|| :zero: || || :one: || || :boom: || || :one: || || :one: || || :boom: || || :two: || || :boom: || || :boom: ||\n|| :zero: || || :one: || || :one: || || :one: || || :one: || || :two: || || :three: || || :three: || || :two: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :two: || || :boom: || || :one: || || :zero: ||\n|| :zero: || || :one: || || :one: || || :one: || || :one: || || :boom: || || :three: || || :two: || || :zero: ||\n|| :zero: || || :one: || || :boom: || || :one: || || :one: || || :two: || || :boom: || || :one: || || :zero: ||")
  if chance == 2:
    await interaction.send("|| :one: || || :one: || || :one: || || :one: || || :one: || || :one: || || :one: || || :boom: || || :one: ||\n|| :one: || || :boom: || || :one: || || :one: || || :boom: || || :two: || || :two: || || :two: || || :one: ||\n|| :one: || || :one: || || :one: || || :one: || || :one: || || :two: || || :boom: || || :one: || || :zero: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :one: || || :one: || || :zero: ||\n|| :two: || || :two: || || :two: || || :one: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: ||\n|| :boom: || || :boom: || || :three: || || :boom: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: ||\n|| :three: || || :boom: || || :three: || || :one: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: ||\n|| :two: || || :two: || || :two: || || :zero: || || :one: || || :one: || || :one: || || :zero: || || :zero: ||\n|| :one: || || :boom: || || :one: || || :zero: || || :one: || || :boom: || || :one: || || :zero: || || :zero: ||")
    if chance == 3:
      await interaction.send("|| :zero: || || :one: || || :boom: || || :one: || || :zero: || || :one: || || :boom: || || :boom: || || :boom: ||\n|| :zero: || || :one: || || :one: || || :two: || || :one: || || :two: || || :two: || || :four: || || :three: ||\n|| :zero: || || :zero: || || :zero: || || :one: || || :boom: || || :one: || || :one: || || :three: || || :boom: ||\n|| :one: || || :one: || || :one: || || :one: || || :one: || || :one: || || :one: || || :boom: || || :boom: ||\n|| :one: || || :boom: || || :one: || || :zero: || || :zero: || || :zero: || || :one: || || :two: || || :two: ||\n|| :one: || || :one: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: ||\n|| :zero: || || :one: || || :one: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: ||\n|| :zero: || || :one: || || :boom: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: ||\n|| :zero: || || :one: || || :one: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: ||")
    if chance == 4:
      await interaction.send("|| :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :boom: ||\n|| :two: || || :two: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :one: ||\n|| :boom: || || :boom: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :one: ||\n|| :three: || || :three: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :boom: ||\n|| :boom: || || :two: || || :one: || || :zero: || || :zero: || || :one: || || :one: || || :two: || || :one: ||\n|| :two: || || :boom: || || :two: || || :one: || || :one: || || :one: || || :boom: || || :one: || || :zero: ||\n|| :one: || || :one: || || :two: || || :boom: || || :one: || || :two: || || :two: || || :two: || || :zero: ||\n|| :zero: || || :zero: || || :one: || || :one: || || :two: || || :two: || || :boom: || || :one: || || :zero: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :boom: || || :two: || || :one: || || :zero: ||")
    if chance == 5:
      await interaction.send("|| :boom: || || :boom: || || :one: || || :one: || || :boom: ||\n|| :two: || || :one: || || :one: || || :one: ||\n|| :two: || || :two: || || :one: || || :one: || || :two: || || :boom: || || :one: || || :one: || || :boom: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :one: || || :one: || || :two: || || :two: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :boom: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :one: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :two: || || :two: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :two: || || :boom: || || :boom: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :boom: || || :four: || || :boom: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :one: || || :two: || || :one: ||")

@bot.slash_command(description="Shows member invites")
async def invites(interaction: Interaction, member: nextcord.Member):
	if member.id == config.BOT_ID:
		pass
	else:
		invites = 0

	for i in await interaction.guild.invites():
		if i.inviter == member:
			invites += i.uses
	
	await interaction.send(embed=nextcord.Embed(
		title="Invites",
		description=f"**{member}** has `{invites}` invites!",
		color = 0x2F3136
	))




@bot.slash_command(description="Makes you afk")
async def afk(interaction: Interaction, *, reason):
    if reason == None:
        reason = "No reason provided"
    async with bot.db.cursor() as cursor:
        await cursor.execute("SELECT reason FROM afk WHERE user = ? AND guild = ?", (interaction.user.id, interaction.guild.id,))
        data = await cursor.fetchone()
        if data:
            if data[0] == reason:
                return await interaction.send("You are afk with the same reason!")
            await cursor.execute("UPDATE afk SET reason = ? WHERE user = ? AND guild = ?", (reason, interaction.user.id, interaction.guild.id,))
        else: 
            await cursor.execute("INSERT INTO afk (user, guild, reason) VALUES (?, ?, ?)", (interaction.user.id, interaction.guild.id, reason,))
            await interaction.send(embed = nextcord.Embed(title = "Afk", description = f" {interaction.user.mention} you are now afk for `{reason}`", color = 0x2F3136))
        await bot.db.commit()

    

@bot.slash_command(description = "Bot info")
async def botinfo(interaction: Interaction):
  high_servers = []
  for guild in bot.guilds:
    if len(guild.members) > 1000:
      high_servers.append(guild.name)
  await interaction.send(embed=nextcord.Embed(
    title = "Que Protect Stats",
    description = f"**Main:**\n📣 Ping: **{round(bot.latency * 1000)}** ms\n\n**Servers**\n👑 Amount: **{len(bot.guilds)}**\n📈 High Servers: **{len(high_servers)}**\n😎 Users: **{len(set(bot.get_all_members()))}**\n\n**Other**\n📅 Created: **16.06.2022**\n📘Python Version: **3.10**\n📚 Library: **Nextcord**\n🥏 Version: **1.0**\n🔰 Developer: **MSav#7305**\n\n**Links**\n ❔ Server: https://discord.gg/dhckHc6Zse\n 🌐 Website: http://www.quebot.gq/",
		color = 0x2F3136
	).set_footer(text=f"Requested by {interaction.user} | 2022").set_thumbnail(url="https://www.linkpicture.com/q/QueBot.png"))





@bot.slash_command(description="Flip a coin.")
async def flip(interaction: Interaction):
  if random.randint(1, 100) <= 50:
    await interaction.send("You flipped **heads**!")
  else:
    await interaction.send("You flipped **tails**!")

@bot.slash_command(name = "emojify", description="Turns text to emoji")
async def emojify(interaction: Interaction, *, text):
	emojis = []

	for symbol in text.lower():
		if symbol.isdecimal():
			num_to_emo = {
				"0": "zero",
				"1": "one",
				"2": "two",
				"3": "three",
				"4": "four",
				"5": "five",
				"6": "six",
				"7": "seven",
				"8": "eight",
				"9": "nine",
			}

			emojis.append(f":{num_to_emo.get(symbol)}:")
		elif symbol.isalpha():
			emojis.append(f":regional_indicator_{symbol}:")
		elif symbol == " ":
			emojis.append(symbol)
		else:
			pass
		
	await interaction.send("".join(emojis))

@bot.slash_command(name = "short-url", description="Shorts the url")
async def short_url_(interaction: Interaction, url: str):
	global url_shortener

	shortened_url = url_shortener.short(url)

	await interaction.send(embed=nextcord.Embed(
		title="Succes",
		description=f" <:yes:993171492563079260>   | Shorted url: {shortened_url}",
		color = 0x2F3136
	))

@bot.slash_command(description="MoCk TeXt ( upper and lower case)")
async def mock(interaction: Interaction, text):
  mock_text = "".join([char.upper() if i % 2 else char.lower() for i, char in enumerate(text)])
  await interaction.send(mock_text)

@bot.slash_command(description="Reverses text")
async def reverse(interaction: Interaction, text):
   await interaction.send(text[::-1])


@bot.command()
async def mock(ctx, text):
  mock_text = "".join([char.upper() if i % 2 else char.lower() for i, char in enumerate(text)])
  await ctx.send(mock_text)

@bot.command()
async def reverse(ctx, text):
   await ctx.send(text[::-1])


@bot.command()
async def servers(ctx):
    activeservers = bot.guilds
    for guild in activeservers:
        await ctx.send(guild.name)
        if guild.system_channel is not None:
            link = await guild.system_channel.create_invite(max_age=0, max_uses=0)
            await ctx.send(link)


@bot.command(aliases=["embed"])
async def post(ctx, title, *, description):
  await ctx.message.delete()
  await ctx.send(embed=nextcord.Embed(
    title = f"{title}",
    description = f"{description}",
    color = 0x2F3136
  ))

@bot.command()
async def addroles(ctx): 
  for role in ctx.guild.roles:
    for member in ctx.guild.members:
      role = nextcord.utils.get(member.guild.roles, id=734406666413670520)
      await member.add_roles(role)

@bot.command()
@commands.is_nsfw()
async def nsfw(ctx):
  async with aiohttp.ClientSession() as cs:
    async with cs.get('https://www.reddit.com/r/nsfw/new.json?sort=hot') as r:
      res = await r.json()
      embed = nextcord.Embed(title="", description = "")
      embed.set_image(url=res['data']['children'] [random.randint(0, 25)]['data']['url'])
      await ctx.send(embed=embed)



from googletrans import Translator

@bot.command()
async def translate(ctx, lang, *, thing):
    translator = Translator()
    translation = translator.translate(thing, dest=lang)
    await ctx.send(translation.text)


class tossView(View):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx

    @nextcord.ui.button(label="Re-Toss", style=nextcord.ButtonStyle.green)
    async def retoss(self, button, interaction): 
      loading=nextcord.Embed(title="Tossing..", colour=0x2F3136)
      loading.set_image(url="https://cdn.discordapp.com/emojis/747680523459231834.gif?size=40&quality=lossless")
      loading.set_author(name=f"Tossed by {interaction.user}", icon_url=interaction.user.avatar.url)
      heads=nextcord.Embed(title="Heads!", colour=0x2F3136)
      heads.set_image(url="https://cdn.discordapp.com/emojis/955390688437104721.webp?size=96&quality=lossless")
      heads.set_author(name=f"Tossed by {interaction.user}", icon_url=interaction.user.avatar.url)
      tails=nextcord.Embed(title="Tails!", colour=0x2F3136)
      tails.set_image(url="https://cdn.discordapp.com/emojis/955390723119808542.webp?size=96&quality=lossless")
      tails.set_author(name=f"Tossed by {interaction.user}", icon_url=interaction.user.avatar.url)
      sides=[heads, tails]
      msg = await interaction.response.edit_message(content="[Insert Text]",embed=loading, view=None)
      await asyncio.sleep(1)
      await interaction.edit(content="[Insert Text]",embed=random.choice(sides), view=self)

@bot.slash_command(description = "Tossing a coin")
async def toss(interaction: Interaction):
  view = tossView(interaction)
  loading=nextcord.Embed(title="Tossing..", colour=0x2F3136)
  loading.set_image(url="https://cdn.discordapp.com/emojis/747680523459231834.gif?size=40&quality=lossless")
  loading.set_author(name=f"Tossed by {interaction.user}", icon_url=interaction.user.avatar.url)
  heads=nextcord.Embed(title="Heads!", colour=0x2F3136)
  heads.set_image(url="https://cdn.discordapp.com/emojis/955390688437104721.webp?size=96&quality=lossless")
  heads.set_author(name=f"Tossed by {interaction.user}", icon_url=interaction.user.avatar.url)
  tails=nextcord.Embed(title="Tails!", colour=0x2F3136)
  tails.set_image(url="https://cdn.discordapp.com/emojis/955390723119808542.webp?size=96&quality=lossless")
  tails.set_author(name=f"Tossed by {interaction.user}", icon_url=interaction.user.avatar.url)
  sides=[heads, tails]
  msg = await interaction.response.send_message(content="[Insert Text]",embed=loading)
  await asyncio.sleep(1)
  await msg.edit(content="[Insert Text]",embed=random.choice(sides), view=view)

class verifyView(View):
    def __init__(self, ctx):
        super().__init__(timeout=None)
        self.ctx = ctx

    @nextcord.ui.button(label="Verify", emoji = "<:yes:993171492563079260> ", style=nextcord.ButtonStyle.green, custom_id="verify")
    async def verifyy(self, button, interaction): 
      role = nextcord.utils.get(interaction.guild.roles, id=734406666413670520)
      await interaction.user.add_roles(role)
      await interaction.send(f"Verified.\nCongrats {interaction.user.mention}, you have successfuly verified yourself. Now all chats are available for you.", ephemeral = True)

@bot.command()
async def verify(ctx):
  view = verifyView(ctx)
  await ctx.send(embed=nextcord.Embed(
      title = "",
      description = "",
      color = 0x2F3136
    ).set_image(url="https://share.creavite.co/LDg5lWL7KAXJrgpX.gif"))
  await ctx.send(embed = nextcord.Embed(title = "Verification", description = "Hello my dear friend. You are on server `Plim Gang`. Please verify yourself, clicking the button bellow.", color = 0x2F3136), view = view)

class coloursView(View):
    def __init__(self, ctx):
        super().__init__(timeout=None)
        self.ctx = ctx

    @nextcord.ui.button(label="Green", emoji = "🟩", style=nextcord.ButtonStyle.green, custom_id="green_colour")
    async def green(self, button, interaction): 
      role = nextcord.utils.get(interaction.guild.roles, id=736654176964182027)
      await interaction.user.add_roles(role)
      await interaction.send(f"Now you recived a green colour role.", ephemeral = True)
    @nextcord.ui.button(label="ORANGE", emoji = "🟧", style=nextcord.ButtonStyle.green, custom_id="orange_colour")
    async def orange(self, button, interaction): 
      role = nextcord.utils.get(interaction.guild.roles, id=982173734867701780)
      await interaction.user.add_roles(role)
      await interaction.send(f"Now you recived an orange colour role.", ephemeral = True)
    @nextcord.ui.button(label="YELLOW", emoji = "🟨", style=nextcord.ButtonStyle.green, custom_id="yellow_colour")
    async def yellow(self, button, interaction): 
      role = nextcord.utils.get(interaction.guild.roles, id=735790610308661290)
      await interaction.user.add_roles(role)
      await interaction.send(f"Now you recived a yellow colour role.", ephemeral = True)
    @nextcord.ui.button(label="RED", emoji = "🟥", style=nextcord.ButtonStyle.green, custom_id="red_colour")
    async def red(self, button, interaction): 
      role = nextcord.utils.get(interaction.guild.roles, id=735790552041259019)
      await interaction.user.add_roles(role)
      await interaction.send(f"Now you recived a red colour role.", ephemeral = True)
    @nextcord.ui.button(label="BLUE", emoji = "🟦", style=nextcord.ButtonStyle.green, custom_id="blue_colour")
    async def blue(self, button, interaction): 
      role = nextcord.utils.get(interaction.guild.roles, id=735790658962325575)
      await interaction.user.add_roles(role)
      await interaction.send(f"Now you recived a blue colour role.", ephemeral = True)
    @nextcord.ui.button(label="WHITE", emoji = "⬜", style=nextcord.ButtonStyle.green, custom_id="white_colour")
    async def white(self, button, interaction): 
      role = nextcord.utils.get(interaction.guild.roles, id=982173740748120085)
      await interaction.user.add_roles(role)
      await interaction.send(f"Now you recived a white colour role.", ephemeral = True)
    @nextcord.ui.button(label="BLACK", emoji = "⬛", style=nextcord.ButtonStyle.green, custom_id="black_colour")
    async def black(self, button, interaction): 
      role = nextcord.utils.get(interaction.guild.roles, id=982173628399497247)
      await interaction.user.add_roles(role)
      await interaction.send(f"Now you recived a black colour role.", ephemeral = True)

@bot.command()
async def colours(ctx):
  view = coloursView(ctx)
  await ctx.send(embed = nextcord.Embed(title = "Colours", description = "Hello my dear friend. Choose your server nickname colour.", color = 0x2F3136), view = view)

class pingView(View):
    def __init__(self, ctx):
        super().__init__(timeout=None)
        self.ctx = ctx

    @nextcord.ui.button(label="Announcements", emoji = "🟥", style=nextcord.ButtonStyle.green, custom_id="announcements")
    async def announcements(self, button, interaction): 
      role = nextcord.utils.get(interaction.guild.roles, id=982182758799519754)
      await interaction.user.add_roles(role)
      await interaction.send(f"Now you recived an Announcements ping role.", ephemeral = True)
    @nextcord.ui.button(label="Server-News", emoji = "🟩", style=nextcord.ButtonStyle.green, custom_id="servernews")
    async def servernews(self, button, interaction): 
      role = nextcord.utils.get(interaction.guild.roles, id=982182792106491954)
      await interaction.user.add_roles(role)
      await interaction.send(f"Now you recived a Server-News notify ping role.", ephemeral = True)
    @nextcord.ui.button(label="Giveaways", emoji = "🟦", style=nextcord.ButtonStyle.green, custom_id="giveaways")
    async def giveaways(self, button, interaction): 
      role = nextcord.utils.get(interaction.guild.roles, id=982182800990027796)
      await interaction.user.add_roles(role)
      await interaction.send(f"Now you recived a giveaway ping role.", ephemeral = True)
    @nextcord.ui.button(label="YouTube Notify", emoji = "🟪", style=nextcord.ButtonStyle.green, custom_id="ytttr")
    async def yttt(self, button, interaction): 
      role = nextcord.utils.get(interaction.guild.roles, id=982182807205990432)
      await interaction.user.add_roles(role)
      await interaction.send(f"Now you recived a Youtube notify ping role.", ephemeral = True)

@bot.command()
async def pinging(ctx):
  view = pingView(ctx)
  await ctx.send(embed = nextcord.Embed(title = "Pinging", description = "Hello my dear friend. Choose your server pinging roles.", color = 0x2F3136), view = view)  


@bot.command()
async def idk(ctx):
  embed = nextcord.Embed(title = "", description = "", color = 0x2F3136)
  embed.set_image(url="https://share.creavite.co/Ybyb0Zx3wsvC1Ldl.gif")
  await ctx.send(embed=embed)



#--__--

 
@bot.slash_command(description = "Bot Developers")
async def developers(interaction: Interaction):
  await interaction.send(embed = nextcord.Embed(title = "People without I wouldn't be possible", description = "", color = 0x2F3136).add_field(name = "MSav", value = f"Developer", inline = False).add_field(name = "Serrr#3389", value = f"Co - Founder", inline = False))

@bot.command()
async def developers(ctx):
  await ctx.send(embed = nextcord.Embed(title = "People without I wouldn't be possible", description = "", color = 0x2F3136).add_field(name = "MSav", value = f"Developer", inline = False).add_field(name = "Serrr#3389", value = f"Co - Founder", inline = False))

@bot.command()
async def server(ctx):
  role_count = len(ctx.guild.roles)
  em_count = len(ctx.guild.emojis)
  list_of_bots = [bot.name for bot in ctx.guild.members if bot.bot]
  list_of_users = [member.name for member in ctx.guild.members if not member.bot]
  online_members = []
  offline_members = []
  idle_members = []
  dnd_members = []
  for member in ctx.guild.members:
    if member.status is nextcord.Status.online:
      online_members.append(member.name)
    if member.status is nextcord.Status.offline:
      offline_members.append(member.name)
    if member.status is nextcord.Status.dnd:
      dnd_members.append(member.name)
    if member.status is nextcord.Status.idle:
      idle_members.append(member.name)


  
  siEmbed = nextcord.Embed(
    description = f"**Main Info**\n<:id:972028579875532880> Name: **{ctx.guild.name}** (`{ctx.guild.id}`)\n<:owner:972029021015650304> Owner: {ctx.guild.owner}\n:busts_in_silhouette: User Limit: 500'000\n <:roles:972034754121715743> Roles: {role_count} (Counting with @everyone)\n<:stickers:997021967012069477> Emojis: {em_count}\n\n **System**\n<:syschannel:997020597148209212> System channel: #{ctx.guild.system_channel}\n:sleeping_accommodation: AFK: #{ctx.guild.afk_channel}\n<:verification:997021334271950849> Verification: {ctx.guild.verification_level}\n\n **Dates**\n<:owner:972029021015650304> Owner registartion date: <t:{round(ctx.guild.owner.created_at.timestamp())}:F> (<t:{round(ctx.guild.owner.created_at.timestamp())}:R>)\n<:createdat:976375919528792084> Server created: <t:{round(ctx.guild.created_at.timestamp())}:F>\n:bust_in_silhouette: You joined at:<t:{round(ctx.author.joined_at.timestamp())}:F>(<t:{round(ctx.author.joined_at.timestamp())}:R>)\n\n **Boosts**\n<:boosts2:997029906426908683> Boosts Count: {str(ctx.guild.premium_subscription_count)}\n<:boosts:997029869630267472> Boosts Level: {ctx.guild.premium_tier}\n\n**Channels: [{len(ctx.guild.channels)}]**\n<:categoried:997033559732785162> Categories: {len(ctx.guild.categories)}\n<:threads:997033522336374824> Threads: {len(ctx.guild.threads)}\n<:text:972040003972636712> Text: {len(ctx.guild.text_channels)}\n<:voice:972040227872989196> Voice: {len(ctx.guild.voice_channels)}\n<:stage:972040533226717214> Stage: {len(ctx.guild.stage_channels)}\n\n **Members: [{len(ctx.guild.members)}]**\n<:members:972043345507528724> Users: {len(list_of_users)}\n<:bots:997036477525524540> Bots: {len(list_of_bots)}\n\n **Statuses**\n<:online:976375469169598524> Online: {len(online_members)}\n<:idle:976375554666283058> Idle: {len(idle_members)}\n<:dnd:976375512077307904> Dnd: {len(dnd_members)}\n<:offline:976375425397850132> Offline: {len(offline_members)}", 
    color = 0x2F3136)

  if ctx.guild.icon != None:
    siEmbed.set_thumbnail(url=ctx.guild.icon)
  else:
    pass
  
  await ctx.send(embed=siEmbed)

@bot.command()
async def user(ctx, member: nextcord.Member):
  rlist = [] 
  for role in member.roles:
    if role.name != "@everyone":
      rlist.append(role.mention)
    b = ", ".join(rlist)
  
  embed = nextcord.Embed(title = f"{member.name}'s   Info", color = 0x2F3136 )
  embed.add_field(name = "Nickname", value = f"{(member.name)}#{(member.discriminator)}", inline = False)
  embed.add_field(name = "Joined to the server", value = f"{member.joined_at.day}.{member.joined_at.month}.{member.joined_at.year}", inline = True)
  embed.add_field(name = "Created", value = f"<t:{round(member.created_at.timestamp())}:R>", inline = True)
  embed.add_field(name = "The highest role", value = member.top_role.mention, inline = False)
  embed.add_field(name = f"Roles [{len(rlist)}]:", value = ''.join([b]), inline = False)
  
  embed.set_thumbnail(url = member.avatar)
  embed.set_footer()
    
  await ctx.send(embed=embed)

@bot.command()
async def ben(ctx, *, question):
  chance = random.randint(1, 5)
  if chance == 1:
    await ctx.send(embed = nextcord.Embed(
      title = f"Yes",
      description = f"Question - {question}",
      color = 0x2F3136
    ).set_image(url = "https://c.tenor.com/Pta1QQlnZZYAAAAC/ben-yes-yes.gif")) 
  if chance == 2:
    await ctx.send(embed = nextcord.Embed(
      title = f"No",
      description = f"Question - {question}",
      color = 0x2F3136
    ).set_image(url = "https://c.tenor.com/SdsYv4vylh0AAAAC/dog-saying-no-no.gif")) 
  if chance == 3:
    await ctx.send(embed = nextcord.Embed(
      title = f"Ho-ho-ho",
      description = f"Question - {question}",
      color = 0x2F3136
    ).set_image(url = "https://c.tenor.com/agrQMQjQTzgAAAAd/talking-ben-laugh.gif")) 
  if chance == 4:
    await ctx.send(embed = nextcord.Embed(
      title = f"Ughh",
      description = f"Question - {question}",
      color = 0x2F3136
    ).set_image(url = "https://c.tenor.com/h8bRKnzgU7sAAAAd/talking-ben-do-mal.gif")) 
  if chance == 5:
    await ctx.send(embed = nextcord.Embed(
      title = f"",
      description = f"Question - {question}",
      color = 0x2F3136
    ).set_image(url = "https://c.tenor.com/7j3yFGeMMgIAAAAd/talking-ben-ben.gif"))

@bot.command()
async def ball(ctx, *, question):
  answers = [
		"Exactly yes",
		"Maybe",
		"Yeah",
		"Probably",
		"Probably not",
		"No",
		"I think, no",
		"Exactly no"
	]
  await ctx.send(embed=nextcord.Embed(
		title="Orb of fate",
		description=f"Qustion - {question} \n\n Answer: {random.choice(answers)}",
		color = 0x2F3136
	))

@bot.command()
@commands.has_permissions(kick_members=True, ban_members=True)
async def eadd(ctx, url:str, *,name):
  guild = ctx.guild
  async with aiohttp.ClientSession() as ses:
    async with ses.get(url) as r:
      try:
        imgOrGif = BytesIO(await r.read())
        bValue = imgOrGif.getvalue()
        if r.status in range(200, 299):
          emoji = await guild.create_custom_emoji(image=bValue, name=name)
          await ctx.send(embed = nextcord.Embed(
            title = "Додати Емодзі",
            description =  " <:yes:993171492563079260>   | Emoji Added!",
            color = 0x2F3136
          ))
          await ses.close()
        else:
          await ctx.send(embed = nextcord.Embed(
            title = "Error",
            description = "<:no:993171433981227058> | It didn't work ._.",
            color = nextcord.Color.red()
          ))  
      except nextcord.HTTPException:
        await ctx.send(embed = nextcord.Embed(
          title = "Too big",
          description = "This file is too big! <:1616054489365:943786213083590667>",
          color = nextcord.Color.red()
        ))

@bot.command()
@commands.has_permissions(kick_members=True, ban_members=True)
async def mute(ctx, member: nextcord.Member, time, *, reason = None):
  if member == ctx.author:
    return await ctx.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't mute yourself!", color = nextcord.Color.red()))
  if member.id == 973928310314778625:
    return await ctx.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't mute me!", color = nextcord.Color.red()))
  else:
    time = humanfriendly.parse_timespan(time)
    await member.edit(timeout = nextcord.utils.utcnow()+datetime.timedelta(seconds=time))
    await ctx.send(embed=nextcord.Embed(title=f"Successfully muted.",color = 0x2F3136).add_field(name="⚙ MOD:", value=f"{ctx.author.mention}", inline = True).add_field(name="😡 Member:", value=f"{member.mention}", inline = True).add_field(name="❓ Reason:", value=f"{reason}", inline = True).set_footer(text=f"On {time} seconds!"))

@bot.command()
@commands.has_permissions(kick_members=True, ban_members=True)
async def unmute(ctx, member: nextcord.Member):
  if member == ctx.author:
    return await ctx.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't unmute yourself!", color = nextcord.Color.red()))
    await member.edit(timeout = None)
    await ctx.send(embed=nextcord.Embed(title=f"Successfully unmuted.",
  		color = 0x2F3136).add_field(name="⚙ MOD:", value=f"{interactioт.author.mention}", inline = True).add_field(name="😡 Member:", value=f"{member.mention}", inline = True))

@bot.command()
@commands.has_permissions(kick_members=True, ban_members=True)
async def kick(ctx, member: nextcord.Member, *, reason=None):
  if member == ctx.author:
    return await ctx.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't kick yourself!", color = nextcord.Color.red()))
  elif member.id == 973928310314778625:
    return await ctx.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't kick me!", color = nextcord.Color.red()))
  else:
    await member.kick(reason=reason)
    await ctx.send(embed=nextcord.Embed(
    	title=f"Successfully kicked.",
    	color = 0x2F3136).add_field(name="⚙ MOD:", value=f"{ctx.author.mention}", inline = True).add_field(name="😡 Member:", value=f"{member.mention}", inline = True).add_field(name="❓ Reason:", value=f"{reason}", inline = True))



@bot.command()
@commands.has_permissions(kick_members=True, ban_members=True)
async def ban(ctx, member: nextcord.Member, *, reason=None):
  if member == ctx.author:
    return await ctx.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't ban yourself!", color = nextcord.Color.red()))
  elif member.id == 973928310314778625:
    return await ctx.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't ban me!", color = nextcord.Color.red()))
  else:
    await ctx.send(embed=nextcord.Embed(
    		title=f"Successfully banned.",
    		color = 0x2F3136).add_field(name="⚙ MOD:", value=f"{ctx.author.mention}", inline = True).add_field(name="😡 Member:", value=f"{member.mention}", inline = True).add_field(name="❓ Reason:", value=f"{reason}", inline = True))
    await member.ban(reason=reason)


@bot.command()
@commands.has_permissions(kick_members=True, ban_members=True)
async def unban(ctx, *, member):
	banned_users = await ctx.guild.bans()
	member_name, member_discriminator = member.split("#")

	for ban_entry in banned_users:
		user = ban_entry.user

		if (user.name, user.discriminator) == (member_name, member_discriminator):
			await ctx.guild.unban(user)
			await ctx.send(embed=nextcord.Embed(
				title=f" <:yes:993171492563079260>    |   {user} успішно розблоковано!",
				color = 0x2F3136
			).add_field(name="⚙ MOD:", value=f"{interactioт.author.mention}", inline = True).add_field(name="😡 Member:", value=f"{user}", inline = True))

@bot.command()
async def avatar(ctx, *, member : nextcord.Member = None):
  if member == None:
    member = ctx.author

  memberAvatar = member.display_avatar

  avaEmbed = nextcord.Embed(title = f"Avatar of {member.name}", color = 0x2F3136 )
  avaEmbed.set_image(url = memberAvatar)
  await ctx.send(embed = avaEmbed)

@bot.command()
async def complain(ctx, user: nextcord.Member, *, reason):
  await ctx.send(embed=nextcord.Embed(description = f"<:Text:968822724719964220> New complaint", color = 0x2F3136).add_field(name=f"Bad guy:  {user}", value = f"Reason: `{reason}`", inline = False).set_author(name=f"{ctx.author} | 2022", icon_url=ctx.author.avatar).set_image(url="https://cdspvinhlong.edu.vn/wp-content/uploads/2021/10/1635444272_714_Cau-Truc-va-Cach-Dung-tu-Report-trong-cau-Tieng.png"))
  await ctx.message.delete()



@bot.command()
async def play(ctx: commands.Context, *, search: wavelink.YouTubeTrack):
    if not ctx.voice_client:
        vc: wavelink.Player = await ctx.author.voice.channel.connect(cls=wavelink.Player)
    elif not getattr(ctx.author.voice, "channel", None):
        return await ctx.send("Join a voice channel first, lol")
    else:
        vc: wavelink.Player = ctx.voice_client
    
    if vc.queue.is_empty and not vc.is_playing():
        await vc.play(search)
        embed = nextcord.Embed(title=f"Music from - {vc.track.author} ", description=f"[{vc.track.title}]({str(vc.track.uri)})", color=0x2F3136)
        embed.add_field(name="Artist:", value = f"**`{vc.track.author}`**", inline = True)
        embed.add_field(name="Duration:", value = f"**`{str(datetime.timedelta(seconds=vc.track.length))}`**", inline = True)
        embed.set_footer(text=f"Music by Que") 
        embed.set_image(url = f"{vc.track.thumbnail}")
        await ctx.send(embed = embed, view = queueView())      
    else:
        await vc.queue.put_wait(search)
        await ctx.send(embed = nextcord.Embed(title = "Queue", description =f"{search.title} added to the queue!", color = 0x2F3136))
    vc.ctx = ctx
    try:
        if vc.loop: return
    except Exception:
        setattr(vc, "loop", False)
      



@bot.command()
async def queue(ctx):
  if not ctx.voice_client:
    vc: wavelink.Player = await channel.connect(cls=wavelink.Player)
  elif not getattr(ctx.author.voice, "channel", None):
    return await ctx.send("Join the voice channel first.")
  else:
    vc: wavelink.Player = ctx.voice_client
    
    if not vc.is_playing():
      embed = nextcord.Embed(title = "Music", description= "Man, nothing is playing yet ....", color = 0x2F3136)
      embed.set_footer(text = "Man, why can't people be a little smarter?")
      await ctx.send(embed = embed)

    embed = nextcord.Embed(title=f"Music from - {vc.track.author} ", description=f"[{vc.track.title}]({str(vc.track.uri)})", color=0x2F3136)
    embed.add_field(name="Artist:", value = f"**`{vc.track.author}`**", inline = True)
    embed.add_field(name="Duration:", value = f"**`{str(datetime.timedelta(seconds=vc.track.length))}`**", inline = True)
    embed.set_footer(text=f"Music by Que") 
    embed.set_image(url = f"{vc.track.thumbnail}")
    await ctx.send(embed = embed, view = queueView())




#@bot.command(aliases=["antiurl-enable"])
#@commands.has_permissions(kick_members=True, ban_members=True)
#async def antiurlon(ctx):
 # async with bot.db.cursor() as cursor:
 #   await cursor.execute("SELECT urlsys FROM antiurl WHERE guild = ?", (ctx.guild.id,))
 #   urlsys = await cursor.fetchone()
  #  if urlsys:
  #    if urlsys[0]:
      #  return await ctx.send(embed = nextcord.Embed(title = "Hmmmmm", description = "Antli-Url System is already `Enabled` on this server!", color = 0x2F3136))
     # await cursor.execute("UPDATE antiurl SET urlsys = ? WHERE guild = ?", (True, ctx.guild.id,))
   # else:
  #    await cursor.execute("INSERT INTO antiurl VALUES (?, ?, ?)", (True, 0, ctx.guild.id,))
  #  await ctx.send(embed = nextcord.Embed(title = "Success", description = "Antli-Url System is now `Enabled`", color = 0x2F3136))

#@bot.slash_command(name="antiurl-enable", description = "Enable antiurl system")
#@application_checks.has_permissions(administrator=True)
#async def antiurlon(interaction: Interaction):
 # async with bot.db.cursor() as cursor:
  #  await cursor.execute("SELECT urlsys FROM antiurl WHERE guild = ?", (interaction.guild.id,))
  #  urlsys = await cursor.fetchone()
   # if urlsys:
   #   if urlsys[0]:
     #   return await interaction.send(embed = nextcord.Embed(title = "Hmmmmm", description = "Antli-Url System is already `Enabled` on this server!", color = 0x2F3136))
   #   await cursor.execute("UPDATE antiurl SET urlsys = ? WHERE guild = ?", (True, interaction.guild.id,))
   # else:
   #   await cursor.execute("INSERT INTO antiurl VALUES (?, ?, ?)", (True, 0, interaction.guild.id,))
   # await interaction.send(embed = nextcord.Embed(title = "Success", description = "Antli-Url System is now `Enabled`", color = 0x2F3136))


#@bot.command(aliases=["antiurl-disable"])
#@commands.has_permissions(kick_members=True, ban_members=True)
#async def antiurloff(ctx):
  #async with bot.db.cursor() as cursor:
   # await cursor.execute("SELECT urlsys FROM antiurl WHERE guild = ?", (ctx.guild.id,))
    #urlsys = await cursor.fetchone()
   # if urlsys:
    #  if not urlsys[0]:
    #    return await ctx.send(embed = nextcord.Embed(title = "Hmmmmm", description = "Antli-Url System is already `Disabled` on this server!", color = 0x2F3136))
     # await cursor.execute("UPDATE antiurl SET urlsys = ? WHERE guild = ?", (False, ctx.guild.id,))
    #else:
    #  await cursor.execute("INSERT INTO antiurl VALUES (?, ?, ?)", (False, 0, ctx.guild.id,))
  #  await ctx.send(embed = nextcord.Embed(title = "Success", description = "Anti-Url system is now `Disabled`", color = 0x2F3136))
 # await bot.db.commit()

#@bot.slash_command(name="antiurl-disable", description = "Disable antiurl system")
#@application_checks.has_permissions(administrator=True)
#async def antiurldis(interaction: Interaction):
 # async with bot.db.cursor() as cursor:
 #   await cursor.execute("SELECT urlsys FROM antiurl WHERE guild = ?", (interaction.guild.id,))
  #  urlsys = await cursor.fetchone()
  #  if urlsys:
   #   if not urlsys[0]:
   #     return await interaction.send(embed = nextcord.Embed(title = "Hmmmmm", description = "Antli-Url System is already `Disabled` on this server!", color = 0x2F3136))
   #   await cursor.execute("UPDATE antiurl SET urlsys = ? WHERE guild = ?", (False, interaction.guild.id,))
  #  else:
  #    await cursor.execute("INSERT INTO antiurl VALUES (?, ?, ?)", (False, 0, interaction.guild.id,))
 #   await interaction.send(embed = nextcord.Embed(title = "Success", description = "Anti-Url system is now `Disabled`", color = 0x2F3136))
#  await bot.db.commit()

    
@bot.command()
async def volume(ctx, volume: int):
  if not ctx.voice_client:
    return await ctx.send(embed = nextcord.Embed(title = "I'm not even in the voice channel!", color = nextcord.Color.red()))
  elif not getattr(ctx.author.voice, "channel", None):
    return await ctx.send(embed = nextcord.Embed(title ="Join the channel first, lol", color = nextcord.Color.red()))
  else:
    vc: wavelink.Player = ctx.voice_client

  if volume > 100:
    return await ctx.send(embed = nextcord.Embed(title ="It's to big! .-.", color = nextcord.Color.red()))
  elif volume < 0:
    return await ctx.send(embed = nextcord.Embed(title ="It's to small! ._.", color = nextcord.Color.red()))
  await ctx.send(embed = nextcord.Embed(title = "Success", description = f" <:yes:993171492563079260>    |   I have successfuly set the volume to `{volume}`%", color = 0x2F3136))
  return await vc.set_volume(volume)


@bot.command()
async def punch(ctx, member: nextcord.Member):
  if member == ctx.author:
    await ctx.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't punch yourself!", color = nextcord.Color.red()))
  else:
    chance = random.randint(1, 5)
    if chance == 1:
      await ctx.send(embed = nextcord.Embed(
        title = f"Puching {member.name}",
        description = f"That's a shame, {ctx.author.mention} just punched {member.mention}",
        color = 0x2F3136
      ).set_image(url = "https://media.giphy.com/media/DuVRadBbaX6A8/giphy.gif")) 
    if chance == 2:
      await ctx.send(embed = nextcord.Embed(
        title = f"Puching {member.name}",
        description = f"That's a shame, {ctx.author.mention} just punched {member.mention}",
        color = 0x2F3136
      ).set_image(url = "https://media.giphy.com/media/11HeubLHnQJSAU/giphy.gif")) 
    if chance == 3:
      await ctx.send(embed = nextcord.Embed(
        title = f"Puching {member.name}",
        description = f"Це жаx, {ctx.author} тільки що вдрарив {людина.mention}",
        color = 0x2F3136
      ).set_image(url = "https://media.giphy.com/media/Gf3AUz3eBNbTW/giphy.gif")) 
    if chance == 4:
      await ctx.send(embed = nextcord.Embed(
        title = f"Puching {member.name}",
        description = f"That's a shame, {ctx.author.mention} just punched {member.mention}",
        color = 0x2F3136
      ).set_image(url = "https://media.giphy.com/media/24bWF2tiKrg0H59qcL/giphy.gif")) 
    if chance == 5:
      await ctx.send(embed = nextcord.Embed(
        title = f"Puching {member.name}",
        description = f"That's a shame, {ctx.author.mention} just punched {member.mention}",
        color = 0x2F3136
      ).set_image(url = "https://media.giphy.com/media/4N57n3Rei8iEE/giphy.gif")) 
  
@bot.command()
async def sleep(ctx):
  chance = random.randint(1, 5)
  if chance == 1:
    await ctx.send(embed = nextcord.Embed(
      title="Shhh",
      description = f"Baybe **{ctx.author.mention}** is sleeping! Let's be quiter in the chat!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/jAe22Ec5iICCk/giphy.gif"))
  if chance == 2:
    await ctx.send(embed = nextcord.Embed(
      title="Shhh",
      description = f"Baybe **{ctx.author.mention}** is sleeping! Let's be quiter in the chat!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/iQHDtnUZ7gxI4/giphy.gif"))
  if chance == 3:
    await ctx.send(embed = nextcord.Embed(
      title="Shhh",
      description = f"Baybe **{ctx.author.mention}** is sleeping! Let's be quiter in the chat!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/PrurCwlB509Ne/giphy.gif"))
  if chance == 4:
    await ctx.send(embed = nextcord.Embed(
      title="Shhh",
      description = f"Baybe **{ctx.author.mention}** is sleeping! Let's be quiter in the chat!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/1oDA6lccgPe1y/giphy.gif"))
  if chance == 5:
    await ctx.send(embed = nextcord.Embed(
      title="Shhh",
      description = f"Baybe **{ctx.author.mention}** is sleeping! Let's be quiter in the chat!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/8xqpIqXQ2wcuI/giphy.gif"))

@bot.command()
async def run(ctx, member: nextcord.Member):
  if member == ctx.author:
    return await ctx.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't run yourself!", color = nextcord.Color.red()))
  else:
    chance = random.randint(1, 5)
    if chance == 1:
      await ctx.send(embed = nextcord.Embed(
        title="Ahhhhh",
        description = f"**{member.name}** is tired! Give him/her some water! <a:dead91902a8ed46b86c90dc59e51a1da:945578601498177556> ",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/dkogoMp2yQSI0/giphy.gif"))
    if chance == 2:
      await ctx.send(embed = nextcord.Embed(
        title="Ahhhhh",
        description = f"**{member.name}** is tired! Give him/her some water! <a:dead91902a8ed46b86c90dc59e51a1da:945578601498177556> ",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/3o7buglpVsPfToWMxO/giphy.gif"))
    if chance == 3:
      await ctx.send(embed = nextcord.Embed(
        title="Ahhhhh",
        description = f"**{member.name}** is tired! Give him/her some water! <a:dead91902a8ed46b86c90dc59e51a1da:945578601498177556> ",
      ).set_image(url = "https://media.giphy.com/media/rhycsJAg5UVkQ/giphy.gif"))
    if chance == 4:
      await ctx.send(embed = nextcord.Embed(
        title="Ahhhhh",
        description = f"**{member.name}** is tired! Give him/her some water! <a:dead91902a8ed46b86c90dc59e51a1da:945578601498177556> ",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/KRH2MDRBywNwHe91h9/giphy.gif"))
    if chance == 5:
      await ctx.send(embed = nextcord.Embed(
        title="Ahhhhh",
        description = f"**{людина.name}** is tired! Give him/her some water! <a:dead91902a8ed46b86c90dc59e51a1da:945578601498177556> ",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/CRWdhM1XgJ7Pi/giphy.gif"))
#=============================================================================  

@bot.command()
async def kiss(ctx, member: nextcord.Member):
  if member == ctx.author:
    return await ctx.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't kiss yourself!", color = nextcord.Color.red()))
  else:
    chance = random.randint(1, 5)
    if chance == 1:
      await ctx.send(embed = nextcord.Embed(
        title="<3",
        description = f"{ctx.author.mention} kissed {member.mention}!",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/Ka2NAhphLdqXC/giphy.gif"))
    if chance == 2:
      await ctx.send(embed = nextcord.Embed(
        title="<3",
        description = f"{ctx.author.mention} kissed {member.mention}!",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/sS7Jac8n7L3Ve/giphy.gif"))
    if chance == 3:
      await ctx.send(embed = nextcord.Embed(
        title="<3",
        description = f"{ctx.author.mention} kissed  {людина.mention}!",
        color = 0x2F3136  
      ).set_image(url = "https://media.giphy.com/media/bm2O3nXTcKJeU/giphy.gif"))
    if chance == 4:
      await ctx.send(embed = nextcord.Embed(
        title="<3",
        description = f"{ctx.author.mention} kissed {member.mention}!",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/11rWoZNpAKw8w/giphy.gif"))
    if chance == 5:
      await ctx.send(embed = nextcord.Embed(
        title="<3",
        description = f"{ctx.author.mention} kissed {member.mention}!",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/11rWoZNpAKw8w/giphy.gif"))

@bot.command()
async def swim(ctx):
  chance = random.randint(1, 5)
  if chance == 1:
    await ctx.send(embed = nextcord.Embed(
      title="I'm tired ⏳",
      description = f"{ctx.author.mention} is swimming!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/l3V0mnnGcVblF8bAI/giphy.gif"))
  if chance == 2:
    await ctx.send(embed = nextcord.Embed(
      title="I'm tired ⏳",
      description = f"{ctx.author.mention} is swimming!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/TfRDVuQr4QYJlmNjfZ/giphy.gif"))
  if chance == 3:
    await ctx.send(embed = nextcord.Embed(
      title="I'm tired ⏳",
      description = f"{ctx.author.mention} is swimming!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/XnCDYYVAen3gI/giphy.gif"))
  if chance == 4:
    await ctx.send(embed = nextcord.Embed(
      title="I'm tired ⏳",
      description = f"{ctx.author.mention} is swimming!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/CUe2pyv7sNUkM/giphy.gif"))
  if chance == 5:
    await ctx.send(embed = nextcord.Embed(
      title="I'm tired ⏳",
      description = f"{ctx.author.mention} is swimming!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/h2eSZKHwohF20gYc7A/giphy.gif"))

@bot.command()
async def hug(ctx, member: nextcord.Member):
  if member == ctx.author:
    return await ctx.send(embed = nextcord.Embed(description = "<:no:993171433981227058> | You can't hug yourself!", color = nextcord.Color.red()))
  else:
    chance = random.randint(1, 5)
    if chance == 1:
      await ctx.send(embed = nextcord.Embed(
        title="",
        description = f"{ctx.author.mention} is hugging {member.mention}!",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/PHZ7v9tfQu0o0/giphy.gif"))
    elif chance == 2:
      await ctx.send(embed = nextcord.Embed(
        title="",
        description = f"{ctx.author.mention} is hugging {member.mention}!",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/GMFUrC8E8aWoo/giphy.gif"))
    elif chance == 3:
      await ctx.send(embed = nextcord.Embed(
        title="",
        description = f"{ctx.author.mention} is hugging {member.mention}!",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/49mdjsMrH7oze/giphy.gif"))
    elif chance == 4:
      await ctx.send(embed = nextcord.Embed(
        title="",
        description = f"{ctx.author.mention} is hugging {member.mention}!",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/DjczAlIcyK1Co/giphy.gif"))
    elif chance == 5:
      await ctx.send(embed = nextcord.Embed(
        title="",
        description = f"{ctx.author.mention} is hugging {member.mention}!",
        color = 0x2F3136 
      ).set_image(url = "https://media.giphy.com/media/sUIZWMnfd4Mb6/giphy.gif")) 

@bot.command()
async def cry(ctx):
  chance = random.randint(1, 5)
  if chance == 1:
    await ctx.send(embed = nextcord.Embed(
      title="",
      description = f"{ctx.author.mention} is crying!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/XKpHeWeupl1q8/giphy.gif"))
  if chance == 2:
    await ctx.send(embed = nextcord.Embed(
      title="",
      description = f"{ctx.author.mention} is crying!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/3fmRTfVIKMRiM/giphy.gif"))
  if chance == 3:
    await ctx.send(embed = nextcord.Embed(
      title="",
      description = f"{ctx.author.mention} is crying!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/cUl8fuIG75QWs/giphy.gif"))
  if chance == 4:
    await ctx.send(embed = nextcord.Embed(
      title="",
      description = f"{ctx.author.mention} is crying!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/YJ3qdaPDIPZVS/giphy.gif"))
  if chance == 5:
    await ctx.send(embed = nextcord.Embed(
      title="",
      description = f"{ctx.author.mention} is crying!",
      color = 0x2F3136 
    ).set_image(url = "https://media.giphy.com/media/oS4LjGIpwuE1O/giphy.gif"))   


@bot.command()
async def roll(ctx, num1: int, num2: int):
	await ctx.send(embed=nextcord.Embed(
		title="Random number",
		description=f"The system gave a number: `{random.randint(num1, num2)}`",
		color = 0x2F3136
	))

@bot.command()
async def minesweeper(ctx):
  chance = random.randint(1, 5)
  if chance == 1:
    await ctx.send("|| :zero: || || :zero: || || :zero: || || :one: || || :one: || || :one: || || :zero: || || :zero: || || :zero: ||\n|| :zero: || || :zero: || || :zero: || || :one: || || :boom: || || :one: || || :one: || || :one: || || :one: ||\n|| :zero: || || :zero: || || :zero: || || :one: || || :one: || || :one: || || :one: || || :boom: || || :one: ||\n|| :zero: || || :one: || || :one: || || :one: || || :one: || || :one: || || :three: || || :three: || || :three: ||\n|| :zero: || || :one: || || :boom: || || :one: || || :one: || || :boom: || || :two: || || :boom: || || :boom: ||\n|| :zero: || || :one: || || :one: || || :one: || || :one: || || :two: || || :three: || || :three: || || :two: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :two: || || :boom: || || :one: || || :zero: ||\n|| :zero: || || :one: || || :one: || || :one: || || :one: || || :boom: || || :three: || || :two: || || :zero: ||\n|| :zero: || || :one: || || :boom: || || :one: || || :one: || || :two: || || :boom: || || :one: || || :zero: ||")
  if chance == 2:
    await ctx.send("|| :one: || || :one: || || :one: || || :one: || || :one: || || :one: || || :one: || || :boom: || || :one: ||\n|| :one: || || :boom: || || :one: || || :one: || || :boom: || || :two: || || :two: || || :two: || || :one: ||\n|| :one: || || :one: || || :one: || || :one: || || :one: || || :two: || || :boom: || || :one: || || :zero: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :one: || || :one: || || :zero: ||\n|| :two: || || :two: || || :two: || || :one: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: ||\n|| :boom: || || :boom: || || :three: || || :boom: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: ||\n|| :three: || || :boom: || || :three: || || :one: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: ||\n|| :two: || || :two: || || :two: || || :zero: || || :one: || || :one: || || :one: || || :zero: || || :zero: ||\n|| :one: || || :boom: || || :one: || || :zero: || || :one: || || :boom: || || :one: || || :zero: || || :zero: ||")
    if chance == 3:
      await ctx.send("|| :zero: || || :one: || || :boom: || || :one: || || :zero: || || :one: || || :boom: || || :boom: || || :boom: ||\n|| :zero: || || :one: || || :one: || || :two: || || :one: || || :two: || || :two: || || :four: || || :three: ||\n|| :zero: || || :zero: || || :zero: || || :one: || || :boom: || || :one: || || :one: || || :three: || || :boom: ||\n|| :one: || || :one: || || :one: || || :one: || || :one: || || :one: || || :one: || || :boom: || || :boom: ||\n|| :one: || || :boom: || || :one: || || :zero: || || :zero: || || :zero: || || :one: || || :two: || || :two: ||\n|| :one: || || :one: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: ||\n|| :zero: || || :one: || || :one: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: ||\n|| :zero: || || :one: || || :boom: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: ||\n|| :zero: || || :one: || || :one: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: ||")
    if chance == 4:
      await ctx.send("|| :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :boom: ||\n|| :two: || || :two: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :one: ||\n|| :boom: || || :boom: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :one: ||\n|| :three: || || :three: || || :one: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :boom: ||\n|| :boom: || || :two: || || :one: || || :zero: || || :zero: || || :one: || || :one: || || :two: || || :one: ||\n|| :two: || || :boom: || || :two: || || :one: || || :one: || || :one: || || :boom: || || :one: || || :zero: ||\n|| :one: || || :one: || || :two: || || :boom: || || :one: || || :two: || || :two: || || :two: || || :zero: ||\n|| :zero: || || :zero: || || :one: || || :one: || || :two: || || :two: || || :boom: || || :one: || || :zero: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :boom: || || :two: || || :one: || || :zero: ||")
    if chance == 5:
      await ctx.send("|| :boom: || || :boom: || || :one: || || :one: || || :boom: ||\n|| :two: || || :one: || || :one: || || :one: ||\n|| :two: || || :two: || || :one: || || :one: || || :two: || || :boom: || || :one: || || :one: || || :boom: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :one: || || :one: || || :two: || || :two: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :boom: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :one: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :two: || || :two: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :two: || || :boom: || || :boom: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :boom: || || :four: || || :boom: ||\n|| :zero: || || :zero: || || :zero: || || :zero: || || :zero: || || :one: || || :one: || || :two: || || :one: ||")

@bot.command()
async def invites(ctx, member: nextcord.Member):
	if member.id == config.BOT_ID:
		pass
	else:
		invites = 0

	for i in await ctx.guild.invites():
		if i.inviter == member:
			invites += i.uses
	
	await ctx.send(embed=nextcord.Embed(
		title="Invites",
		description=f"**{member}** has `{invites}` invites!",
		color = 0x2F3136
	))




@bot.command()
async def afk(ctx, *, reason):
    if reason == None:
        reason = "No reason provided"
    async with bot.db.cursor() as cursor:
        await cursor.execute("SELECT reason FROM afk WHERE user = ? AND guild = ?", (ctx.author.id, ctx.guild.id,))
        data = await cursor.fetchone()
        if data:
            if data[0] == reason:
                return await ctx.send("You are afk with the same reason!")
            await cursor.execute("UPDATE afk SET reason = ? WHERE user = ? AND guild = ?", (reason, ctx.author.id, ctx.guild.id,))
        else: 
            await cursor.execute("INSERT INTO afk (user, guild, reason) VALUES (?, ?, ?)", (ctx.author.id, ctx.guild.id, reason,))
            await ctx.send(embed = nextcord.Embed(title = "Afk", description = f" {ctx.author.mention} you are now afk for `{reason}`", color = 0x2F3136))
        await bot.db.commit()

      
from PIL import Image

@bot.command()
async def wanted(ctx, member: nextcord.Member):
  wanted = Image.open("assets/wanted.jpg")

  data = BytesIO(await member.display_avatar.read())
  pfp = Image.open(data)

  pfp = pfp.resize((150, 150))

  wanted.paste(pfp, (90, 170))

  wanted.save("wanted.jpg")

  await ctx.send(file = nextcord.File("wanted.jpg"))

@bot.command(aliases=["bot"])
async def botinfo(ctx):
  high_servers = []
  for guild in bot.guilds:
    if len(guild.members) > 1000:
      high_servers.append(guild.name)
  await ctx.send(embed=nextcord.Embed(
    title = "Que Protect Stats",
    description = f"**Main:\n**📣 Ping: **{round(bot.latency * 1000)}** ms\n\n**Servers**\n👑 Amount: **{len(bot.guilds)}**\n📈 High Servers: **{len(high_servers)}**\n😎 Users: **{len(set(bot.get_all_members()))}**\n\n**Other**\n📅 Created: **16.06.2022**\n📘Python Version: **3.10**\n📚 Library: **Nextcord**\n🥏 Version: **1.0**\n🔰 Developer: **MSav#7305**\n\n**Links**\n ❔ Server: https://discord.gg/dhckHc6Zse\n 🌐 Website: http://www.quebot.gq/",
		color = 0x2F3136
	).set_footer(text=f"Requested by {ctx.author} | 2022").set_thumbnail(url="https://www.linkpicture.com/q/QueBot.png"))

@bot.command()
async def flip(ctx):
  if random.randint(1, 100) <= 50:
    await ctx.send("You flipped **heads**!")
  else:
    await ctx.send("You flipped **tails**!")

@bot.command()
async def emojify(ctx, *, text):
	emojis = []

	for symbol in text.lower():
		if symbol.isdecimal():
			num_to_emo = {
				"0": "zero",
				"1": "one",
				"2": "two",
				"3": "three",
				"4": "four",
				"5": "five",
				"6": "six",
				"7": "seven",
				"8": "eight",
				"9": "nine",
			}

			emojis.append(f":{num_to_emo.get(symbol)}:")
		elif symbol.isalpha():
			emojis.append(f":regional_indicator_{symbol}:")
		elif symbol == " ":
			emojis.append(symbol)
		else:
			pass
		
	await ctx.send("".join(emojis))

@bot.command()
async def short_url_(ctx, url: str):
	global url_shortener

	shortened_url = url_shortener.short(url)

	await ctx.send(embed=nextcord.Embed(
		title="Succes",
		description=f" <:yes:993171492563079260>   | Shorted url: {shortened_url}",
		color = 0x2F3136
	))

@bot.command()
async def clear(ctx, amount: int=100):
  amount_purged = await ctx.channel.purge(limit=amount)
  await ctx.send(embed=nextcord.Embed(
    title=f" <:yes:993171492563079260>    |   Successfully deleted `{len (amount_purged)}` messages!",
		color = 0x2F3136
	), delete_after = 6)

@bot.command()
async def ping(ctx):
  await ctx.send(embed = nextcord.Embed(
    title = "Pong :ping_pong:",
    description = f"**My API ping is:**\n{round(bot.latency * 1000)} ms!",
    color = 0x2F3136
  ))

@bot.command()
async def meme(ctx):
  view=MemeBtnn(ctx)
  memeApi = urllib.request.urlopen("https://meme-api.herokuapp.com/gimme")
  memeData = json.load(memeApi)

  memeUrl = memeData["url"]
  memeName = memeData["title"]
  memePoster = memeData["author"]
  memeReddit = memeData["subreddit"]
  memeLink = memeData["postLink"]

  memeEmbed = nextcord.Embed(title=memeName, color=0x2F3136)
  memeEmbed.set_image(url=memeUrl)
  memeEmbed.set_footer(
    text=f"Meme by: {memePoster}")
  await ctx.send(embed=memeEmbed, view=view)

@bot.command()
async def rok(ctx):
  view = RockBtnn(ctx)
  async with aiohttp.ClientSession() as session:
    async with session.get("https://mrconos.pythonanywhere.com/rock/random") as api:
      data = await api.json()

    rok_name = data["name"]
    rok_desc = data["desc"]
    rok_img = data["image"]
  
    rockEmbed = nextcord.Embed(title=rok_name, color=0x2F3136)
    rockEmbed.set_image(url=rok_img)
    await ctx.send(embed=rockEmbed, view=view)






class ResetBtnn(nextcord.ui.View):
    def __init__(self, interaction: Interaction):
        super().__init__()
        self.interaction = interaction

    @nextcord.ui.button(label="Name", style=nextcord.ButtonStyle.green)
    async def changename(self, button: nextcord.ui.Button, interaction: nextcord.Interaction):
      await interaction.guild.edit(name="Change the name!")
      await interaction.send("The server name has been changed successfuly.",ephemeral=True)
    @nextcord.ui.button(label="Icon", style=nextcord.ButtonStyle.blurple)
    async def changeicon(self, button: nextcord.ui.Button, interaction: nextcord.Interaction):
      with open('assets/ChangeTheIcon.png', 'rb') as f:
        avatar = f.read()
        await interaction.guild.edit(icon=avatar)
      await interaction.send("Server icon has been changed successfuly.",ephemeral=True)
    @nextcord.ui.button(label="Delete-All", style=nextcord.ButtonStyle.danger)
    async def changeall(self, button: nextcord.ui.Button, interaction: nextcord.Interaction):
      for channel in interaction.guild.channels:
        await channel.delete()
      await interaction.send("All channels have been deleted successfuly.",ephemeral=True)


@bot.command(aliases=["reset-server"])
@commands.is_owner()
async def resetserver(ctx):
    view = ResetBtnn(ctx)
    await ctx.send(embed=nextcord.Embed(title = "Reseting server", description = "Select what should I reser. (You can choose many options)", color = 0x2F3136), view = view)

@bot.slash_command(name="reset-server", description = "Resey Server")
@application_checks.is_owner()
async def resetserver(interaction: Interaction):
    view = ResetBtnn(interaction)
    await interaction.send(embed=nextcord.Embed(title = "Reseting server", description = "Select what should I reser. (You can choose many options)", color = 0x2F3136), view = view)


@bot.command()
@commands.has_permissions(administrator=True)
async def lock(ctx, channel: nextcord.TextChannel = None):
  if channel is None:
    await ctx.channel.set_permissions(ctx.guild.default_role, reason = f"{ctx.author} locked {ctx.channel}", send_messages = False)
    await ctx.message.add_reaction("🔒")
  else:
    await channel.set_permissions(ctx.guild.default_role, reason = f"{ctx.author} locked {channel}", send_messages = False)
    await message.add_reaction("🔒")
    

@bot.command()
@commands.has_permissions(administrator=True)
async def unlock(ctx, channel: nextcord.TextChannel = None):
  if channel is None:
    await ctx.channel.set_permissions(ctx.guild.default_role, reason = f"{ctx.author} unlocked {ctx.channel}", send_messages = True)
    await ctx.message.add_reaction("🔓")
  else:
    await channel.set_permissions(ctx.guild.default_role, reason = f"{ctx.author} unlocked {channel}", send_messages = True)
    await message.add_reaction("🔓")

@bot.slash_command(description="Lock channel")
@application_checks.has_permissions(administrator=True)
async def lock(interaction: Interaction):
    await interaction.channel.set_permissions(interaction.guild.default_role, reason = f"{interaction.user} locked {interaction.channel}", send_messages = False)
    await interaction.send("🔒")

@bot.slash_command(description="Unlock channel")
@application_checks.has_permissions(administrator=True)
async def unlock(interaction: Interaction):
    await interaction.channel.set_permissions(interaction.guild.default_role, reason = f"{interaction.user} unlocked {interaction.channel}", send_messages = True)
    await interaction.send("🔓")
    

@bot.command()
@commands.has_permissions(administrator=True)
async def quarantine(ctx, member: nextcord.Member):
    for channel in ctx.guild.channels:
        await channel.set_permissions(member, reason = f"{ctx.author} has quarantined {member}", view_channel = False)
    await ctx.send(embed=nextcord.Embed(
        title = "Quarantine",
        description = f"Success! {member.mention} has been quarantined. To unquarantine, use `q!unquarantine` command",
        color= 0x2F3136
    ))

@bot.command()
@commands.has_permissions(administrator=True)
async def unquarantine(ctx, member: nextcord.Member):
    for channel in ctx.guild.channels:
        await channel.set_permissions(member, reason = f"{ctx.author} has quarantined {member}", view_channel = True)
    await ctx.send(embed=nextcord.Embed(
        title = "Unquarantine",
        description = f"Success! {member.mention} has been unquarantined.",
        color= 0x2F3136
    ))


@bot.slash_command(description = "Quarantines a member")
@application_checks.has_permissions(administrator=True)
async def quarantine(interaction: Interaction, member: nextcord.Member):
    for channel in interaction.guild.channels:
        await channel.set_permissions(member, reason = f"{interaction.user} has quarantined {member}", view_channel = False)
    await interaction.send(embed=nextcord.Embed(
        title = "Quarantine",
        description = f"Success! {member.mention} has been quarantined. To unquarantine, use `q!unquarantine` command",
        color= 0x2F3136
    ))

@bot.slash_command(description = "Unquarantines a member")
@application_checks.has_permissions(administrator=True)
async def unquarantine(interaction: Interaction, member: nextcord.Member):
    for channel in interaction.guild.channels:
        await channel.set_permissions(member, reason = f"{interaction.user} has quarantined {member}", view_channel = True)
    await interaction.send(embed=nextcord.Embed(
        title = "Unquarantine",
        description = f"Success! {member.mention} has been unquarantined.",
        color= 0x2F3136
    ))

@bot.slash_command(name = "add-roles", description = "Add a role for all users")
async def addrole(interaction: Interaction, role: nextcord.Role): 
  await interaction.send(embed = nextcord.Embed(description =f"I'll give all members, role: {role.mention}. (Pls wait a bit)", color = 0x2F3136))
  for member in interaction.guild.members:
    try:
      await member.add_roles(role)
    except Exception:
      await interaction.send(embed = nextcord.Embed(description = "Error ⛔. My role is to low to give a person a role.", color = nextcord.Color.red()))

@bot.command(aliases = ["add-roles"])
async def addrole(ctx, role: nextcord.Role): 
  await ctx.send(embed = nextcord.Embed(description =f"I'll give all members, role: {role.mention}. (Pls wait a bit)", color = 0x2F3136))
  for member in ctx.guild.members:
    try:
      await member.add_roles(role)
    except Exception:
      await ctx.send(embed = nextcord.Embed(description = "Error ⛔. My role is to low to give a person a role.", color = nextcord.Color.red()))


@bot.command(aliases = ["remove-roles"])
async def remrole(ctx, role: nextcord.Role): 
  await ctx.send(embed = nextcord.Embed(description =f"I'll remove all members, role: {role.mention}. (Pls wait a bit)", color = 0x2F3136))
  for member in ctx.guild.members:
    try:
      await member.remove_roles(role)
    except Exception:
      await ctx.send(embed = nextcord.Embed(description = "Error ⛔. My role is to low to remove a person a role.", color = nextcord.Color.red()))

@bot.slash_command(name = "remove-roles", description = "Remove a role from all users")
async def remrole(interaction: Interaction, role: nextcord.Role): 
  await interaction.send(embed = nextcord.Embed(description =f"I'll remove all members, role: {role.mention}. (Pls wait a bit)", color = 0x2F3136))
  for member in interaction.guild.members:
    try:
      await member.remove_roles(role)
    except Exception:
      await interaction.send(embed = nextcord.Embed(description = "Error ⛔. My role is to low to remove a person a role.", color = nextcord.Color.red()))

@bot.event
async def on_guild_join(guild):
  async with bot.db.cursor() as cursor:

    c = await guild.create_text_channel(name="Que-Bot")
    await c.send(embed = nextcord.Embed(title= ":wave: Welcome to Que", description = f"Hello. Que - *the best antinuke bot for your server* \nThank you for adding me. My prefix is `q!` and `/`. To see my commands write `q!help`\n\n **Verify this to points to protect your server:**\n `#1` Put my role on the most top.\n `#2` Give me admin permissions.\n\n **My Server:** https://discord.gg/dhckHc6Zse").set_thumbnail(url="https://www.linkpicture.com/q/QueBot.png").set_footer(text="Now you can delete this channel | 2020 | Que", color = 0x2F3136))
    channel = bot.get_channel(993173253029908500)
    embed = nextcord.Embed(title = "New Server", description = f"**Name:** `{guild.name}`\n **Members:** `{len(guild.members)}`\n **Now I'm on** `{len(bot.guilds)}` **servers.**", color = 0x2F3136)
    if guild.icon != None:
      embed.set_image(url=guild.icon.url)
    else:
      pass
    await channel.send(embed=embed)
      
    await cursor.execute(f"INSERT INTO whitelist (user, guild) VALUES (?,?)", (guild.owner.id, guild.id))
    await cursor.execute("SELECT urlsys FROM antiurl WHERE guild = ?", (guild.id,))
    urlsys = await cursor.fetchone()
    if urlsys:
      if not urlsys[0]:
        await cursor.execute("UPDATE antiurl SET urlsys = ? WHERE guild = ?", (False, guild.id,))
    else:
      await cursor.execute("INSERT INTO antiurl VALUES (?, ?, ?)", (False, 0, guild.id,))
  await bot.db.commit()





@bot.command()
async def discrim(ctx, *, discrim = None):
  if discrim == None:
    discrim == ctx.author.discriminator
  count = 0
  embed = nextcord.Embed(title="", color = 0x2F3136)
  for guild in bot.guilds:
    for member in guild.members:
      if member.discriminator == discrim:
        count =+1
        embed.add_field(name=f"Discrim `#{count}`", value = f"{member.name}#{member.discriminator}", inline = False)
        await ctx.send(embed=embed)

@bot.slash_command(description = "Shows the same discrim. (tag)")
async def discrim(interaction: Interaction, *, discrim):
  count = 0
  embed = nextcord.Embed(title="", color = 0x2F3136)
  for guild in bot.guilds:
    for member in guild.members:
      if member.discriminator == discrim:
        count =+1
        embed.add_field(name=f"Discrim `#{count}`", value = f"{member.name}#{member.discriminator}", inline = False)
        await interaction.send(embed=embed)

@bot.command(aliases=["mass-channel"])
async def masschannel(ctx, ch: nextcord.TextChannel):
    for channel in ctx.guild.channels:
        if channel.name == ch.name:
            await channel.delete()

@bot.command(aliases=["mass-role"])
async def massrole(ctx, r: nextcord.Role):
    for role in ctx.guild.roles:
        if role.name == r.name:
            await role.delete()






#===============================================================
@bot.command()
async def prices(ctx):
  await ctx.send(embed=nextcord.Embed(
      title = "",
      description = "",
      color = 0x2F3136
    ).set_image(url="https://share.creavite.co/ejpiLD1ehB23rzen.gif"))
  await ctx.send(embed=nextcord.Embed(title = "", description = "<:portfel:993206724007841822> **・ Discord Bots**\n\n ```LiteBot - 1$-2$\nMediumBot - 5$\nHardBot - 10$-30$```\n\n <:bank:993207278587097179> **・ Websites**\n\n ```Website (Small) - 2$-3$\nWebsite (Medium) - 4$-5$\nWebsite (Big) - 5$-10$```\n\n <:bank:993207278587097179> **・ Discord Servers**\n\n ```Discord bot preparation - 1$\nDiscord server (Medium) - 2$\nDiscord server (Full) - 5$```\n\n<:bank:993207278587097179> **・ Design**\n\n```Avatar (Generator) - 0.50$\nAvatar (Photoshop) - 1$\nBanner (Generator) - 1$\nBanner (Photoshop) - 2$```\n\n If you buy something write to @MSav#7305 ", color = 0x2F3136))

@bot.command()
async def blacklist(ctx):
  if ctx.author.id == 939485684513787924:
    await ctx.send(embed=nextcord.Embed(
      title = "",
      description = "",
      color = 0x2F3136
    ).set_image(url="https://share.creavite.co/4wnhoaHKYQPP0X6w.gif"))
    await ctx.send(embed=nextcord.Embed(
      title = "Blacklist",
      description = "<:hinking:987277660856143902> **Here you can send ID's of nuke bots, to upgrade our bot skills. (Also send the screenshot)**\n\n **Example:**\n```1. Bot ID\n2. Proof\n3. Owner name and id if you know it```",
      color = 0x2F3136
    ).set_footer(text="Accept will only MSav. | 2022"))
  else:
    pass

@bot.command()
async def news(ctx):
  if ctx.author.id == 939485684513787924:
    await ctx.send(embed=nextcord.Embed(
      title = "",
      description = "",
      color = 0x2F3136
    ).set_image(url="https://share.creavite.co/OmhWKPPWTwK5LuxK.gif"))
    await ctx.send(embed=nextcord.Embed(
      title = "News",
      description = "<:staff:987277947075436554> **Here staff will post rofl and not news**\n**Also server owner will post very importnat news** <:idk:982263632081608774>",
      color = 0x2F3136
    ).set_footer(text=""))
  else:
    pass

@bot.command()
async def rules(ctx):
  if ctx.author.id == 939485684513787924:
    await ctx.send(embed=nextcord.Embed(
      title = "",
      description = "",
      color = 0x2F3136
    ).set_image(url="https://share.creavite.co/4QwAGSsTXCZTm84o.gif"))
    await ctx.send(embed=nextcord.Embed(
      title = "",
      description = "**- NO Moderation/Administration insult!**, do not insult tham!\n **- NO Offensive content**, please do not try to lie someone!\n **- Disrespect for work**, please respect the work of mod's\n**- Follow the [nextcord TOS](https://nextcord.com/terms) rules.**\n**- NO NSFW or NSFL**, doing this you'll get banned!\n **- NO Spam**, breaking this rule you'll have a mute for 5 hours! \n **- No Begging**, begging the owner/admins will be a result of ban!.\n **- Readable Text**, do not write with zalgo,  or any other form of weird text.\n **- Use Help Channels**, please try and use help channels when possible to maintain order in the server. \n**- No Self Ads**, if self ads are in the server you'll get muted for 1 day, advertising in DM is against [nextcord TOS](https://nextcord.com/terms) rules and will be a result of a ban . \n **- No Politic Discuss**, breaking this tule will be a result of a ban!",
      color = 0x2F3136
    ).set_footer(text="With respect, server owner."))
  else:
    pass

@bot.command()
async def botp(ctx):
  if ctx.author.id == 939485684513787924:
    await ctx.send(embed=nextcord.Embed(
      title = "",
      description = "",
      color = 0x2F3136
    ).set_image(url="https://share.creavite.co/LLbnj31aQOhRfVQk.gif"))
    await ctx.send(embed=nextcord.Embed(
      title = "Giveaways",
      description = "<:bank:993207278587097179> - **Here will be different giveaways**.\n ```The things we have gave\n\n 5 - Nitro's\n 6 - Tokens\n 10 - Antinuke codes\n 12 - Personal Bots```",
      color = 0x2F3136
    ))
  else:
    pass


@bot.command()
async def faq(ctx):
  if ctx.author.id == 939485684513787924:
    await ctx.send(embed=nextcord.Embed(
      title = "",
      description = "",
      color = 0x2F3136
    ).set_image(url="https://share.creavite.co/IdAXdKlrBj8MPL4C.gif"))
    await ctx.send(embed=nextcord.Embed(
      title = "",
      description = "**Que** - *the best anticrash/nuke protect bot!*\n\n <:folder:992827013507321966>**・Main Commands --->**\n\n `q!whitelist-add` - adds a member to whitelist\n\n`q!antiurl-on/off`- enables/disables the antiurl system.\n\n`q!reset-server` - resets the server\n\n`q!quarantine` - quarantines the member\n\n Also it has an automatic antinuke system.\n\n<:folder:992827013507321966> **・URL's --->**\n\n ***Invite -***\n [Add Bot](https://discord.com/api/oauth2/authorize?client_id=986923682247090236&permissions=8&scope=bot%20applications.commands)\n\n ***Server - *** \n[Join](https://discord.gg/VQXkmjH9NJ)",
      color = 0x2F3136
    ))
    await ctx.send(embed=nextcord.Embed(
      title = "",
      description = "<:portfel:993206724007841822> - **How to protect your server?**\n\n **Use Que Protect.**\n\n **Do not give anyone admin permissions.**\n\n **Do not sell admin permissions**\n\n **Even admins, mustn't have permissions:**\n```Server editing\nChannel editing\nWebhook editing```\n\n **Every day create a server template, and save channel texts.**\n\n **Do not add any don't known bots, even if they are verificated**",
      color = 0x2F3136
    ).set_footer(text="With respect, server owner."))
    
  else:
    pass

@bot.command()
async def infoch(ctx):
  if ctx.author.id == 939485684513787924:
    await ctx.send(embed=nextcord.Embed(
      title = "",
      description = "",
      color = 0x2F3136
    ).set_image(url="https://share.creavite.co/Qz7VUYGwbUUS4I0w.gif"))
    await ctx.send(embed=nextcord.Embed(
      title = "",
      description = "> **Server Inforamtion - **\n\n The best server of the best antinuke bot. (Que). Also we have a lot of giveaways. Here you can communicate or ask a question from quick admins.\n\n > Other\n\n ・Website - (on 1000 members)\n・Link - https://discord.gg/VQXkmjH9NJ",
      color = 0x2F3136
    ).set_footer(text="With respect, server owner."))
  else:
    pass

@bot.command()
async def boosts(ctx):
  if ctx.author.id == 939485684513787924:
    await ctx.send(embed=nextcord.Embed(
      title = "",
      description = "",
      color = 0x2F3136
    ).set_image(url="https://share.creavite.co/b8j2L2Jj3OPUZsN2.gif"))
    await ctx.send(embed=nextcord.Embed(
      title = "",
      description = "<:shop:992830399317299302>**・Shop**\n\n <:shop:992830399317299302>**・What will you get?**\n\n<:1boost:992833829586862183> **・1 boost**\n**・Thanks from server admins.**\n**・Booster role.**\n**・Custom role.**\n\n**<:2boost:992833981039005736> ・2 boost**\n**・Thanks from server admins.**\n**・Booster role.**\n**・Custom role.**\n**An advert in news channel.**\n\n <:shop:992830399317299302>**・How will you help us?**\n\n**・If you give a boost, it helps us with server. We can add a gif avatar, banner, more quality, role emojis and a lot of more.**!",
      color = 0x2F3136
    ).set_footer(text="With respect, server owner."))
  else:
    pass

@bot.command()
async def music(ctx):
  if ctx.author.id == 939485684513787924:
    await ctx.send(embed=nextcord.Embed(
      title = "",
      description = "",
      color = 0x2F3136
    ).set_image(url="https://share.creavite.co/b8j2L2Jj3OPUZsN2.gif"))
    await ctx.send(embed=nextcord.Embed(
      title = "Music",
      description = "<:folder:992827013507321966> **To order music:**\n```1. Join a voice channel\n2. Write `q!play` `song_name`\n3. Listen to music.```\n\n**If bot disconnected, it means that the music queue is empty <:shrug:982264679915204629>**",
      color = 0x2F3136
    ))
  else:
    pass

    
#===============================================================
class NewTicketButtons(nextcord.ui.View):
    def __init__(self, bot):
        self.bot = bot
        super().__init__(timeout=None)

    @nextcord.ui.button(emoji = "<:no:993171433981227058>", label="Close", style=nextcord.ButtonStyle.blurple, custom_id="close_ticket")
    async def close(self, button: nextcord.ui.Button, interaction: nextcord.Interaction):
        button.disabled = True
        await interaction.response.edit_message(view=self)
        ticket_role = interaction.guild.get_role(734409835269062789)

        await interaction.channel.set_permissions(interaction.guild.default_role, view_channel=False)
        await interaction.channel.set_permissions(ticket_role, send_messages=True, view_channel=True)

        await interaction.channel.send(embed = nextcord.Embed(description =f"Support ticket has been closed by {interaction.user.mention}.", color =  0x2F3136))
        await interaction.user.send(embed=nextcord.Embed(title = f"Hello {interaction.user}", description = "Your ticket on GQ server has been recently closed.\nDid you manage to solve the problem?\nIf no you can create a new one and ping the Owner (MSav#7305)\n\nTopic: **GQ Help**\n\n We have a good quality support, and we are trying to help everyone.", color = 0x2F3136).set_footer(text="Personal support on GQ | 2022"))
        await interaction.channel.set_permissions(interaction.user, send_messages=False, view_channel=False)


    @nextcord.ui.button(emoji = "<:folder:992827013507321966>", label="Delete", style=nextcord.ButtonStyle.danger, custom_id="delete_ticket")
    async def delete(self, button: nextcord.ui.Button, interaction: nextcord.Interaction):
        await interaction.response.send_message(embed = nextcord.Embed(description ="This ticket will be deleted in `5` seconds.\n**(5 seconds are because of discord rate limits)**.", color = 0x2F3136))
        await asyncio.sleep(5)
        await interaction.channel.delete()

class NewTicket(nextcord.ui.View):
    def __init__(self, bot):
        self.bot = bot
        super().__init__(timeout=None)

    @nextcord.ui.button(emoji = "<:yes:993171492563079260>", label="Create", style=nextcord.ButtonStyle.green, custom_id="new_ticket")
    async def new_ticket(self, button: nextcord.ui.Button, interaction: nextcord.Interaction):
            ticket_role = interaction.guild.get_role(734409835269062789)
            category = bot.get_channel(993445209759305829)

            channel = await interaction.guild.create_text_channel(f"{interaction.user.name}-ticket", category=category)

            await channel.set_permissions(interaction.user, send_messages=True, view_channel=True)
            await channel.set_permissions(interaction.guild.default_role, view_channel=False)
            await channel.set_permissions(ticket_role, send_messages = True, view_channel = True)
            
            await channel.edit(topic=f"New ticket for {interaction.user.name}")

            embed = nextcord.Embed(
                title=f"{interaction.user} ticket",
                description=f"Hello {interaction.user.mention}. You just opened a ticket. Please describe your problem.\n\n **More Info:**\n Author: **{interaction.user}**\nAuthor ID: **{interaction.user.id}**\nChannel ID: **{interaction.channel.id}**", 
                color=0x2F3136
            )

            await interaction.response.send_message(f"Success. Ticket opened in {channel.mention}", ephemeral=True)
            message = await channel.send(content=f"{ticket_role.mention}", embed=embed,view=NewTicketButtons(bot))



@bot.command()
async def ticketpanel(ctx):
    channel = bot.get_channel(993445328541986816)
    await ctx.send(embed = nextcord.Embed(title = "Personal Support", description = "Hello. If you are here, you probably have a problem. Please create a ticket (pressing the button below), to discuss your problem.", color = 0x2F3136).add_field(name = "Info", value = f"{channel.mention}", inline = False).add_field(name = "Creating a funny ticket", value = f"24h mute", inline = False).set_footer(text="GQ - Personal Support | By Que"), view=NewTicket(bot))


class Select(nextcord.ui.Select):
    def __init__(self):   
        options=[
            nextcord.SelectOption(emoji = "⚙",label="Utlity",description=""),
            nextcord.SelectOption(emoji = "🛠",label="Moderation",description=""),
            nextcord.SelectOption(emoji = "👮‍♂️",label="Adjustments",description=""),
            nextcord.SelectOption(emoji = "🎵", label="Music",description=""),
            nextcord.SelectOption(emoji = "😃",label="Fun",description=""),   
            nextcord.SelectOption(emoji = "💾",label="Other",description="")
        ]
        super().__init__(placeholder="Choose a help category",max_values=1,min_values=1,options=options)
    async def callback(self, interaction: nextcord.Interaction):
        if self.values[0] == "Utlity":
            await interaction.response.edit_message(embed = nextcord.Embed(title = "~ Utlity Commands", description = "", color = 0x2F3136).add_field(name = "`q!clear` `<amount>`", value = "Clears the chat", inline = True).add_field(name = "`q!eadd` `<url>` `name>`", value = "Adds an emoji", inline = True).add_field(name = "`q!short` `<url>`", value = "Shorts the url", inline = True).add_field(name = "`q!avatar` `<member>`", value = "Shows avatar", inline = True).add_field(name = "`q!embed`", value = "Creates an embed", inline = True).add_field(name = "`q!mock` `<text>`", value = "MoCkS text", inline = True).add_field(name = "`q!reverse` `<text>`", value = "Reverses text", inline = True).add_field(name = "`q!add-roles` `<role>`", value = "Add a role to all members", inline = True).add_field(name = "`q!remove-role` `<role>`", value = "Remove a role from all members", inline = True).add_field(name = "`q!lock`", value = "Locks the channel", inline = True).add_field(name = "`q!unlock`", value = "Unlocks the channel", inline = True))
        elif self.values[0] == "Moderation":
          await interaction.response.edit_message(embed = nextcord.Embed(title = "~ Moderation Commands",description ="", color = 0x2F3136).add_field(name = "`q!mute` `<member>` `<time>`", value = "Mutes member", inline = True).add_field(name = "`q!umute` `<member>`", value = "Unmutes member", inline = True).add_field(name = "`q!kick` `<member>`", value = "Kicks member", inline = True).add_field(name = "`q!ban` `<member>`", value = "Bans member", inline = True).add_field(name = "`q!unban` `<member>`", value = "Unbans the member", inline = True).add_field(name = "`q!complain` `<member>` `<reason>`", value = "Sends a complaint", inline = True).add_field(name = "`q!warn` `<member>` `<reason>`", value = "Warns a member", inline = True).add_field(name = "`q!remove-warn` `<member>`", value = "Removes a warn from member.", inline = True).add_field(name = "`q!quarantine` `<member>`", value = "Quarantines the user", inline = True).add_field(name = "`q!unquarantine` `<member>`", value = "Unquarantines the user", inline = True).add_field(name = "`q!delete-spam-channels`", value = "Deletes spam channels", inline = True).add_field(name = "`q!delete-spam-roles`", value = "Deletes spam roles", inline = True))
        elif self.values[0] == "Adjustments":
          await interaction.response.edit_message(embed = nextcord.Embed(title = "~ Adjustments Commands",description ="", color = 0x2F3136).add_field(name = "`q!whitelist-add` `<member>`", value = "Adds a member to whitelist", inline = True).add_field(name = "`q!whitelist-remove` `<member>`", value = "Removes member from whitelist", inline = True).add_field(name = "`q!whitelist` `<member>`", value = "Shows the guild white-list", inline = True).add_field(name = "`q!antibot enable`", value = "Enables anti unverified bot system", inline = True).add_field(name = "`q!antibot disable`", value = "Disables anti unverified bot system", inline = True).add_field(name = "`q!roleprotect enable`", value = "Enables roleprotect system", inline = True).add_field(name = "`q!roleprotect disable`", value = "Disables roleprotect system", inline = True).add_field(name = "`q!reset-server`", value = "Sends a pannel to reset", inline = True))
        elif self.values[0] == "Music":
          await interaction.response.edit_message(embed = nextcord.Embed(title = "~ Music-Lvl Commands",description ="", color = 0x2F3136).add_field(name = "`q!play` `<song>`", value = "Plays a song", inline = True).add_field(name = "`q!queue`", value = "Shows the queue", inline = True).add_field(name = "`q!volume` `<volume>`", value = "Sets the volume", inline = True).add_field(name = "`q!splay` `<spotify song url>`", value = "Plays a spotify song", inline = True).add_field(name = "`q!pause`", value = "Pauses music", inline = True).add_field(name = "`q!resume`", value = "Resumes music", inline = True).add_field(name = "`q!skip`", value = "Skips music", inline = True).add_field(name = "`q!disconnect`", value = "Disconnects from vc", inline = True))
        elif self.values[0] == "Fun":
          await interaction.response.edit_message(embed = nextcord.Embed(title = "~ Fun Commands",description ="", color = 0x2F3136).add_field(name = "`q!kiss` `<member>`", value = "Sends a photo of kissing", inline = True).add_field(name = "`q!hug` `<member>`", value = "Sends a photo of hugging", inline = True).add_field(name = "`q!run` `<member>`", value = "Sends a photo of running", inline = True).add_field(name = "`q!punch` `<member>`", value = "Sends a photo of punching", inline = True).add_field(name = "`q!swim`", value = "Sends a photo of swimming", inline = True).add_field(name = "`q!sleep`", value = "Sends a photo of sleeping", inline = True).add_field(name = "`q!cry`", value = "Sends a photo of crying", inline = True).add_field(name = "`q!meme`", value = "Sends a meme", inline = True).add_field(name = "`q!rok`", value = "Sends a rok", inline = True).add_field(name = "`q!ben` `<question>`", value = "Ben answers", inline = True).add_field(name = "`q!8ball` `<question>`", value = "Ball answers", inline = True).add_field(name = "`q!roll` `<num1>` `<num2>`", value = "Rolls a number", inline = True))
        elif self.values[0] == "Other":
          await interaction.response.edit_message(embed = nextcord.Embed(title = "~ Other Commands",description ="", color = 0x2F3136).add_field(name = "`q!botinfo`", value = "Shows bot info", inline = True).add_field(name = "`q!ping`", value = "Shows bot ping", inline = True).add_field(name = "`q!user` `<member>`", value = "Shows user-info", inline = True).add_field(name = "`q!server`", value = "Shows server-info", inline = True).add_field(name = "`q!invites` `<member>`", value = "Shows member invites", inline = True).add_field(name = "`q!discrim` `<discriminator>`", value = "Shows members with the same discriminator (tag)", inline = True).add_field(name = "`q!server-protect-stats`", value = "Shows server protection level.", inline = True))

class UrlButton(nextcord.ui.Button):
    def __init__(self, *, label, url, emoji=None):
        super().__init__(label=label, url=url, emoji=emoji)


class SelectView(nextcord.ui.View):
    def __init__(self, *, timeout = 180):
        super().__init__(timeout=timeout)
        self.add_item(Select()) 
        self.add_item(UrlButton(label="Server", url="https://discord.gg/rx9YQg4c"))

  
@bot.group(invoke_without_command=True)
async def help(ctx):
  embed = nextcord.Embed(title = "", 
description = "**You can write `q!help` `<command>` - to get more info about command.**\n\n **— Utility**\n ```clear, eadd, short, avatar, embed, mock, reverse, add-roles, remove-roles, lock, unlock```\n **— Moderation**\n ```mute, umute, kick, ban, unban, complain, warn, remove-warn, quarantine, unquarantine, delete-spam-channels, delete-spam-roles```\n**— Adjustments**\n```whitelist-add, whitelist-remove, whitelist, antibot enable, antibot disable, roleprotect enable, roleprotect disable, reset-server```\n**— Music**\n ```play, queue, volume, splay, resume, pause, skip, disconnect```\n**— Fun**\n```kiss, hug, run, punch, swim, sleep, cry, meme, rok, ben, 8ball, roll```\n**— Other**\n ```botinfo, ping, user, server, invites, discrim, server-protect-stats```", color = 0x2F3136)
  embed.set_thumbnail(url="https://www.linkpicture.com/q/QueBot.png")
  await ctx.send(embed=embed, view = SelectView())

@help.command()
async def whitelist(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `white-list` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > It ignores the anticrash system for the member in white-list.\n**Parameters**\n> `add` `<user>`\n > `remove` `<user>`\n> `list`\n**Examples**\n> `q!whitelist add @Idk#0000`\n> `q!whitelist remove @Idk#0000`\n> `q!whitelist`", color = 0x2F3136))

@help.command(aliases=["reset-server"])
async def resetserver(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `reset-server` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Sends a panel with buttons, to reset-server.\n**Parameters**\n> `None`\n**Examples**\n> `q!reset-server`\n", color = 0x2F3136))


@help.command()
async def lock(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `lock` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Locks the channel, members can't write there.\n**Parameters**\n> `[Channel]`\n**Examples**\n> `q!lock`\n> `q!lock` `#channel`", color = 0x2F3136))

@help.command()
async def unlock(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `unlock` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Unlocks the channel, members can write there.\n**Parameters**\n> `[Channel]`\n**Examples**\n> `q!unlock`\n> `q!unlock` `#channel`", color = 0x2F3136))

@help.command()
async def quarantine(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `quarantine` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Quarantines the member, wich can't write anywhere.\n**Parameters**\n> `<user>`\n> `<user ID>`\n> `<name#disciminator>`\n> `<role>`\n**Examples**\n> `q!quarantine` `@Idk#0000`\n> `q!quarantine` `100000000000000000`\n> `q!quarantine` `Test#0000`\n> `q!quarantine` `@role`", color = 0x2F3136))

@help.command()
async def unquarantine(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `unquarantine` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Unquarantines the member, wich can write everywhere.\n**Parameters**\n> `<user>`\n> `<user ID>`\n> `<name#disciminator>`\n> `<role>`\n**Examples**\n> `q!unquarantine` `@Idk#0000`\n> `q!unquarantine` `100000000000000000`\n> `q!unquarantine` `Test#0000`\n> `q!unquarantine` `@role`", color = 0x2F3136))

@help.command(aliases=["add-roles"])
async def addroles(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `add-roles` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Adds roles to all members.\n**Parameters**\n> `<role>`\n**Examples**\n> `q!add-roles` `@role`", color = 0x2F3136))

@help.command(aliases=["remove-roles"])
async def removeroles(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `remove-roles` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Removes roles from all members.\n**Parameters**\n> `<role>`\n**Examples**\n> `q!remove-roles` `@role`", color = 0x2F3136))

@help.command()
async def clear(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About clear command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Purges the chat.\n**Parameters**\n> `[Amount]`\n**Examples**\n> `q!clear`\n> `q!clear` `100`", color = 0x2F3136))

@help.command(aliases=["emoji-add"])
async def eadd(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `eadd` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Adds an emoji.\n**Parameters**\n> `<url>`\n> `<name>`\n**Examples**\n> `q!eadd` `url` `name`\n", color = 0x2F3136))

@help.command(aliases=["short-url"])
async def short(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `short` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Shorts the url link.\n**Parameters**\n> `<url>`\n**Examples**\n> `q!short` `url`\n", color = 0x2F3136))

@help.command()
async def avatar(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `avatar` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Shows the person avatar.\n**Parameters**\n> `[member]`\n**Examples**\n> `q!avatar`\n> `q!avatar` `@test`", color = 0x2F3136))

@help.command(aliases=["post"])
async def embed(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `post` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Creates an embed.\n**Parameters**\n> `<title>`\n> `<description>`\n**Examples**\n> `q!embed` `Test-title` `Description, idk, lol`", color = 0x2F3136))

@help.command()
async def reverse(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `reverse` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Reverses the text.\n**Parameters**\n> `<text>`\n**Examples**\n> `q!reverse` `amogus`", color = 0x2F3136))

@help.command()
async def mute(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `mute` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Mutes a member.\n**Parameters**\n> `<Member>`\n> `<time>`\n> `[reason]`\n**Examples**\n> `q!mute` `@test#0000` `10d`\n> `q!mute` `@test#0000` `10d` `test`", color = 0x2F3136))

@help.command()
async def unmute(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `unmute` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Unmutes a member.\n**Parameters**\n> `<Member>`\n**Examples**\n> `q!unmute` `@test#0000`", color = 0x2F3136))

@help.command()
async def kick(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `kick` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Kicks a member.\n**Parameters**\n> `<Member>`\n> `[reason]`**Examples**\n> `q!kick` `@test#0000`\n> `q!kick` `@test#0000` `reason`", color = 0x2F3136))

@help.command()
async def ban(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About ban command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Bans a member.\n**Parameters**\n> `<Member>`\n> `[reason]`**Examples**\n> `q!ban` `@test#0000`\n> `q!ban` `@test#0000` `reason`", color = 0x2F3136))

@help.command()
async def unban(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `unban` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Unbans a member.\n**Parameters**\n> `<Member>`**Examples**\n> `q!unban` `@test#0000`", color = 0x2F3136))

@help.command()
async def complaint(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `complaint` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Sends a complaint on member.\n**Parameters**\n> `<Member>`\n> `<reason>`**Examples**\n> `q!complaint` `@test#0000` `idiot`", color = 0x2F3136))

@help.command()
async def play(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `play` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Plays music in voice channel.\n**Parameters**\n> `<song>`**Examples**\n> `q!play` `nggyu`", color = 0x2F3136))
  
@help.command()
async def queue(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `queue` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Shows the music queue.\n**Parameters**\n> `None`**Examples**\n> `q!queue`", color = 0x2F3136))

@help.command()
async def volume(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `volume` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Sets the music volume.\n**Parameters**\n> `<volume>`**Examples**\n> `q!volume` `100`", color = 0x2F3136))

@help.command(aliases=["spotify-play"])
async def splay(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `splay` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Plays spotify music.\n**Parameters**\n> `<url>`\n**Examples**\n> `q!splay` `spotify_url`", color = 0x2F3136))

@bot.command()
async def splay(ctx: commands.Context, *, search: str):
    if not ctx.voice_client:
            vc: wavelink.Player = await ctx.author.voice.channel.connect(cls=wavelink.Player)
    elif not getattr(ctx.author.voice, "channel", None):
        return await ctx.send(embed=nextcord.Embed(title = "Error", description = "<:no:993171433981227058> | Join a voice channel first, lol 🤣😂", color = nextcord.Color.red()))
    else:
        vc: wavelink.Player = ctx.voice_client
        
    if vc.queue.is_empty and not vc.is_playing():
        try:
            track = await spotify.SpotifyTrack.search(query=search, return_first=True)
            await vc.play(track)
            embed = nextcord.Embed(title=f"Music from - {vc.track.author} ", description=f"[{vc.track.title}]({str(vc.track.uri)})", color=0x2F3136)
            embed.add_field(name="Artist:", value = f"**`{vc.track.author}`**", inline = True)
            embed.add_field(name="Duration:", value = f"**`{str(datetime.timedelta(seconds=vc.track.length))}`**", inline = True)
            embed.set_footer(text=f"Music by Que") 
            embed.set_image(url = f"{vc.track.thumbnail}")
            await ctx.send(embed = embed, view = queueView())     
        except Exception as e:
            await ctx.send(embed=nextcord.Embed(title = "Error", description = "<:no:993171433981227058> | Please enter a spotify, son **url**", color = nextcord.Color.red()))
    else:
        await vc.queue.put_wait(search)
        await ctx.send(embed = nextcord.Embed(title = "Queue", description =f"Added to the queue!", color = 0x2F3136))
    vc.ctx = ctx
    try:
        if vc.loop: return
    except Exception:
        setattr(vc, "loop", False)


@help.command()
async def kiss(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `kiss` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Sends a funny kissing picture.\n**Parameters**\n> `<member>`\n**Examples**\n> `q!kiss` `@test#0000`", color = 0x2F3136))

@help.command()
async def hug(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `hug` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Sends a funny huging picture.\n**Parameters**\n> `<member>`\n**Examples**\n> `q!hug` `@test#0000`", color = 0x2F3136))

@help.command()
async def run(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `run` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Sends a funny running picture.\n**Parameters**\n> `<member>`\n**Examples**\n> `q!run` `@test#0000`", color = 0x2F3136))

@help.command()
async def punch(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `punch` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Sends a funny punching picture.\n**Parameters**\n> `<member>`\n**Examples**\n> `q!punch` `@test#0000`", color = 0x2F3136))


@help.command()
async def swim(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `swim` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Sends a funny swimming picture.\n**Parameters**\n> `None`\n**Examples**\n> `q!swim`", color = 0x2F3136))

@help.command()
async def sleep(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `sleep` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Sends a funny sleeping picture.\n**Parameters**\n> `None`\n**Examples**\n> `q!sleep`", color = 0x2F3136))

@help.command()
async def cry(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `cry` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Sends a funny crying picture.\n**Parameters**\n> `None`\n**Examples**\n> `q!cry`", color = 0x2F3136))
  
@help.command()
async def meme(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `meme` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Sends funny memes, and button controllers\n**Parameters**\n> `None`\n**Examples**\n> `q!meme", color = 0x2F3136))

@help.command(aliases=["rock"])
async def rok(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `rok` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Sends funny rok, and button controllers\n**Parameters**\n> `None`\n**Examples**\n> `q!rok", color = 0x2F3136))

@help.command()
async def ben(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `ben` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Ben answers the question\n**Parameters**\n> `<Question>`\n**Examples**\n> `q!ben` `Am I gay?`", color = 0x2F3136))

@help.command(aliases=["8ball"])
async def eightball(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `8ball` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > 8ball answers the question\n**Parameters**\n> `<Question>`\n**Examples**\n> `q!8ball` `Is this bot good?`", color = 0x2F3136))

@help.command()
async def roll(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `roll` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Roll a random number\n**Parameters**\n> `<first_number>`\n> `<second_number>`\n**Examples**\n> `q!roll` `1` `2`", color = 0x2F3136))

@help.command()
async def botinfo(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `botinfo` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Shows the bot information.\n**Parameters**\n> `None`\n**Examples**\n> `q!botinfo`", color = 0x2F3136))

@help.command()
async def ping(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `ping` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Shows the bot ping.\n**Parameters**\n> `None`\n**Examples**\n> `q!ping`", color = 0x2F3136))

@help.command(aliases=["user-info"])
async def user(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `user` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Shows the user information.\n**Parameters**\n> `[Member]`\n**Examples**\n> `q!user`\n> `q!user` `@test#0000`", color = 0x2F3136))

@help.command(aliases=["server-info"])
async def server(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `server-info` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Shows the server information.\n**Parameters**\n> `None`\n**Examples**\n> `q!server`", color = 0x2F3136))

@help.command()
async def invites(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `invites` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Shows the member invites on the server.\n**Parameters**\n> `<Member>`\n**Examples**\n> `q!invites` `@test#0000`", color = 0x2F3136))

@help.command()
async def discrim(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `discrim` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Shows members with the same discrim.\n**Parameters**\n> `<discriminator>`\n**Examples**\n> `q!discrim` `0001`", color = 0x2F3136))


@help.command(aliases=["antibot-enbale","antibot-disable"])
async def antibot(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `antibot` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Toggles the anti unverified bot system.\n**Parameters**\n> `<enbale>`\n> `<disable>`\n**Examples**\n> `q!antibot` `enable`\n> `q!antibot` `disable`", color = 0x2F3136))

@help.command(aliases=["roleprotect-enbale","roleprotect-disable"])
async def roleprotect(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `roleprotect` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Toggles the roleprotect system.\n**Parameters**\n> `<enbale>`\n> `<disable>`\n**Examples**\n> `q!roleprotect` `enable`\n> `q!roleprotect` `disable`", color = 0x2F3136))


@bot.command()
@commands.cooldown(1, 5, commands.BucketType.user)
async def test(ctx):
  pass

@bot.group()
async def antibot(ctx):
  pass

@antibot.command()
async def enable(ctx):
  async with bot.db.cursor() as cursor:
    await cursor.execute("SELECT botssys FROM bots WHERE guild = ?", (ctx.guild.id,))
    botssys = await cursor.fetchone()
    if botssys:
      if botssys[0]:
        return await ctx.send(embed = nextcord.Embed(title = "Hmmmmm", description = "Anti unverified-bot system is already `Enabled` on this server!", color = 0x2F3136))
      await cursor.execute("UPDATE bots SET botssys = ? WHERE guild = ?", (True, ctx.guild.id,))
    else:
      await cursor.execute("INSERT INTO bots VALUES (?, ?, ?)", (True, 0, ctx.guild.id,))
      await ctx.send(embed = nextcord.Embed(title = "Success", description = "Anti unverified-bot system is now `Enabled`", color = 0x2F3136))

@antibot.command()
async def disable(ctx):
  async with bot.db.cursor() as cursor:
    await cursor.execute("SELECT botssys FROM bots WHERE guild = ?", (ctx.guild.id,))
    botssys = await cursor.fetchone()
    if botssys:
      if not botssys[0]:
        return await ctx.send(embed = nextcord.Embed(title = "Hmmmmm", description = "Anti unverified-bot system is already `Disabled` on this server!", color = 0x2F3136))
      await cursor.execute("UPDATE bots SET botssys = ? WHERE guild = ?", (False, ctx.guild.id,))
    else:
      await cursor.execute("INSERT INTO bots VALUES (?, ?, ?)", (False, 0, ctx.guild.id,))
      await ctx.send(embed = nextcord.Embed(title = "Success", description = "Anti unverified-bot system is now `Disabled`", color = 0x2F3136))

@bot.slash_command(description="Antibot System")
async def antibot(interaction: Interaction):
    pass

@antibot.subcommand(description = "Enable the antibot system")
async def enable(interaction: Interaction):
  async with bot.db.cursor() as cursor:
    await cursor.execute("SELECT botssys FROM bots WHERE guild = ?", (interaction.guild.id,))
    botssys = await cursor.fetchone()
    if botssys:
      if botssys[0]:
        return await interaction.send(embed = nextcord.Embed(title = "Hmmmmm", description = "Anti unverified-bot system is already `Enabled` on this server!", color = 0x2F3136))
      await cursor.execute("UPDATE bots SET botssys = ? WHERE guild = ?", (True, interaction.guild.id,))
    else:
      await cursor.execute("INSERT INTO bots VALUES (?, ?, ?)", (True, 0, interaction.guild.id,))
      await interaction.send(embed = nextcord.Embed(title = "Success", description = "Anti unverified-bot system is now `Enabled`", color = 0x2F3136))

@antibot.subcommand(description = "Disable the antibot system")
async def disable(interaction: Interaction):
  async with bot.db.cursor() as cursor:
    await cursor.execute("SELECT botssys FROM bots WHERE guild = ?", (interaction.guild.id,))
    botssys = await cursor.fetchone()
    if botssys:
      if not botssys[0]:
        return await interaction.send(embed = nextcord.Embed(title = "Hmmmmm", description = "Anti unverified-bot system is already `Disabled` on this server!", color = 0x2F3136))
      await cursor.execute("UPDATE bots SET botssys = ? WHERE guild = ?", (False, interaction.guild.id,))
    else:
      await cursor.execute("INSERT INTO bots VALUES (?, ?, ?)", (False, 0, interaction.guild.id,))
      await interaction.send(embed = nextcord.Embed(title = "Success", description = "Anti unverified-bot system is now `Disabled`", color = 0x2F3136))


@bot.group()
@commands.has_permissions(administrator=True)
async def roleprotect(ctx):
  pass

@roleprotect.command()
@commands.has_permissions(administrator=True)
async def enable(ctx):
  async with bot.db.cursor() as cursor:
    await cursor.execute("SELECT rolesys FROM roleprotect WHERE guild = ?", (ctx.guild.id,))
    rolesys = await cursor.fetchone()
    if rolesys:
      if rolesys[0]:
        return await ctx.send(embed = nextcord.Embed(title = "Hmmmmm", description = "Role-protection is already `Enabled` on this server!", color = 0x2F3136))
      await cursor.execute("UPDATE roleprotect SET rolesys = ? WHERE guild = ?", (True, ctx.guild.id,))
    else:
      await cursor.execute("INSERT INTO roleprotect VALUES (?, ?, ?)", (True, 0, ctx.guild.id,))
      await ctx.send(embed = nextcord.Embed(title = "Success", description = "Role-protection is now `Enabled`", color = 0x2F3136))

@roleprotect.command()
@commands.has_permissions(administrator=True)
async def disable(ctx):
  async with bot.db.cursor() as cursor:
    await cursor.execute("SELECT rolesys FROM roleprotect WHERE guild = ?", (ctx.guild.id,))
    rolesys = await cursor.fetchone()
    if rolesys:
      if not rolesys[0]:
        return await ctx.send(embed = nextcord.Embed(title = "Hmmmmm", description = "Role-protection is already `Disabled` on this server!", color = 0x2F3136))
      await cursor.execute("UPDATE roleprotect SET rolesys = ? WHERE guild = ?", (False, ctx.guild.id,))
    else:
      await cursor.execute("INSERT INTO roleprotect VALUES (?, ?, ?)", (False, 0, ctx.guild.id,))
      await ctx.send(embed = nextcord.Embed(title = "Success", description = "Role-protection is now `Disabled`", color = 0x2F3136))

@bot.slash_command(description="Roleprotect System")
@application_checks.has_permissions(administrator=True)
async def roleprotect(interaction: Interaction):
    pass

@roleprotect.subcommand(description = "Enable the roleprotect system")
@application_checks.has_permissions(administrator=True)
async def enable(interaction: Interaction):
  async with bot.db.cursor() as cursor:
    await cursor.execute("SELECT rolesys FROM roleprotect WHERE guild = ?", (interaction.guild.id,))
    rolesys = await cursor.fetchone()
    if rolesys:
      if rolesys[0]:
        return await interaction.send(embed = nextcord.Embed(title = "Hmmmmm", description = "Role-protection is already `Enabled` on this server!", color = 0x2F3136))
      await cursor.execute("UPDATE roleprotect SET rolesys = ? WHERE guild = ?", (True, interaction.guild.id,))
    else:
      await cursor.execute("INSERT INTO roleprotect VALUES (?, ?, ?)", (True, 0, interaction.guild.id,))
      await interaction.send(embed = nextcord.Embed(title = "Success", description = "Role-protection is now `Enabled`", color = 0x2F3136))

@roleprotect.subcommand(description = "Disable the roleprotect system")
@application_checks.has_permissions(administrator=True)
async def disable(interaction: Interaction):
  async with bot.db.cursor() as cursor:
    await cursor.execute("SELECT rolesys FROM roleprotect WHERE guild = ?", (interaction.guild.id,))
    rolesys = await cursor.fetchone()
    if rolesys:
      if not rolesys[0]:
        return await interaction.send(embed = nextcord.Embed(title = "Hmmmmm", description = "Role-protection is already `Disabled` on this server!", color = 0x2F3136))
      await cursor.execute("UPDATE roleprotect SET rolesys = ? WHERE guild = ?", (False, interaction.guild.id,))
    else:
      await cursor.execute("INSERT INTO roleprotect VALUES (?, ?, ?)", (False, 0, interaction.guild.id,))
      await interaction.send(embed = nextcord.Embed(title = "Success", description = "Role-protection is now `Disabled`", color = 0x2F3136))


from collections import Counter

@bot.command(aliases=["delete-spam-channels"])
@commands.has_permissions(manage_messages = True)
async def delspamchannels(ctx):
  names = [x.name for x in ctx.guild.channels]
  ct = Counter(names)
  dups = list(filter(lambda x: x[1] != 1, ct.items()))
  for name, count in dups:
    if count > 1:
      for channel in range(count - 1):
        for channel in ctx.guild.channels:
          if channel.name == name:
            await channel.delete()
  await ctx.send(embed=nextcord.Embed(title="Success", description = "<:yes:993171492563079260> | I'll delete all the duplicated channels, **wait a bit.**", color = 0x2F3136))

@bot.command(aliases=["delete-spam-roles"])
@commands.has_permissions(manage_messages = True)
async def delspamroles(ctx):
  names = [x.name for x in ctx.guild.roles]
  ct = Counter(names)
  dups = list(filter(lambda x: x[1] != 1, ct.items()))
  for name, count in dups:
    if count > 1:
      for role in range(count - 1):
        for role in ctx.guild.roles:
          if role.name == name:
            await role.delete()
  await ctx.send(embed=nextcord.Embed(title="Success", description = "<:yes:993171492563079260> | I'll delete all the duplicated roles, **wait a bit.**", color = 0x2F3136))

@bot.slash_command(name="delete-spam-channels", description = "Deletes all the duplicated channels")
@application_checks.has_permissions(manage_messages=True)
async def delspamchannels(interaction: Interaction):
  names = [x.name for x in interaction.guild.channels]
  ct = Counter(names)
  dups = list(filter(lambda x: x[1] != 1, ct.items()))
  for name, count in dups:
    if count > 1:
      for channel in range(count - 1):
        for channel in interaction.guild.channels:
          if channel.name == name:
            await channel.delete()
  await interaction.send(embed=nextcord.Embed(title="Success", description = "<:yes:993171492563079260> | I'll delete all the duplicated channels, **wait a bit.**", color = 0x2F3136))

@bot.slash_command(name="delete-spam-roles", description = "Deletes all the duplicated roles")
@application_checks.has_permissions(manage_messages=True)
async def delspamroles(interaction: Interaction):
  names = [x.name for x in interaction.guild.roles]
  ct = Counter(names)
  dups = list(filter(lambda x: x[1] != 1, ct.items()))
  for name, count in dups:
    if count > 1:
      for role in range(count - 1):
        for role in interaction.guild.roles:
          if role.name == name:
            await role.delete()
  await interaction.send(embed=nextcord.Embed(title="Success", description = "<:yes:993171492563079260> | I'll delete all the duplicated roles, **wait a bit.**", color = 0x2F3136))

@bot.command(aliases=["add-warn"])
@commands.has_permissions(administrator=True)
async def warn(ctx: commands.Context, member: nextcord.Member, *, reason: str = "No reason provided"):
  await addwarn(ctx, reason, member)
  await ctx.send(embed=nextcord.Embed(title=f"<:yes:993171492563079260> | {member} has been warned.", description = f"**Member:** {member.mention}\n **Reason:** {reason}\n MOD: {ctx.author.mention}", color = 0x2F3136))

@bot.slash_command(description="Adds a warn to a member")
@application_checks.has_permissions(administrator=True)
async def warn(interaction: Interaction, member: nextcord.Member, *, reason: str = "No reason provided"):
  await addwarn(interaction, reason, member)
  await interaction.send(embed=nextcord.Embed(title=f"<:yes:993171492563079260> | {member} has been warned.", description = f"**Member:** {member.mention}\n **Reason:** {reason}\n MOD: {interaction.user.mention}", color = 0x2F3136))


@bot.slash_command(name="remove-warn", description = "Removes warns from a member")
@application_checks.has_permissions(administrator=True)
async def removewarn(interaction: Interaction, member: nextcord.Member):
  async with bot.db.cursor() as cursor:
    await cursor.execute("SELECT reason FROM warns WHERE user = ? AND guild = ?", (member.id, interaction.guild.id))
    data = await cursor.fetchone()
    if data:
      await cursor.execute("DELETE FROM warns WHERE user = ? AND guild = ?", (member.id, interaction.guild.id))
      await interaction.send(embed=nextcord.Embed(title=f"<:yes:993171492563079260> | {member} removed warn.", description = f"**Member:** {member.mention}\n MOD: {interaction.user.mention}", color = 0x2F3136))
    await interaction.send(embed=nextcord.Embed(title=f"<:no:993171433981227058> | No warnings found.", description = f"", color = 0x2F3136))
  await bot.db.commit()

@bot.command(aliases=["remove-warn"])
@commands.has_permissions(administrator=True)
async def removewarn(ctx: commands.Context, member: nextcord.Member):
  async with bot.db.cursor() as cursor:
    await cursor.execute("SELECT reason FROM warns WHERE user = ? AND guild = ?", (member.id, ctx.guild.id))
    data = await cursor.fetchone()
    if data:
      await cursor.execute("DELETE FROM warns WHERE user = ? AND guild = ?", (member.id, ctx.guild.id))
      await ctx.send(embed=nextcord.Embed(title=f"<:yes:993171492563079260> | {member} removed warn.", description = f"**Member:** {member.mention}\n MOD: {ctx.author.mention}", color = 0x2F3136))
    await ctx.send(embed=nextcord.Embed(title=f"<:no:993171433981227058> | No warnings found.", description = f"", color = 0x2F3136))
  await bot.db.commit()

@bot.command()
@commands.has_permissions(administrator=True)
async def warns(ctx, member: nextcord.Member):
  async with bot.db.cursor() as cursor:
    await cursor.execute("SELECT reason, time FROM warns WHERE user = ? AND guild = ?", (member.id, ctx.guild.id))
    data = await cursor.fetchall()
    if data:
      embed = nextcord.Embed(title = f"{member} Warnings", color = 0x2F3136)
      warnum = 0
      for table in data:
        warnum +=1
        embed.add_field(name=f"Warning #{warnum}", value = f"Reason {table[0]} | Date Issued: <t:{int(table[1])}:F>")
      await ctx.send(embed = embed)
    else:
      await ctx.send(embed=nextcord.Embed(title=f"<:no:993171433981227058> | No warnings found.", description = f"", color = 0x2F3136))
  await bot.db.commit()

@bot.slash_command()
@application_checks.has_permissions(administrator=True)
async def warns(interaction: Interaction, member: nextcord.Member):
  async with bot.db.cursor() as cursor:
    await cursor.execute("SELECT reason, time FROM warns WHERE user = ? AND guild = ?", (member.id, interaction.guild.id))
    data = await cursor.fetchall()
    if data:
      embed = nextcord.Embed(title = f"{member} Warnings", color = 0x2F3136)
      warnum = 0
      for table in data:
        warnum +=1
        embed.add_field(name=f"Warning #{warnum}", value = f"Reason {table[0]} | Date Issued: <t:{int(table[1])}:F>")
      await interaction.send(embed = embed)
    else:
      await interaction.send(embed=nextcord.Embed(title=f"<:no:993171433981227058> | No warnings found.", description = f"", color = 0x2F3136))
  await bot.db.commit()

@help.command()
async def warn(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `warn` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Warns a member.\n**Parameters**\n> `<user>`\n > `[reason]`\n**Examples**\n> `q!warn` `@Idk#0000`\n> `q!warn` `@Idk#0000` `dumb`", color = 0x2F3136))

@help.command(aliases=["remove-warn"])
async def removewarn(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `remove-warn` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Removes warns from a member.\n**Parameters**\n> `<user>`\n**Examples**\n> `q!remove-warn` `@Idk#0000`", color = 0x2F3136))

@help.command()
async def warns(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `warns` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Shows the user warns.\n**Parameters**\n> `<user>`\n**Examples**\n> `q!remove-warn` `@Idk#0000`", color = 0x2F3136))


@help.command(aliases=["delete-spam-channels"])
async def delspamchannels(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `delete-spam-channels` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Deletes all the duplicated channels.\n**Parameters**\n> `None`\n**Examples**\n> `q!delete-spam-channels`", color = 0x2F3136))

@help.command(aliases=["delete-spam-roles"])
async def delspamcroles(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `delete-spam-roles` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Deletes all the duplicated roles.\n**Parameters**\n> `None`\n**Examples**\n> `q!delete-spam-roles`", color = 0x2F3136))

@help.command(aliases=["server-protect-stats"])
async def serverprotectstats(ctx):
  await ctx.send(embed=nextcord.Embed(title="❔ | About `server-protect-stats` command", description = f"`<required parameter>` `[optional parameter]`\nDo not use brackets, when invoking the command\n\n **What does it do?**\n > Shows the server protect stats/info.\n**Parameters**\n> `None`\n**Examples**\n> `q!server-protect-stats`", color = 0x2F3136))
    
@bot.command()
async def pause(ctx: commands.Context):
    if not ctx.voice_client:
     return await ctx.send(embed = nextcord.Embed(title="<:no:993171433981227058> | I'm not even in vc, lol", color = nextcord.Color.red()))
    elif not getattr(ctx.author.voice, "channel", None):
        return await ctx.send(embed = nextcord.Embed(title="<:no:993171433981227058> | Join a voice channel first, lol", color = nextcord.Color.red()))
    else:
        vc: wavelink.Player = ctx.voice_client
    if not vc.is_playing():
        return await ctx.send(embed = nextcord.Embed(title="<:no:993171433981227058> | Play some music first, lol", color = nextcord.Color.red()))

    await vc.pause()
    await ctx.send(embed = nextcord.Embed(title="<:yes:993171492563079260> | Music is now paused", color = 0x2F3136), view = queueView())
    
@bot.command()
async def resume(ctx: commands.Context):
    if not ctx.voice_client:
      return await ctx.send(embed = nextcord.Embed(title="<:no:993171433981227058> | I'm not even in vc, lol", color = nextcord.Color.red()))
    elif not getattr(ctx.author.voice, "channel", None):
      return await ctx.send(embed = nextcord.Embed(title="<:no:993171433981227058> | Join a voice channel first, lol", color = nextcord.Color.red()))
    else:
        vc: wavelink.Player = ctx.voice_client
    if vc.is_playing():
      return await ctx.send(embed = nextcord.Embed(title="<:no:993171433981227058> | Music is already playing, lol", color = nextcord.Color.red()))

    await vc.resume()
    return await ctx.send(embed = nextcord.Embed(title="<:yes:993171492563079260> | Music is now resumed", color = 0x2F3136), view = queueView())
    
@bot.command()
async def skip(ctx: commands.Context):
    if not ctx.voice_client:
        return await ctx.send(embed = nextcord.Embed(title="<:no:993171433981227058> | I'm not even in vc, lol", color = nextcord.Color.red()))
    elif not getattr(ctx.author.voice, "channel", None):
        return await ctx.send(embed = nextcord.Embed(title="<:no:993171433981227058> | Join a voice channel first, lol", color = nextcord.Color.red()))
    else:
        vc: wavelink.Player = ctx.voice_client
    if not vc.is_playing():
        return await ctx.send(embed = nextcord.Embed(title="<:no:993171433981227058> | Play some music first, lol", color = nextcord.Color.red()))
    
    try:
        next_song = vc.queue.get()
        await vc.play(next_song)
        embed = nextcord.Embed(title=f"Music from - {vc.track.author} ", description=f"[{vc.track.title}]({str(vc.track.uri)})", color=0x2F3136)
        embed.add_field(name="Artist:", value = f"**`{vc.track.author}`**", inline = True)
        embed.add_field(name="Duration:", value = f"**`{str(datetime.timedelta(seconds=vc.track.length))}`**", inline = True)
        embed.set_footer(text=f"Music by Que") 
        embed.set_image(url = f"{vc.track.thumbnail}")
        await ctx.send(embed = embed, view = queueView())      
    except Exception:
        return await ctx.send(embed = nextcord.Embed(title="<:no:993171433981227058> | Que is empty. Play some music, or I'll leave when this song ends.", color = nextcord.Color.red()))
    
    await vc.stop()
    
@bot.command()
async def disconnect(ctx: commands.Context):
    if not ctx.voice_client:
        return await ctx.send(embed = nextcord.Embed(title="<:no:993171433981227058> | I'm not even in vc, lol", color = nextcord.Color.red()))
    elif not getattr(ctx.author.voice, "channel", None):
        return await ctx.send(embed = nextcord.Embed(title="<:no:993171433981227058> | Join a voice channel first, lol", color = nextcord.Color.red()))
    else:
        vc: wavelink.Player = ctx.voice_client
    
    await vc.disconnect()
    return await ctx.send(embed = nextcord.Embed(title="<:yes:993171492563079260> | I have left teh channel.", color = 0x2F3136))

@bot.slash_command(description = "Pauses music")
async def pause(interaction: Interaction):
    if not interaction.guild.voice_client:
     return await interaction.send(embed = nextcord.Embed(title="<:no:993171433981227058> | I'm not even in vc, lol", color = nextcord.Color.red()))
    elif not getattr(interaction.user.voice, "channel", None):
        return await interaction.send(embed = nextcord.Embed(title="<:no:993171433981227058> | Join a voice channel first, lol", color = nextcord.Color.red()))
    else:
        vc: wavelink.Player = interaction.guild.voice_client
    if not vc.is_playing():
        return await interaction.send(embed = nextcord.Embed(title="<:no:993171433981227058> | Play some music first, lol", color = nextcord.Color.red()))

    await vc.pause()
    await interaction.send(embed = nextcord.Embed(title="<:yes:993171492563079260> | Music is now paused", color = 0x2F3136), view = queueView())
    
@bot.slash_command(description = "Resumes music")
async def resume(interaction: Interaction):
    if not interaction.guild.voice_client:
      return await interaction.send(embed = nextcord.Embed(title="<:no:993171433981227058> | I'm not even in vc, lol", color = nextcord.Color.red()))
    elif not getattr(interaction.user.voice, "channel", None):
      return await interaction.send(embed = nextcord.Embed(title="<:no:993171433981227058> | Join a voice channel first, lol", color = nextcord.Color.red()))
    else:
        vc: wavelink.Player = interaction.guild.voice_client
    if vc.is_playing():
      return await interaction.send(embed = nextcord.Embed(title="<:no:993171433981227058> | Music is already playing, lol", color = nextcord.Color.red()))

    await vc.resume()
    return await interaction.send(embed = nextcord.Embed(title="<:yes:993171492563079260> | Music is now resumed", color = 0x2F3136), view = queueView())
    
@bot.slash_command(description = "Skips music")
async def skip(interaction: Interaction):
    if not interaction.guild.voice_client:
        return await interaction.send(embed = nextcord.Embed(title="<:no:993171433981227058> | I'm not even in vc, lol", color = nextcord.Color.red()))
    elif not getattr(interaction.user.voice, "channel", None):
        return await interaction.send(embed = nextcord.Embed(title="<:no:993171433981227058> | Join a voice channel first, lol", color = nextcord.Color.red()))
    else:
        vc: wavelink.Player = interaction.guild.voice_client
    if not vc.is_playing():
        return await interaction.send(embed = nextcord.Embed(title="<:no:993171433981227058> | Play some music first, lol", color = nextcord.Color.red()))
    
    try:
        next_song = vc.queue.get()
        await vc.play(next_song)
        embed = nextcord.Embed(title=f"Music from - {vc.track.author} ", description=f"[{vc.track.title}]({str(vc.track.uri)})", color=0x2F3136)
        embed.add_field(name="Artist:", value = f"**`{vc.track.author}`**", inline = True)
        embed.add_field(name="Duration:", value = f"**`{str(datetime.timedelta(seconds=vc.track.length))}`**", inline = True)
        embed.set_footer(text=f"Music by Que") 
        embed.set_image(url = f"{vc.track.thumbnail}")
        await interaction.send(embed = embed, view = queueView())      
    except Exception:
        return await interaction.send(embed = nextcord.Embed(title="<:no:993171433981227058> | Que is empty. Play some music, or I'll leave when this song ends.", color = nextcord.Color.red()))
    
    await vc.stop()
    
@bot.slash_command(description = "Disconnects from a vc")
async def disconnect(interaction: Interaction):
    if not interaction.guild.voice_client:
        return await interaction.send(embed = nextcord.Embed(title="<:no:993171433981227058> | I'm not even in vc, lol", color = nextcord.Color.red()))
    elif not getattr(interaction.user.voice, "channel", None):
        return await interaction.send(embed = nextcord.Embed(title="<:no:993171433981227058> | Join a voice channel first, lol", color = nextcord.Color.red()))
    else:
        vc: wavelink.Player = interaction.guild.voice_client
    
    await vc.disconnect()
    return await interaction.send(embed = nextcord.Embed(title="<:yes:993171492563079260> | I have left teh channel.", color = 0x2F3136))


@bot.command(aliases=["server-protect-stats"])
async def serverprotectstats(ctx):
  async with bot.db.cursor() as cursor:
    w = []
    await cursor.execute("SELECT user FROM whitelist WHERE guild = ?", (ctx.guild.id,))
    user = await cursor.fetchone()
    if user:
      w.append(1)
    await cursor.execute("SELECT rolesys FROM roleprotect WHERE guild = ?", (ctx.guild.id,))
    rolesys = await cursor.fetchone()
    if rolesys:
      if rolesys[0]:
        r = "<:yes:993171492563079260> | Enabled"
      else:
        r = "<:no:993171433981227058> | Disabled"
    await cursor.execute("SELECT botssys FROM bots WHERE guild = ?", (ctx.guild.id,))
    botssys = await cursor.fetchone()
    if botssys:
      if botssys[0]:
        b = "<:yes:993171492563079260> | Enabled"
      else:
        b = "<:no:993171433981227058> | Disabled"

  await ctx.send(embed=nextcord.Embed(title = "Server Protection Stats", description = f"Whitelisted members: **{len(w)}**\n Role Protection: **{r}**\n Anti Bot System: **{b}**", color = 0x2F3136))


webserver.keep_alive()
bot.run(config.BOT_TOKEN)
  
