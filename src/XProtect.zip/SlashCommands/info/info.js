const { Client, MessageEmbed, MessageButton, CommandInteraction } = require("discord.js");
module.exports = {
  name: "info",
  description: "Инфо о боте",
  type: "CHAT_INPUT",
  run: async (client, interaction, args) => {
    const info = new MessageEmbed()
      .setColor("ffffff")
      .setDescription(`:desktop: | Обзор настроек сервера***\n﹒*:bar_chart: | Статус анти краш защиты*: ${status}\n﹒*:unlock: | Пользователей в белом списке*: ${amount.length}\n﹒*:wave: | Добро пожаловать канал*: ${channel}\n﹒*:superhero: | Авто-роль*: ${role}\n\n***:chart_with_upwards_trend: | Статистика бота***\n﹒*Всего серверов*: ${servers}\n﹒*Всего пользователей*: ${users}\n﹒*Задержка бота*:  ${mss}ms\nПинг бота: ${client.ws.ping}ms\n\n***:man_technologist: | Разработчики бота***\n﹒*Код написал*:Drukindn#1223 , YAZEGUS#7777 \n Так-же советуем вам прописать h.enable если анти-краш не включен \n﹒*:heavy_plus_sign: | Discord сервер`)

    interaction.followUp({ embeds: [info], ephemeral: true });
  },
};