const { Client, MessageEmbed, MessageButton, CommandInteraction } = require("discord.js");
module.exports = {
  name: "invite",
  description: "Помощь",
  type: "CHAT_INPUT",
  run: async (client, interaction, args) => {
    const invite = new MessageEmbed()
      .setColor("ffffff")
      .setDescription(`https://discord.com/api/oauth2/authorize?client_id=977546369847926784&permissions=8&scope=bot`)

    interaction.followUp({ embeds: [invite], ephemeral: true });
  },
};