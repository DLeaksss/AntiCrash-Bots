const { Client, MessageEmbed, MessageButton, CommandInteraction } = require("discord.js");
module.exports = {
  name: "enable",
  description: "Включить защиту ",
  type: "CHAT_INPUT",
  run: async (client, interaction, args) => {
    const enable = new MessageEmbed()
      .setColor("ffffff")
      .setDescription(` Анти краш был включен. Ваш сервер в безопасности 
лучше ещё пропишите h.enable :shield:`)

    interaction.followUp({ embeds: [enable], ephemeral: true });
  },
};