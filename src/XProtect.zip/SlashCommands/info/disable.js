const { Client, MessageEmbed, MessageButton, CommandInteraction } = require("discord.js");
module.exports = {
  name: "disable",
  description: "отключить защиту",
  type: "CHAT_INPUT",
  run: async (client, interaction, args) => {
    const disable = new MessageEmbed()
      .setColor("ffffff")
      .setDescription(`Анти краш был отключен. Если вы передумали, то скорее напишите h.enable`)

    interaction.followUp({ embeds: [disable], ephemeral: true });
  },
};