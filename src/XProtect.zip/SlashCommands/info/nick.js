const { Client, MessageEmbed, MessageButton, CommandInteraction } = require("discord.js");
module.exports = {
  name: "nick",
  description: "поменять ник",
  type: "CHAT_INPUT",
  run: async (client, interaction, args) => {
    const nick = new MessageEmbed()
    const nickname = args[0];
    if (!message.member.permissions.has("MANAGE_MEMBERS")) {
      message.channel.send({ content: `*${message.author.username}*, Тебе нельзя :) Тебе нужны права **управление участниками**`});
    } else {
      const member = message.mentions.members.first();
      if (!member) {
        message.channel.send({ content: ` укажите участника которому хотите изменить ник`});
      } 
      if (!member.manageable) {
        message.channel.send({ content: `у меня нет доступа :C` });
      } else {
        if (!nickname) {
          message.channel.send({ content: `Предоставьте мне ник.` });
        } else {
        member.setNickname(`${nickname}`);
        message.channel.send({ content: `Успех! Ник изменен на *${nickname}*.`});
        }
      }
    }
  },
};