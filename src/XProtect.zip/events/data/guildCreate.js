const { MessageEmbed } = require("discord.js");
const client = require('../../index');
const chalk = require("chalk");
const Database = require("@replit/database");
const db = new Database();
const { bot } = require('../../files/settings.js');
const prefix = bot.prefix;

const Settings = require('../../files/settings');
const isPrivate = Settings.options.privateMode;

client.on("guildCreate", async (guild) => {
  if (isPrivate === true) {
    let allowed = await db.get(`allowed ${guild.id}`);
    if (allowed !== true) {
      await guild.leave();
      console.log(`${chalk.cyanBright(`{!} :: Left Guild : ${guild.name}`)}\n${chalk.yellowBright(`{!} :: The Guild Was'nt Whitelisted.\n`)}`)
    }
  } else {
    console.log(`${chalk.cyanBright(`{!} :: Joined Guild : ${guild.name}`)}\n${chalk.red(`{!} :: Antinuke Isn't Enabled There.\n`)}`);
    const intro = new MessageEmbed()
      .setColor("ffffff")
      .setFooter({ text: `Префикс: ${prefix} `})
      .setDescription(`Привет, спасибо тебе что именно ты добавил меня, во мне много окманд. Кстати что-бы краша не произошло надо сделать кое-что, сейчас скажу что:
1. Пропишите hp.enable
2. Поставьте мою роль как выше что-бы я смог забанить крашера.
3. Сделайте так что-бы у меня были права администратора. \n **Discord сервер: [Вступить](https://discord.gg/ypNnuQduwa)**`)
    
    const channel = guild.channels.cache.find(channel => 
      channel.type == "GUILD_TEXT" &&
      channel.permissionsFor(guild.me).has("SEND_MESSAGES")
      );
    if (channel) {
      channel.send({ embeds: [intro ] });
    }
  }
});