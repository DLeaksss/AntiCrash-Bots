const { Client, MessageEmbed } = require('discord.js');
const client = require('../index');

module.exports = {
  Embeds: function (event, guild, executor, target, punishment) {
    if (event === "Channel Creation") {
      return new MessageEmbed()
        .setDescription(`**__:rotating_light: | ДЕЙСТВИЕ ЗАПРЕЩЕНО!__**\n\n﹒Сервер: **${guild}**\n﹒Действие: **${event}**\n\n**__:fire: | ДЕТАЛИ СОБЫТИЙ:__**\n\n﹒Нарушитель: **${executor}**\n﹒Канал: **${target}**\n﹒Наказание: **${punishment}**`)
        .setColor("02fa23")
    } else if (event === "Channel Deletion") {
      return new MessageEmbed()
        .setDescription(`***__:rotating_light: | ДЕЙСТВИЕ ЗАПРЕЩЕНО!__***\n\n﹒Сервер: **${guild}**\n﹒Действие: **${event}**\n\n***__:fire: | ДЕТАЛИ СОБЫТИЙ:__***\n\n﹒Нарушитель: **${executor}**\n﹒Канал: **${target}**\n﹒Наказание: **${punishment}**`)
        .setColor("02fa23")
    } else if (event === "Role Creation") {
      return new MessageEmbed()
        .setDescription(`***__:rotating_light: | ДЕЙСТВИЕ ЗАПРЕЩЕНО!__***\n\n﹒Сервер: **${guild}**\n﹒Действие: **${event}**\n\n***__:fire: | ДЕТАЛИ СОБЫТИЙ:__***\n\n﹒Нарушитель: **${executor}**\n﹒Роль: **${target}**\n﹒Наказание: **${punishment}**`)
        .setColor("02fa23")
    } else if (event === "Role Deletion") {
      return new MessageEmbed()
        .setDescription(`***__:rotating_light: | ДЕЙСТВИЕ ЗАПРЕЩЕНО!__***\n\n﹒Сервер: **${guild}**\n﹒Действие: **${event}**\n\n***__:fire: | ДЕТАЛИ СОБЫТИЙ:__***\n\n﹒Нарушитель: **${executor}**\n﹒Роль: **${target}**\n﹒Наказание: **${punishment}**`)
        .setColor("ffffff")
    } else if (event === "Member Kick") {
      return new MessageEmbed()
        .setDescription(`***__:rotating_light: | ДЕЙСТВИЕ ЗАПРЕЩЕНО!__***\n\n﹒Сервер: **${guild}**\n﹒Действие: **${event}**\n\n***__:fire: | ДЕТАЛИ СОБЫТИЙ:__***\n\n﹒Нарушитель: **${executor}**\n﹒Жертва: **${target}**\n﹒Наказание: **${punishment}**`)
        .setColor("ffffff")
    } else if (event === "Member Ban") {
      return new MessageEmbed()
        .setDescription(`***__:rotating_light: | ДЕЙСТВИЕ ЗАПРЕЩЕНО!__***\n\n﹒Сервер: **${guild}**\n﹒Действие: **${event}**\n\n***__:fire: | ДЕТАЛИ СОБЫТИЙ:__***\n\n﹒Нарушитель: **${executor}**\n﹒Жертва: **${target}**\n﹒Наказание: **${punishment}**`)
        .setColor("ffffff")
    } else if (event === "Webhook Create") {
      return new MessageEmbed()
        .setDescription(`***__:rotating_light: | ДЕЙСТВИЕ ЗАПРЕЩЕНО!__***\n\n﹒Сервер: **${guild}**\n﹒Действие: **${event}**\n\n***__:fire: | ДЕТАЛИ СОБЫТИЙ:__***\n\n﹒Нарушитель: **${executor}**\n﹒Webhook: **${target}**\n﹒Наказание: **${punishment}**`)
        .setColor("ffffff")
    } else if (event === "Bot Add") {
      return new MessageEmbed()
        .setDescription(`***__:rotating_light: | ДЕЙСТВИЕ ЗАПРЕЩЕНО!__***\n\n﹒Сервер: **${guild}**\n﹒Действие: **${event}**\n\n***__:fire: | ДЕТАЛИ СОБЫТИЙ:__***\n\n﹒Нарушитель: **${executor}**\n﹒Бот: **${target}**\n﹒Наказание: **${punishment}**`)
        .setColor("ffffff")
    }
  },
  InteractionEmbeds: {
    AntinukeCmds: new MessageEmbed()
      .setDescription(`**__:shield: | АНТИ КРАШ КОММАНДЫ__**\n\n**px!wl** - добавить в белый список пользователя / бота \n**px!uwl** - убрать из белого списка пользователя / бота \n**px!list** - посмотреть кто в белом списке*`)
      .setFooter({ text: `Ты знаешь, что такое безумие? Я знаю.` })
      .setColor("ffffff"),
    Information: function (ping, users, guilds) {
      return new MessageEmbed()
        .setDescription(`**__:scroll: | АНТИ КРАШ ИНФОРМАЦИЯ__**\n\nБиблиотека: *discord.js*\nЯзык программирования: *JavaScript*\nРазработчик: *S.mode#9723*\n\nЗадержка: *${ping}ms*\nСервера: *${guilds}*\nПользователи: ${users}`)
      .setColor("ffffff")
    },
    AntinukeWiki: new MessageEmbed()
      .setDescription(
        `**__:scroll: | АНТИ КРАШ ПОСОБИЕ ДЛЯ ЧАЙНИКОВ :)__**
*Привет! Ещё раз крепко жму руку надеюсь не отмерла ). Спасибо за использование бота! В этой инструкции вы узнаете как настроить бота!*

**Как это работает?**
*Если кто-то совершает действие на вашем сервере, он регистрируется в журнале аудита. Поэтому H Protect проверяет журнал аудита, чтобы узнать, что произошло и кто это сделал. Человек, который выполняет действие, называется **нарушитель**. предположим, что он забанил кого-то. Жертва является **целью**. бот проверяет, доверяет ли исполнитель владельцу или нет. Если исполнителя нет в списке доверенных пользователей, он банит его. а также пытается отправить **прямое сообщение** владельцу, включая то, что и почему произошло.*

**Вещи которые нужно знать!**
*Вы должны предоставить боту h Protect **права администратора**, чтобы он мог модерировать и защищать ваш сервер. Также роль h Protect должна быть **выше всех ролей**, чтобы он мог наказывать нарушителей. Также просим оставить личные сообщения открытыми, если хотите получать уведомления от h Protect. В противном случае h Protect не сможет вам сказать что произошло и кого за что забанил и т.д.*`
    )
      .setColor("ffffff"),
  }
}