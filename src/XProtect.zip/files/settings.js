module.exports = {
  bot: {
    prefix: "s.",
    token: process.env.token,
    invLink: `https://discord.com/api/oauth2/authorize?client_id=977546369847926784&permissions=8&scope=bot`
  },
  presence: {
    status: 'idle',
    activity: 'PLAYING'
  },
  options: {
    founders: ["1001143162795982998"],
    privateMode: false
  },
  credits: {
    developerId: "1001143162795982998",
    developer: "Parmizan#1055"
  }
}