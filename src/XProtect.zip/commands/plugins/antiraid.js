// Кнопки СУКА!
const { Message, Client, MessageEmbed } = require("discord.js");
const client = require("../../index");

// БД
const Database = require("@replit/database");
const db = new Database();

// Параметры
const Settings = require('../../files/settings.js');
const prefix = Settings.bot.prefix;

// комманда
module.exports = {
  name: "9089089809antiraid",
  aliases: ['80809anr'],
  run: async (client, message, args) => {
    const guide = new MessageEmbed()
      .setColor("ffffff")
      .setDescription(`*Не работает*`)

    message.channel.send({ embeds: [guide] });
  },
};