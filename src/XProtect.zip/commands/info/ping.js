const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "a",
  aliases: ['p','ping'],
  run: async (client, message, args) => {;
    const ping = new MessageEmbed()
      .setColor("GREEN")
      .setDescription(`Пинг бота: ${client.ws.ping}ms`)
    // отпрвка
    message.channel.send({ embeds: [ping]});
  },
};