const { Message, Client } = require("discord.js");
const Database = require("@replit/database");
const db = new Database();

const settings = require('../../files/settings');
const isPrivate = settings.options.privateMode;
const owners = settings.options.founders;

module.exports = {
  name: "wl",
  aliases: ['allowguild', 'allow'],
  run: async (client, message, args) => {
    if (isPrivate === true) {
      const ID = args[0];
      if (owners.includes(message.author.id)) {
      if (!ID) {
        message.channel.send({ content: `Предоставьте мне ID сервера.` })
      } else if (ID.length !== 18) {
        message.channel.send({ content: `Пожалуйста, предоставьте мне ВЕРНЫЙ ID сервера.` })
      } else {
        let allowed = await db.get(`allowed ${ID}`)
        if (allowed === null) allowed = false;
        
        if (allowed === true) {
          message.channel.send({ content: `Этот сервер уже есть в белом списке.` });
        } else {
          await db.set(`allowed ${ID}`, true);
          await message.channel.send({ content: `Успех! Сервер успешно был добавлен в белый список.` })
          await client.guilds.cache.forEach( (guild) => { arr.push(`${guild.id}`) });
        }
      }
    }
    }
  },
};