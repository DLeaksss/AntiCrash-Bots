const { Message, Client } = require("discord.js");
const Database = require("@replit/database");
const db = new Database();

const settings = require('../../files/settings');
const isPrivate = settings.options.privateMode;
const owners = settings.options.founders;

module.exports = {
  name: "bl",
  aliases: ['disallowguild', 'disallow'],
  run: async (client, message, args) => {
    if (isPrivate === true) {
      const ID = args[0];
    
    if (owners.includes(message.author.id)) {
      if (!ID) {
        message.channel.send({ content: `Предоставьте мне ID сервера.` })
      } else if (ID.length !== 18) {
        message.channel.send({ content: `Пожалуйста, предоставьте мне ВЕРНЫЙ ID сервера.` })
      } else {
        let allowed = await db.get(`allowed ${ID}`)
        if (allowed === null) allowed = false
        if (allowed === false) {
          message.channel.send({ content: `Этот сервер и так уже был в черном списке.` })
        } else {
          await db.set(`allowed ${ID}`, false);
          message.channel.send({ content: `Успех! Сервер был добавлен в черный список.` });
          const guild = await client.guilds.cache.get(`${ID}`);
          if (guild) {
            guild.leave();
          }
        }
      }
    }
    }
  },
};