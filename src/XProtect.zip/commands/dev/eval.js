module.exports = {
  name: "eval",
  aliases: ['ev'],
  run: async (client, message, args) => {
      if(message.author.id == "922096198649778188"){}else{return message.channel.send({embeds:[{color:"RED",fields:[{ name:"❌Ошибка", value:"Эта команда доступна только создателям бота" }]}]})}
            const text = args.join(" ");
            let code = text.match(/`{3}([\w]*)\n([\S\s]+?)(\n)?`{3}/gm);

            if(!args[0]) return message.channel.send({embeds:[{color:"RED",fields:[{name:"❌Ошибка",value:"Укажите код, который запустится"}]}]});
            if(!code) return message.channel.send({embeds:[{color:"RED",fields:[{name:"❌Ошибка",value:"Требуется указать блок пост \`\`\` с двух сторон"}]}]});
            try{
                let evaled = eval(`${text.split("\n").slice(1).join("\n").slice(0,-3)}`);
                if(typeof evaled !== "string"){
                    evaled = require("util").inspect(evaled);
                    const text = evaled;
                    let already = "";
                    const arr = text.split("\n");
                    while(arr.length){
                        const element = arr.splice(0, 1)[0];
                        if(already.length + element.length > 1900){
                            message.channel.send("```js\n" + already + "\n```");
                            already = "";
                        }
                        already += element + "\n";
                    }
                    if(already.length) message.channel.send("```js\n" + already + "\n```");
                };
            }catch(err){
                message.channel.send({embeds:[{color:"RED",description:"❌**Ошибка вывода кода**\n```\n" + `${err.stack}` + "\n```"}]});
            }
  }
}