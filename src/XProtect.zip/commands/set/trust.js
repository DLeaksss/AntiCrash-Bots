const { Message, MessageEmbed, Client } = require("discord.js");
const Database = require("@replit/database");
const db = new Database();

const settings = require('../../files/settings');

module.exports = {
  name: "wl",
  aliases: ['w', 'whitelist'],
  run: async (client, message, args) => {
    if (message.author.id !== message.guild.ownerId) {
      message.channel.send({ content: `*Тебе нельзя :) Только создатель сервера может использовать эту команду.*` });
    } else {
      var enabled = await db.get(`antinuke_${message.guild.id}`);
      if (enabled === true) {
      const user = message.mentions.users.first();
      if (!user) {
        const guide = new MessageEmbed()
          .setColor("ffffff")
          .setDescription("***БЕЛЫЙ СПИСОК***\n*Когда пользователь в белом списке бот **ВСЕ** его действия игнорирует.*\n\n﹒*Используйте*: h.wl\n﹒*эта команда доступна только для создателя сервера!*")
        message.channel.send({ embeds: [guide] })
      } else {
        const ID = user.id;
        const Guild = message.guildId;
        let whitelisted = await db.get(`trust${Guild} ${ID}`)
        if (whitelisted === null) whitelisted = false;
      
        if (whitelisted === true) {
          message.channel.send({ content: `*Пользователь уже есть в белом списке.*` });
        } else {
          await db.set(`trust${Guild} ${ID}`, true)
          await message.channel.send({ content: `УСПЕХ! Пользователь **${user.username}** пользователь был добавлен в белый список.` })
        }
      }
     } else {
        message.channel.send({ content: `Сначала активируйте анти краш командой **px!enable**.`});
     }
    }
  },
}