const { Message, Client, MessageEmbed } = require("discord.js");
const Database = require("@replit/database");
const db = new Database();

module.exports = {
  name: "disable",
  aliases: ['d', 'antinuke disable'],
  run: async (client, message, args) => {
    var antinuke = await db.get(`antinuke_${message.guild.id}`);
    if (message.author.id !== message.guild.ownerId) {
      const guide = new MessageEmbed()
        .setColor("ffffff")
        .setDescription("***:shield: | АНТИ КРАШ***\n*Если анти краш будет отключен, то сервер будет под угрозой, а значит бот не будет защищать сервер.*\n\n﹒*Используйте* :: disable *или* d\n﹒*эта команда доступна только для создателя сервера!*")
      message.channel.send({ embeds: [guide] });
    } else {
      if (antinuke === false) {
        message.channel.send({ content: `УПС! Анти краш уже и так был отключен.` });
      } else {
        await db.set(`antinuke_${message.guild.id}`, false);
        await message.channel.send({ content: `УСПЕХ! Анти краш был отключен. Если вы передумали, то скорее напишите h.enable` });
      }
    }
  },
};