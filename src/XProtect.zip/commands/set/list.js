const { Message, Client, MessageEmbed } = require("discord.js");
const Database = require("@replit/database");
const db = new Database();

module.exports = {
  name: "list",
  aliases: ['l', 'trusted', 'whitelisted'],
  run: async (client, message, args) => {

    // Чекер автор овнер или пибр?
    if (message.author.id !== message.guild.ownerId) {
      message.channel.send({ content: `Тебе нельзя :) Только создатель сервера может использовать эту команду.` });
      
    } else {
      var enabled = await db.get(`antinuke_${message.guild.id}`);
      if (enabled === true) {
      const users = [];
      const Guild = message.guildId;
      // Вайт листед
      await db.list(`trust${message.guild.id} `).then(async array => {

        if (array.length > 0) {
          
          // Хд
          for (x in array) {
          const mentions = array[x];
          const split = mentions.split(" ")[1];
          const IDs = "<@" + split + ">";
          await users.push(IDs);
            
          }
          
          // УРА! Отправка
          const trustedUsers = new MessageEmbed()
            .setTitle('В белом списке')
            .setDescription(`${users.join("\n")}`)
            .setColor("ffffff")
          message.channel.send({ embeds: [trustedUsers] })
        } else {
          message.channel.send({ content: 'Список пуст. \nНикого нету в белом списке.\n\n Все давно уже вымерли в 3021 году пока вы спали.\n\n Да, кстати обернитесь.' })
        }
      });
      } else {
        message.channel.send({ content: `Сначала активируйте анти краш командой **h.enable**.`});
      }
    }
  },
}