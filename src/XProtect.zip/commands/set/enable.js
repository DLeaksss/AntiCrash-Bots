const { Message, Client, MessageEmbed } = require("discord.js");
const Database = require("@replit/database");
const db = new Database();

module.exports = {
  name: "enable",
  aliases: ['e', 'antinuke enable'],
  run: async (client, message, args) => {
    var antinuke = await db.get(`antinuke_${message.guild.id}`);
    if (message.author.id !== message.guild.ownerId) {
      const guide = new MessageEmbed()
        .setColor("ffffff")
        .setDescription("сорри это может только создатель сервера")
      message.channel.send({ embeds: [guide] });
    } else {
      if (antinuke === true) {
        message.channel.send({ content: `УПС! Анти краш уже и так был включен для этого сервера.` });
      } else {
        await db.set(`antinuke_${message.guild.id}`, true);
        await message.channel.send({ content: `УСПЕХ! Анти краш был включен. Ваш сервер в безопасности :shield:` });
      }
    }
  },
};