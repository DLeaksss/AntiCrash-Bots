const { MessageEmbed, Client } = require("discord.js");
const Database = require("@replit/database");
const db = new Database();

module.exports = {
  name: "uwl",
  aliases: ['uw', 'unwhitelist'],
  run: async (client, message, args) => {
    if (message.author.id !== message.guild.ownerId) {
      message.channel.send({ content: `*Тебе нельзя :) Только создатель сервера может использовать эту команду.*` });
    } else {
      let enabled = await db.get(`antinuke_${message.guild.id}`);
      if (enabled === true) {
      const user = message.mentions.users.first();
      if (!user) {
        const guide = new MessageEmbed()
         .setColor("GREEN")
         .setDescription("***БЕЛЫЙ СПИСОК***\n*Если вы убирете пользователя из белого списка, то бот снова будет геагировать на действия пользователя и применять наказания за них*\n\n﹒*Используйте*: h.untrust\n﹒*эта команда доступна только для создателя сервера!*")
        message.channel.send({
          embeds: [guide]
        })
      }
      const ID = user.id;
      const Guild = message.guildId;

      let whitelisted = await db.get(`trust${Guild} ${ID}`)
      if (whitelisted === null) whitelisted = false;
      
      if (whitelisted === false) {
        message.channel.send({ content: `Пользователя и так нету в белом списке` });
      } else {
        await db.delete(`trust${Guild} ${ID}`)
        await message.channel.send({ content: `УСПЕХ! Пользователь **${user.username}** был удален из белого списка.` })
      }
    } else {
        message.channel.send({ content: `Сначала активируйте анти краш командой **h.enable**.`});
    }
    }
  },
}