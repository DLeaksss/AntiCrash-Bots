module.exports = {
    name: "ban",
    aliases: [],
    run: async (client, message, args) => {
     if (!message.member.permissions.has("BAN_MEMBERS")) {
       message.channel.send({ content: `*${message.author.username},* Тебе нельзя :) Тебе нужны права **банить участников**` });
     } else {    
       const person = message.mentions.members.first();
       if (!person) {
         message.channel.send({ content: `*${message.author.username},* укажите участника которого хотите забанить.` });
       }
       if (!person.bannable) {
         message.channel.send({ content: `*${message.author.username},* Я не могу его забанить :C` });
       } else {
         var reason = args.slice(1).join(" ");
         if (!reason) reason = `забанен пользователем ${message.author.tag}`
         person.ban({ reason: `${reason}` });
         message.channel.send({ content: `человек забанен! по причине: ${reason}` });
         message.channel.send({ embeds: [embed3]});
       }
     }
  },
};