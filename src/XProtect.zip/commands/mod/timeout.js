module.exports = {
  name: "mute",
  aliases: ["mute"],
  run: async (client, message, args) => {
    const member = message.mentions.members.first();
    if (!message.member.permissions.has("MANAGE_MEMBERS")) {
      message.channel.send({ content: `*${message.author.username}*, Тебе нельзя :) Тебе нужны права **управление участниками**`});
    } else {
      if (!member) {
        message.channel.send({ content: `Чтобы включить/отключить тайм-аут для пользователя сначала укажите его...`});
      } 
      if (!member.manageable) {
        message.channel.send({ content: `я не могу управлять этим пользователем :C` });
      } else {
        if (member.isCommunicationDisabled()) {
          member.timeout(null);
          message.channel.send({ content: `Успех! Тайм-аут убран для этого пользователя.`});
        } else {
        member.timeout(10000000);
        message.channel.send({ content: `Успех! Тайм-аут включен для этого пользователя.`});
        }
      }
    }
  },
};