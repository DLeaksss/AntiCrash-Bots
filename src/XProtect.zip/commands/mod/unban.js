module.exports = {
    name: "unban",
    aliases: [],
    run: async (client, message, args) => {
     if (!message.member.permissions.has("BAN_MEMBERS")) {
       message.channel.send({ content: `*${message.author.username},* Тебе нельзя :) Тебе нужны права **банить участников**` });
     } else {
       const ID = args[0];
       if (!ID) {
         message.channel.send({ content: `Предоставьте мне ID забаненного пользователя пожалуйста.` });
       } else {
         const list = await message.guild.bans.fetch();
         const user = list.find((user) => { user.id == `${ID}` });
         if (!user) {
           message.channel.send({ content: `Этот пользователь не забанен.` });
         } else {
           message.guild.members.users.unban(ID)
           message.channel.send({ content: `человек разбанен!` });
         }
       }
     }
  },
};