const { MessageEmbed } = require("discord.js");
const Database = require("@replit/database");
const db = new Database();

module.exports = {
  name: "autorole",
  aliases: ["ar"],
  run: async (client, message, args) => {
    const role = message.mentions.roles.first();
    const guide = new MessageEmbed()
          .setColor("ffffff")
          .setDescription(`***Авто-роль***
*Я дам роль новым участникам, когда они присоединятся к этому серверу. Упомяните роль, чтобы установить ее для новых участников.*

﹒*Используйте*: h.autorole @роль
﹒*Эта команда доступна только для создателя сервера!*`)
    if (!message.member.permissions.has("ADMINISTRATOR")) {
      if (!role) {
        message.channel.send({ embeds: [guide] });
      } else {
        message.channel.send({ content: `Тебе нельзя :) Вам требуется право администратора.` });
      }
    } else {
      if (!role) {
        message.channel.send({ embeds: [guide] });
      } else {
        if (role.permissions.has("ADMINISTRATOR")) {
          message.channel.send({ content: "Вы не можете выбрать роль с правом администратора." });
        } else if (role.permissions.has("KICK_MEMBERS") ||
                  role.permissions.has("BAN_MEMBERS")) {
          message.channel.send({ content: "Вы не можете выбрать роль у которой есть право управление пользователями (кик, бан и т.д.)" });
        } else {
          const done = new MessageEmbed()
            .setColor("ffffff")
            .setDescription(`***УСПЕХ!***\n﹒*Установленная роль:*: ${role}`)
          await db.set(`autoRole_${message.guild.id}`, role.id);
          message.channel.send({ embeds: [done] });
        }
      }
    }
  },
};