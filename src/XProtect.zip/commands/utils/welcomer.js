const { Message, Client, MessageEmbed } = require("discord.js");
const Database = require("@replit/database");
const db = new Database();

module.exports = {
  name: "welcome",
  aliases: ['wel', 'w'],
  run: async (client, message, args) => {
    const guide = new MessageEmbed()
      .setColor("ffffff")
      .setDescription("***КАНАЛ ПРИВЕТСТВИЙ***\n*Я буду приветствовать новых участников, как только они присоединятся к этому серверу. Упомяните канал, чтобы установить его для новых участников.*\n\n﹒*Используйте*: h.welcome #канал\n﹒*эта команда доступна только для создателя сервера!*")
    
    if (!message.member.permissions.has("ADMINISTRATOR")) {
      message.channel.send({ embeds: [guide] });
    } else {
      const channel = message.mentions.channels.first();
      if (!channel) {
        message.channel.send({ embeds: [guide] });
      } else {
        const success = new MessageEmbed()
          .setColor("GREEN")
          .setDescription(`***Успех!***\n﹒*Установленный канал*: ${channel}`)
        await db.set(`welcomer_${message.guild.id}`, channel.id);
        message.channel.send({ embeds: [success] });
      }
    }
  },
};