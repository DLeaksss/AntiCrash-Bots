import os
import disnake

default_prefix = ['g.', 'G.']

error_color = disnake.Colour.from_rgb(255, 0, 0)
success_color = disnake.Colour.from_rgb(21, 76, 239)
warning_color = disnake.Colour.from_rgb(255, 200, 0)
main_color = disnake.Colour.from_rgb(148, 0,44)


developers = [965615212235464774, 998659686490456144, 996140834602881096] #айдишники разрабов, меня не убирай желательно

betatestbottoken = ""
maintoken = ""

betatests = False #режим тестирования бота
logsram = True #логи о потраченой памяти

logs_webhook = "" #хук с логами заходов

default_wl = [458276816071950337, 708616355024207884, 310848622642069504, 159985870458322944] #белый список по умолчанию, айди своего бота добавлять не надо, т.к он не реагирует на свои же действия

support_server = "" #тут код приглашения на сервер поддержки бота

version = "1.7 Beta, slash commands are supported" #версия бота

ramlogssleep = 60 #задержка на логи о потраченой памяти