import disnake
import config

#я заебался постоянно копировать сообщение с ошибкой, поэтому решил сделать так

async def errmess(ctx, text):
    return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description=f'>>> **{text}**', color=config.error_color))

async def succmess(ctx, text):
    return await ctx.send(embed=disnake.Embed(title='<:483326:1030579742174355597> | Успешно', description=f'>>> **{text}**', color=config.success_color))