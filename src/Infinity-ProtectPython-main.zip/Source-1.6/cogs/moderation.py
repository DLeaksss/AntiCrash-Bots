import sqlite3
from disnake.ui import ActionRow, Select, Button, View
from disnake import AppCmdInter, SelectOption, ButtonStyle
import disnake
from disnake.ext import commands
import io
import contextlib
import textwrap
import os
import aiohttp
from matplotlib.style import use
import requests
import random
import asyncio
import time
import datetime
from datetime import datetime as dt
import typing
from colorama import Fore, init


init()

import database
import config
import adms
import mods
import times


class Mod(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db = sqlite3.connect('data.db')
        self.cur = self.db.cursor()
        
    @commands.slash_command(description='Забанить участника')
    @commands.check(adms.has_ban_members)
    @commands.cooldown(1, 45, commands.BucketType.guild)
    async def ban(self, ctx: AppCmdInter, user: disnake.Member=None, *, reason='Не указана', time1='0s'):
        await ctx.response.defer()
        if user == None:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты не упомянул пользователя которого хочешь забанить**', color=config.error_color))
        if not isinstance(user, disnake.Member):
            #print(type(user))
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты упомянул не пользователя**', color=config.error_color))
        if user.id == ctx.author.id:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Нельзя забанить самого себя**', color=config.error_color))
        if ctx.guild.get_member(user.id):
            if ctx.guild.get_member(user.id) == ctx.guild.me:
                return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Нельзя забанить бота**', color=config.error_color))
            if ctx.guild.get_member(user.id) == ctx.guild.owner:
                return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Нельзя забанить владельца сервера**', color=config.error_color))
            if ctx.guild.get_member(user.id).top_role.position >= ctx.guild.me.top_role.position:
                return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Роль данного пользователя выше/на уровне со мной**', color=config.error_color))
            if ctx.guild.get_member(user.id).top_role.position >= ctx.author.top_role.position and not ctx.author == ctx.guild.owner:
                return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Роль данного пользователя выше/на уровне с тобой**', color=config.error_color))
        if time1 == '0s':
            try:
                await user.send(
                    embed=disnake.Embed(
                        title='<:359940:1025857533321150517> | Бан',
                        description=f'''>>> **Ты получил бан на сервере `{ctx.guild.name}` ({ctx.guild.id})
Модератор: `{ctx.author}` ({ctx.author.mention})
Причина: `{reason}`**''',
                        color=config.main_color
                    )
                )
            except:
                pass
            await user.ban(reason=reason)
            await ctx.send(
                embed=disnake.Embed(
                    title='<:359940:1025857533321150517> | Бан',
                    description=f'''>>> **Пользователь: `{user}` ({user.mention})
Модератор: `{ctx.author}` ({user.mention})
Причина: `{reason}`**''',
                    color=config.main_color
                )
            )
        else:
            if times.ishs(time1):
                time1 = times.string_to_seconds(time1)
                try: await user.send(
                    embed=disnake.Embed(
                        title='<:359940:1025857533321150517> | Бан',
                        description=f'''>>> **Ты получил бан на сервере `{ctx.guild.name}` ({ctx.guild.id})
Модератор: `{ctx.author}` ({ctx.author.mention})
Причина: `{reason}`
Срок: `{times.hms(float(time1))}`**''',
                        color=config.main_color
                    )
                )
                except: pass
                await mods.tempban(ctx, user, time1)
                await ctx.send(
                    embed=disnake.Embed(
                        title='<:359940:1025857533321150517> | Бан',
                        description=f'''>>> **Пользователь: `{user}` ({user.mention})
Модератор: `{ctx.author}` ({user.mention})
Причина: `{reason}`**''',
                        color=config.main_color
                    )
                )
            else:
                try:
                    await user.send(
                        embed=disnake.Embed(
                            title='<:359940:1025857533321150517> | Бан',
                            description=f'''>>> **Ты получил бан на сервере `{ctx.guild.name}` ({ctx.guild.id})
    Модератор: `{ctx.author}` ({ctx.author.mention})
    Причина: `{reason}`**''',
                            color=config.main_color
                        )
                    )
                except:
                    pass
                await user.ban(reason=reason)
                await ctx.send(
                    embed=disnake.Embed(
                        title='<:359940:1025857533321150517> | Бан',
                        description=f'''>>> **Пользователь: `{user}` ({user.mention})
Модератор: `{ctx.author}` ({user.mention})
Причина: `{reason}`**''',
                        color=config.main_color
                    )
                )

    @commands.slash_command(description='Кикнуть учасника')
    @commands.check(adms.has_kick_members)
    @commands.cooldown(1, 45, commands.BucketType.guild)
    async def kick(self, ctx, user: disnake.Member=None, *, reason='Не указана'):
        await ctx.response.defer()
        if user == None:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты не упомянул пользователя которого хочешь кикнуть**', color=config.error_color))
        if not isinstance(user, disnake.Member):
            #print(type(user))
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты упомянул не пользователя**', color=config.error_color))
        if user.id == ctx.author.id:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Нельзя кикнуть самого себя**', color=config.error_color))
        if ctx.guild.get_member(user.id):
            if ctx.guild.get_member(user.id) == ctx.guild.me:
                return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Нельзя кикнуть бота**', color=config.error_color))
            if ctx.guild.get_member(user.id) == ctx.guild.owner:
                return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Нельзя кикнуть владельца сервера**', color=config.error_color))
            if ctx.guild.get_member(user.id).top_role.position >= ctx.guild.me.top_role.position:
                return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Роль данного пользователя выше/на уровне со мной**', color=config.error_color))
            if ctx.author == ctx.guild.owner:
                try:
                    await user.send(
                        embed=disnake.Embed(
                            title='<:359940:1025857533321150517> | Кик',
                            description=f'''>>> **Ты получил кик на сервере `{ctx.guild.name}` ({ctx.guild.id})
Модератор: `{ctx.author}`
Причина: `{reason}`**''',
                            color=config.main_color
                        )
                    )
                except:
                    pass
                await user.kick(reason=f'{ctx.author}: {reason}')
                await ctx.send(
                    embed=disnake.Embed(
                        title='<:359940:1025857533321150517> | Кик',
                        description=f'''>>> **Пользователь: {user}
Модератор: {ctx.author}
Причина: `{reason}`**''',
                        color=config.main_color
                    )
                )
                return
            if ctx.guild.get_member(user.id).top_role.position >= ctx.author.top_role.position:
                return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Роль данного пользователя выше/на уровне с тобой**', color=config.error_color))
        try:
            await user.send(
                embed=disnake.Embed(
                    title='<:359940:1025857533321150517> | Кик',
                    description=f'''>>> **Ты получил кик на сервере `{ctx.guild.name}` ({ctx.guild.id})
Модератор: `{ctx.author}`
Причина: `{reason}`**''',
                    color=config.main_color
                )
            )
        except:
            pass
        await user.kick(reason=reason)
        await ctx.send(
            embed=disnake.Embed(
                title='<:359940:1025857533321150517> | Кик',
                description=f'''>>> **Пользователь: {user}
Модератор: {ctx.author}
Причина: `{reason}`**''',
                color=config.main_color
            )
        )

    @commands.slash_command(description='Очистить чат')
    @commands.check(adms.has_manage_messages)
    @commands.cooldown(1, 60, commands.BucketType.guild)
    async def clear(self, ctx: AppCmdInter, amount: int = 100, user: typing.Optional[disnake.Member] = None):
        await ctx.response.defer()
        m = await ctx.original_message()
        def check(msg):
            return msg.author == user and not msg.id == m.id
        if amount > 1000:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Нельзя удалить более `1000` сообщений**', color=config.error_color))
        else:
            embed = disnake.Embed(color=config.main_color)
            embed.title = "<:1327315:1030959327223226368> | Очистка сообщений"
            if user is None:
                deleted = len(await ctx.channel.purge(limit=amount, check=lambda msg: msg.id != m.id))
                embed.description = f'>>> **Удалено `{deleted}` сообщений**'
            else:
                deleted = len(await ctx.channel.purge(limit=amount, check=check))
                embed.description = f'>>> **Удалено `{deleted}` сообщений от {user.mention}**'
            await ctx.send(embed=embed)
    
    @commands.slash_command(description='Закрыть чат.')
    @commands.check(adms.has_administrator)
    @commands.cooldown(1, 10, commands.BucketType.guild)
    async def lock(self, ctx, channel: disnake.TextChannel = None):
        await ctx.response.defer()
        if channel is None:
            channel = ctx.channel
        await channel.set_permissions(ctx.guild.default_role, send_messages=False, add_reactions=False)
        # await ctx.message.add_reaction('🔒')
        await ctx.send('🔒')

    @commands.slash_command(description='Открыть чат.')
    @commands.check(adms.has_administrator)
    @commands.cooldown(1, 10, commands.BucketType.guild)
    async def unlock(self, ctx, channel: disnake.TextChannel = None):
        await ctx.response.defer()
        if channel is None:
            channel = ctx.channel
        await channel.set_permissions(ctx.guild.default_role, send_messages=None, add_reactions=None)
        await ctx.send('🔓')
        # await ctx.message.add_reaction('🔓')
    """
    @commands.command(description='Закрыть чат.')
    @commands.check(adms.has_administrator)
    @commands.cooldown(1, 10, commands.BucketType.guild)
    async def lock(self, ctx, channel: disnake.TextChannel = None):
        if channel is None:
            channel = ctx.channel
        await channel.set_permissions(ctx.guild.default_role, send_messages=False, add_reactions=False)
        await ctx.message.add_reaction('🔒')
    @commands.command(description='Открыть чат.')
    @commands.check(adms.has_administrator)
    @commands.cooldown(1, 10, commands.BucketType.guild)
    async def unlock(self, ctx, channel: disnake.TextChannel = None):
        if channel is None:
            channel = ctx.channel
        await channel.set_permissions(ctx.guild.default_role, send_messages=None, add_reactions=None)
        await ctx.message.add_reaction('🔓')
    """

    @commands.slash_command(description='Выдать предупреждение участнику')
    @commands.check(adms.has_moderator)
    @commands.cooldown(1, 15, commands.BucketType.guild)
    async def warn(self, ctx: AppCmdInter, user: disnake.Member=None, reason="Причина не указана"):
        await ctx.response.defer()
        if user == None:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты не упомянул пользователя которого хочешь предупредить**', color=config.error_color))
        if not isinstance(user, disnake.Member):
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты упомянул не пользователя**', color=config.error_color))
        if user.id == ctx.author.id:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Нельзя предупредить себя**', color=config.error_color))
        if user.top_role.position >= ctx.author.top_role.position and not ctx.author == ctx.guild.owner:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Роль данного пользователя выше/на уровне с тобой**', color=config.error_color))            
        if user == ctx.guild.owner:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Нельзя предупредить владельца сервера.**', color=config.error_color))
        if user.id == self.bot.user.id:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты не можешь предупредить бота.**', color=config.error_color))
        warnnum = len(self.cur.execute("SELECT * FROM warns WHERE guild_id = {} AND user_id = {}".format(ctx.guild.id, user.id)).fetchall()) + 1
        if warnnum > 30:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Лимит предупреждений для этого участника (30) превышен**', color=config.error_color))
        embed = disnake.Embed(
            title='<:497789:1030770449958830110> | Предупреждение',
            description=f'>>> **Участнику выдано предупреждение\nУчастник: `{user}` ({user.mention})\nМодератор: `{ctx.author}` ({ctx.author.mention})\nНомер предупреждения: `#{warnnum}`\nПричина: `{reason}`**',
            color=config.warning_color
        )
        await ctx.send(embed=embed)
        self.cur.execute("INSERT INTO warns VALUES (?, ?, ?, ?)", (ctx.guild.id, user.id, reason, warnnum))
        self.db.commit()
        embed = disnake.Embed(
            title='<:497789:1030770449958830110> | Предупреждение',
            description=f'>>> **Ты получил предупреждение на сервере `{ctx.guild.name}` ({ctx.guild.id})\nМодератор: `{ctx.author}` ({ctx.author.mention})\nНомер предупреждения: `#{warnnum}`\nПричина: `{reason}`**',
            color=config.warning_color
        )
        await user.send(embed=embed)

    @commands.slash_command(description='Снять предупреждение участнику')
    @commands.check(adms.has_moderator)
    @commands.cooldown(1, 15, commands.BucketType.guild)
    async def unwarn(self, ctx: AppCmdInter, user: disnake.Member=None, number: int=None):
        await ctx.response.defer()
        if user == None:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты не упомянул пользователя которому хочешь снять предупреждение**', color=config.error_color))
        if number == None:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты не указал номер предупреждения которое хочешь снять участнику**', color=config.error_color))
        if not isinstance(user, disnake.Member):
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты упомянул не пользователя**', color=config.error_color))
        if not isinstance(number, int):
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Номер предупреждения должен быть числом**', color=config.error_color)) 
        if user.id == ctx.author.id:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Нельзя снять предупреждение у себя**', color=config.error_color))
        if user == ctx.guild.owner:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Нельзя снять предупреждение владельцу сервера.**', color=config.error_color))
        if self.cur.execute("SELECT * FROM warns WHERE guild_id = {} AND user_id = {} AND warn_number = {}".format(ctx.guild.id, user.id, number)).fetchone() == None:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Такое предупреждение не найдено**', color=config.error_color))
        self.cur.execute("DELETE FROM warns WHERE guild_id = {} AND user_id = {} AND warn_number = {}".format(ctx.guild.id, user.id, number))
        self.db.commit()
        embed=disnake.Embed(
            title="<:497789:1030770449958830110> | Снято предупреждение",
            description=f">>> **Участник: `{user}` ({user.mention})\nМодератор: `{ctx.author}` ({ctx.author.mention})\nНомер предупреждения: `#{number}`**",
            color=config.warning_color
        )
        await ctx.send(embed=embed)

    @commands.slash_command(description="Список предупреждений участника") # CRASH BY SNEJOK332 AND SXELA AND FORZEL AND XZ HUB AND MSC TEAM AND FZL GROUP AND NEESSSGZ 
    @commands.cooldown(1, 10, commands.BucketType.guild)
    async def warnlist(self, ctx, user: disnake.User=None):
        if user == None:
            user = ctx.author
        if not isinstance(user, disnake.Member) and not isinstance(user, disnake.User):
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты упомянул не пользователя**', color=config.error_color))
        warns = self.cur.execute("SELECT warn_number, reason FROM warns WHERE guild_id = {} AND user_id = {}".format(ctx.guild.id, user.id)).fetchall()
        if warns == []:
            embed=disnake.Embed(
                title="<:497789:1030770449958830110> | Список предупреждений",
                description=f">>> **Список предупреждений участника `{user}` ({user.mention})\nПредупреждения отсутствуют**",
                color=config.warning_color
            )
            return await ctx.send(embed=embed)
        wrns = ""
        for war in warns:
            wrns += f"Предупреждение #{war[0]}\nПричина: `{war[1]}`\n"
        embed=disnake.Embed(
            title="<:497789:1030770449958830110> | Список предупреждений",
            description=f">>> **Список предупреждений участника `{user}` ({user.mention})\n{wrns}**",
            color=config.warning_color
        )
        await ctx.send(embed=embed)

    @commands.slash_command(description="Замутить участника")
    @commands.check(adms.has_mute_members)
    @commands.cooldown(1, 30, commands.BucketType.guild)
    async def mute(self, ctx: disnake.AppCmdInter, member: disnake.Member=None, reason='Причина не указана.', time1='0s'):
        if member == None:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты не упомянул пользователя которого хочешь замутить**', color=config.error_color))
        if not isinstance(member, disnake.Member):
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты упомянул не пользователя**', color=config.error_color))
        if member == ctx.author:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Нельзя замутить самого себя**', color=config.error_color))
        if member.id == self.bot.user.id:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Нельзя замутить бота**', color=config.error_color))
        if member == ctx.guild.owner:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты не можешь замутить владельца сервера.**', color=config.error_color))
        if member.id == self.bot.user.id:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты не можешь замутить бота.**', color=config.error_color))
        if member.top_role.position >= ctx.guild.me.top_role.position:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Роль данного пользователя выше/на уровне со мной.**', color=config.error_color))
        if member.top_role >= ctx.author.top_role and not ctx.author == ctx.guild.owner:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты не можешь замутить пользователя, роль которого не ниже твоей.**', color=config.error_color))
        if self.cur.execute("SELECT * FROM mutes WHERE guild_id = {} AND user_id = {}".format(ctx.guild.id, member.id)).fetchone() != None or self.cur.execute("SELECT * FROM timemutes WHERE guild_id = {} AND user_id = {}".format(ctx.guild.id, member.id)).fetchone() != None:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Пользователь уже замучен**', color=config.error_color))
        await ctx.response.defer()
        embed = disnake.Embed(
            title='<:5381637:1032635392266076181> | Мут',
            description=f'''>>> **Пользователь замучен
Администратор: `{ctx.author}` ({ctx.author.mention}
Причина: `{reason}`
Пользователь: `{member}` ({member.mention})**''',
            color=config.error_color
        )
        if time1 == '0s':
            await ctx.edit_original_response(embed=embed)
            await mods.qua(ctx, member)
            embed.description = f'''>>> **Ты был замучен на сервере `{ctx.guild.name}`
Администратор: `{ctx.author}` ({ctx.author.mention}
Причина: `{reason}`**'''
            try: await member.send(embed=embed)
            except: pass
        else: #нахуяяя #рофл ?
            if times.ishs(time1):
                time1 = times.string_to_seconds(time1)
                embed.description=f'''>>> **Пользователь замучен
Администратор: `{ctx.author}` ({ctx.author.mention}
Причина: `{reason}`
Пользователь: `{member}` ({member.mention})
Срок: `{times.hms(float(time1))}`**'''
                await ctx.edit_original_response(embed=embed)
                await mods.tempmute(ctx, member, time1)
                embed.description=f'''>>> **Ты был занесён в карантин на сервере `{ctx.guild.name}`
Администратор: `{ctx.author}` ({ctx.author.mention}
Причина: `{reason}`
Срок: `{times.hms(float(time1))}`**'''
                try: await member.send(embed=embed)
                except: pass
            else:
                await ctx.edit_original_response(embed=embed)
                await mods.mute(ctx, member)
                embed.description = f'''>>> **Ты был замучен в карантин на сервере `{ctx.guild.name}`
Администратор: `{ctx.author}` ({ctx.author.mention}
Причина: `{reason}`**'''
                try: await member.send(embed=embed)
                except: pass

    @commands.slash_command(description='Размутить пользователя')
    @commands.check(adms.has_mute_members)
    @commands.cooldown(1, 30, commands.BucketType.guild)
    async def unmute(self, ctx: disnake.AppCmdInter, member: disnake.Member=None):
        if member == None:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты не упомянул пользователя которого хочешь убрать из карантина**', color=config.error_color))
        if not isinstance(member, disnake.Member):
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты упомянул не пользователя**', color=config.error_color))
        if member == ctx.author:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Нельзя размутить самого себя**', color=config.error_color))
        if self.cur.execute("SELECT * FROM mutes WHERE guild_id = {} AND user_id = {}".format(ctx.guild.id, member.id)).fetchone() == None and self.cur.execute("SELECT * FROM timemutes WHERE guild_id = {} AND user_id = {}".format(ctx.guild.id, member.id)).fetchone() == None:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Пользователь не замучен**', color=config.error_color))
        await ctx.send(
            embed=disnake.Embed(
                title='<:5381637:1032635392266076181> | Мут',
                description=f'>>> **Пользователь `{member}` ({member.mention}) размучен**',
                color=config.error_color
            )
        )
        self.cur.execute("DELETE FROM mutes WHERE user_id = {} AND guild_id = {}".format(member.id, ctx.guild.id))
        self.db.commit()
        self.cur.execute("DELETE FROM timemutes WHERE user_id = {} AND guild_id = {}".format(member.id, ctx.guild.id))
        self.db.commit()
        quarole = self.cur.execute("SELECT role_id FROM muteroles WHERE guild_id = {}".format(ctx.guild.id)).fetchone()
        if quarole != None:
            quarole = ctx.guild.get_role(quarole[0])
        try:
            await member.remove_roles(quarole)
        except: pass
        
    @commands.slash_command(description='Разбанить участника')
    @commands.check(adms.has_ban_members)
    @commands.cooldown(1, 45, commands.BucketType.guild)
    async def unban(self, ctx, user: disnake.User=None, reason='Не указана'):
        # await ctx.response.defer()
        if user == None:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты не упомянул пользователя которого хочешь разбанить**', color=config.error_color))
        if not isinstance(user, disnake.User):
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Ты упомянул не пользователя**', color=config.error_color))
        if user.id == ctx.author.id:
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Нельзя разбанить самого себя**', color=config.error_color))
        if ctx.guild.get_member(user.id):
            return await ctx.send(embed=disnake.Embed(title='<:1828774:1025858045873487922> | Ошибка..', description='>>> **Пользователь есть на сервере**', color=config.error_color))
        await ctx.guild.unban(user, reason=reason)
        await ctx.send(
            embed=disnake.Embed(
                title='<:483326:1030579742174355597> | Успешно',
                description=f'>>> **Пользователь {user} разбанен**',
                color=config.success_color
            )
        )
        self.cur.execute("DELETE FROM timebans WHERE user_id = {} AND guild_id = {}".format(user.id, ctx.guild.id))
        self.db.commit()

    @commands.user_command(name='Список предупреждений')
    async def warnlistuser(self, ctx, user: typing.Union[disnake.User, disnake.Member]):
        await self.warnlist(ctx, user)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        if self.cur.execute("SELECT * FROM mutes WHERE guild_id = {} AND user_id = {}".format(member.guild.id, member.id)).fetchone() != None or self.cur.execute("SELECT * FROM mutes WHERE guild_id = {} AND user_id = {}".format(member.guild.id, member.id)).fetchone() != None:
            quarole = self.cur.execute("SELECT role_id FROM muteroles WHERE guild_id = {}".format(member.guild.id)).fetchone()
            if quarole != None:
                quarole = member.get_role(quarole[0])
                try:
                    await member.add_roles(quarole)
                except: pass

    
def setup(bot):
    bot.add_cog(Mod(bot))