import sqlite3
import disnake
from disnake.ext import commands
import io
import contextlib
import textwrap
import os
import aiohttp
import pyshorteners
import requests
import random
import asyncio
import time
import datetime
from datetime import datetime as dt
import typing
from colorama import Fore, init
from memory_profiler import memory_usage

init()

import database
import config

class Info(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db = sqlite3.connect('data.db')
        self.cur = self.db.cursor()

    async def checkac(self, guild):
        #if self.cur.execute("SELECT * FROM anticrash WHERE guild_id = {}".format(guild.id)).fetchone() != None:
        #    return True
        #return False
        return len(self.cur.execute("SELECT * FROM anticrash WHERE guild_id = {}".format(guild.id)).fetchall())

    async def checkab(self, guild):
        if self.cur.execute("SELECT * FROM antibot WHERE guild_id = {}".format(guild.id)).fetchone() != None:
            return True
        return False

    @commands.slash_command(description="Инфо о эмодзи.")
    async def emojiinfo(self, ctx, emoji:disnake.Emoji):
        embed = disnake.Embed(title="<:471713:1025862037768765500> | Эмодзи", color=config.main_color)
        embed.add_field(name="Название", value=emoji.name)
        embed.add_field(name="ID", value=emoji.id)
        if emoji.animated == False:anim = "Нет <:1828774:1025858045873487922>"
        else:anim="Да <:483326:1030579742174355597>"
        embed.add_field(name="Анимированное ?", value=anim)
        embed.add_field(name="Создано", value=f"<t:{round(emoji.created_at.timestamp())}:f>")
        try:embed.add_field(name="Автор", value=emoji.user if emoji.user else "<:471715:1025863185921749052> Не определён")
        except:embed.add_field(name="Автор", value="<:471715:1025863185921749052> Не определён")
        embed.add_field(name="URL", value=f"[Скачать]({emoji.url})")
        await ctx.send(embed=embed)
    
    @commands.slash_command(description='Инфо о сервере')
    async def serverinfo(self, ctx):
        link = await ctx.guild.channels[0].create_invite()
        rgs = {
            'brazil':':flag_br: Бразилия',
            'europe':':flag_eu: Европа',
            'hongkong':':flag_hk: Гонконг',
            'india':':flag_in: Индия',
            'japan':':flag_jp: Япония',
            'russia':':flag_ru: Россия',
            'singapore':':flag_sg: Сингапур',
            'southafrica':':flag_za: ЮАР',
            'sydney':':flag_au: Сидней',
            'us-central':':flag_us: Центральная Америка',
            'us-east':':flag_us: Восточное побережье США',
            'us-south':':flag_us: Америка (Юг)',
            'us-west':':flag_us: Западное побережье США',
            'deprecated':'Убран'
        }
        vlevels = {
            'none':'Отсутствует',
            'low':'Низкий',
            'medium':'Средний',
            'high':'Высокий',
            'extreme':'Самый высокий',
            'highest': 'Наивысший'
        }
        embed = disnake.Embed(
            title='<:471713:1025862037768765500> | Инфо о сервере',
            color=config.main_color
        )
        embed.add_field(
            name='Основная информация',
            value=f""">>> **├ <:471713:1025862037768765500> × Название сервера: `{ctx.guild.name}`
├ <:link:1025858087841706016> × Ссылка приглашения: [клик](https://discord.gg/{link.code})
├ <:link:1025858087841706016> × Создано приглашений: `{len(await ctx.guild.invites())}`
├ <:id:1025858085216063539> × ID Сервера: `{ctx.guild.id}`
├ <:asteroid:1025858072041758843> × ID Шарда этого сервера: `{ctx.guild.shard_id}`
├ <:87932:1025857391398498384> × Уровень верфикации: `{vlevels[str(ctx.guild.verification_level)]}`
├ <:2958792:1025858054555701298> × Регион: `{rgs.get(str(ctx.guild.region)) if rgs.get(str(ctx.guild.region)) else str(ctx.guild.region)}`
├ <:57113:1025857322511241246> × Владелец сервера: `{ctx.guild.owner if ctx.guild.owner else "Нету"}`
└ <:clock:1025858074927448204> × Дата и время создания сервера: `{ctx.guild.created_at.day}.{ctx.guild.created_at.month}.{ctx.guild.created_at.year}, {ctx.guild.created_at.hour}:{ctx.guild.created_at.minute}`**"""
        )
        embed.add_field(
            name='Каналы',
            value=f'''>>> **├ <:29302:1025857269977583756> × Всего: `{len(ctx.guild.channels)}`
├ <:566718:1025857577109684306> × Текстовых: `{len(ctx.guild.text_channels)}`
├ <:2258918:1025858051091222539> × Голосовых: `{len(ctx.guild.voice_channels)}`
└ <:861317:1025857931700359168> × Категорий: `{len(ctx.guild.categories)}`**'''
        )
        embed.add_field(
            name='Роли',
            value=f'''>>> **├ <:29302:1025857269977583756> × Всего: `{len(ctx.guild.roles)}`
├ <:5632549:1025858065595117648> × правами администратора: `{len([r for r in ctx.guild.roles if r.permissions.administrator])}`
├ <:483408:1026034137829752832> × правами модератора: `{len([r for r in ctx.guild.roles if r.permissions.kick_members])}`
└ <:7167276:1025858070070435861> × Интеграций: `{len([r for r in ctx.guild.roles if r.managed])}`**'''
        )
        embed.add_field(
            name='Участники',
            value=f'''>>> **├ <:681494:1025857658051367034> × Всего: `{ctx.guild.member_count}`
├ <:681494:1025857658051367034> × Людей: `{len([m for m in ctx.guild.members if not m.bot])}`
├ <:5632549:1025858065595117648> × С правами администратора: `{len([m for m in ctx.guild.members if m.guild_permissions.administrator])}`
├ <:359940:1025857533321150517> × С правами 'Ban members': `{len([m for m in ctx.guild.members if m.guild_permissions.ban_members])}`
├ <:359940:1025857533321150517> × С правами 'kick members': `{len([m for m in ctx.guild.members if m.guild_permissions.kick_members])}`
└ <:7167276:1025858070070435861> × Ботов: `{len([m for m in ctx.guild.members if m.bot])}`**'''
        )
        embed.add_field(
            name='Настройки',
            value=f'''>>> **├ <:786346:1025857731212627998> × Анти-краш: `{await self.checkac(ctx.guild)}` запрещённых действий
└ <:7167276:1025858070070435861> × Анти-бот: {"`Включен` <:483326:1030579742174355597>" if await self.checkab(ctx.guild) else "`Выключен` <:1828774:1025858045873487922>"}**'''
        )
        await ctx.send(embed=embed)

    @commands.slash_command(description='Инфо о боте')
    async def info(self, ctx):
        await ctx.response.defer()
        sysinf = f'''>>> **├ <:pingpong:1025858090131800227> × Пинг бота: `{self.bot.latency * 1000:.0f} ms`
├ <:asteroid:1025858072041758843> × Шардов: `{len(self.bot.shards)}`
└ <:597351:1030562707176431688> × Потрачено памяти: `{round(memory_usage()[0], 2)} мб`**'''
        statsinf = f'''>>> **├ <:gear:1025858080803651665> × Серверов: `{len(self.bot.guilds)}`
├ <:1161041:1025857978076774510> × Маленьких серверов (от 30+ уч.): `{len([g for g in self.bot.guilds if len(g.members) >= 30])}`
├ <:3180223:1030569549218717836> × Средних серверов (от 100+ уч.): `{len([g for g in self.bot.guilds if len(g.members) >= 100])}`
├ <:795323:1030562795646894130> × Больших серверов (от 1000+ уч.): `{len([g for g in self.bot.guilds if len(g.members) >= 1000])}`
└ <:681494:1025857658051367034> × Пользователей: `{len([m for g in self.bot.guilds for m in g.members])}`**'''
        otherinf = f'''>>> **├ <:python:1025858092765822998> × Библиотека: `disnake, Python`
├ <:database:1025866585644204122> × База данных: `sqlite3`
├ <:6872721:1030573183868338306> × Версия бота: `{config.version}`
├ <:2838764:1030573247961518141> × Дата создания бота: `{self.bot.user.created_at.day}.{self.bot.user.created_at.month}.{self.bot.user.created_at.year}`
└ <:3242244:1025858058087305307> × Разработчик бота: `!    ɴᴇᴇsssɢᴢˣᶻ#7576`, `DarkBlade#4759`**'''
        links2 = f'''**<:link:1025858087841706016> [Добавить бота](https://discord.com/api/oauth2/authorize?client_id={self.bot.user.id}&permissions=8&scope=bot%20applications.commands)
<:link:1025858087841706016> [Сервер поддержки](https://discord.gg/{config.support_server})**'''
        thanks = '''**DarkBlade#4759 - за помощь в обновлении бота**'''
        embed=disnake.Embed(title='<:471713:1025862037768765500> | Инфо о боте', color=config.main_color)
        embed.add_field(name='Основная информация', value=sysinf, inline=True)
        embed.add_field(name='Статистика бота', value=statsinf, inline=True)
        embed.add_field(name='Прочее', value=otherinf)
        embed.add_field(name='Благодарности', value=thanks)
        embed.add_field(name='Полезные ссылки', value=links2, inline=True)
        await ctx.send(embed=embed)

    @commands.slash_command(description='Пинг бота')
    async def ping(self, ctx):
        embed = disnake.Embed(title="<:pingpong:1025858090131800227> | Пинг бота", description=f'>>> **Средняя задержка: `{int(self.bot.latency * 1000)} милесекунд(ы)`**', color=config.main_color)
        shardsinf = '>>> '
        for shard in self.bot.shards:
            shardsinf += f'**Шард {shard}: `{int(self.bot.get_shard(shard).latency) * 1000} милесекунд(ы)`**\n'
        embed.add_field(inline=False, name="По шардам", value=shardsinf)
        #embed.set_footer(text=f'ID вашего шарда: {ctx.guild.shard_id}')
        await ctx.send(embed=embed)

    @commands.slash_command(description='Оперативная память')
    async def ram(self, ctx):
        embed = disnake.Embed(title="<:18471:1030584720943226913> | Ram", description=f">>> **<:597351:1030562707176431688> × Потрачено памяти: `{round(memory_usage()[0], 2)} мб`**", colour=config.main_color)
        await ctx.send(embed=embed)

    @commands.slash_command(description='Инфо о пользователе')
    @commands.cooldown(1, 10, commands.BucketType.guild)
    async def user(self, ctx, user: disnake.User = None):
        months = {
            1: "января",
            2: "февраля",
            3: "марта",
            4: "апреля",
            5: "мая",
            6: "июня",
            7: "июля",
            8: "августа",
            9: "сентября",
            10: "октября",
            11: "ноября",
            12: "декабря"
        }
        if user is None:
            user = ctx.author
        embed = disnake.Embed(color=config.main_color)
        if user.bot:
            embed.title = f"<:7167276:1025858070070435861> | Информация о боте **{user}**"
        else:
            embed.title = f"<:user:1025858103075405844> | Информация о пользователе **{user}**"
        #print(user.avatar)
        embed.set_thumbnail(url=user.avatar)
        embed.set_footer(text=f'ID: {user.id}')
        if ctx.guild.get_member(user.id):
            user = ctx.guild.get_member(user.id)
            embed.add_field(inline=False, name="Роли", value=f'Всего: **{len(user.roles)}**, наивысшая: {user.top_role.mention}')
            if user == ctx.guild.owner:
                embed.add_field(inline=True, name="Владелец сервера?", value='Да <:483326:1030579742174355597>')
            else:
                embed.add_field(inline=True, name="Владелец сервера?", value='Нет <:1828774:1025858045873487922>')
                if user.guild_permissions.administrator:
                    embed.add_field(inline=True, name="Администратор?", value='Да <:483326:1030579742174355597>')
                else:
                    embed.add_field(inline=True, name="Администратор?", value='Нет <:1828774:1025858045873487922>')
            ja = user.joined_at.replace(tzinfo=datetime.timezone.utc).astimezone(tz=None)
            embed.add_field(inline=False, name="Дата присоединения к серверу", value=f'<t:{int(ja.timestamp())}> (<t:{int(ja.timestamp())}:R>)')
        ca = user.created_at
        embed.add_field(inline=False, name="Дата создания аккаунта", value=f'<t:{int(ca.timestamp())}> (<t:{int(ca.timestamp())}:R>)')
        await ctx.send(embed=embed)

    @commands.user_command(name="Аватарка пользователя")  # optional
    async def avataruser(self, inter: disnake.ApplicationCommandInteraction, user: disnake.User):
        emb = disnake.Embed(title=f"Аватарка {user}", color=config.main_color)
        emb.set_image(url=user.display_avatar.url)
        await inter.response.send_message(embed=emb)


    @commands.user_command(name="Инфо о пользователе")  # optional
    async def infouser(self, inter: disnake.ApplicationCommandInteraction, user: disnake.User):
        embed = disnake.Embed(color=config.main_color)
        if user.bot:
            embed.title = f"<:7167276:1025858070070435861> | Информация о боте **{user}**"
        else:
            embed.title = f"<:user:1025858103075405844> | Информация о пользователе **{user}**"
        embed.set_thumbnail(url=user.avatar)
        embed.set_footer(text=f'ID: {user.id}')
        if inter.guild.get_member(user.id):
            user = inter.guild.get_member(user.id)
            embed.add_field(inline=False, name="Роли", value=f'Всего: **{len(user.roles)}**, наивысшая: {user.top_role.mention}')
            if user == inter.guild.owner:
                embed.add_field(inline=True, name="Владелец сервера?", value='Да <:483326:1030579742174355597>')
            else:
                embed.add_field(inline=True, name="Владелец сервера?", value='Нет <:1828774:1025858045873487922>')
                if user.guild_permissions.administrator:
                    embed.add_field(inline=True, name="Администратор?", value='Да <:483326:1030579742174355597>')
                else:
                    embed.add_field(inline=True, name="Администратор?", value='Нет <:1828774:1025858045873487922>')
            ja = user.joined_at.replace(tzinfo=datetime.timezone.utc).astimezone(tz=None)
            embed.add_field(inline=False, name="Дата присоединения к серверу", value=f'<t:{int(ja.timestamp())}> (<t:{int(ja.timestamp())}:R>)')
        ca = user.created_at
        embed.add_field(inline=False, name="Дата создания аккаунта", value=f'<t:{int(ca.timestamp())}> (<t:{int(ca.timestamp())}:R>)')
        await inter.send(embed=embed)

def setup(bot):
    bot.add_cog(Info(bot))