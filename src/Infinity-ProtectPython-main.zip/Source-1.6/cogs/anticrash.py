import sqlite3
import disnake
from disnake.ext import commands
import io
import contextlib
import textwrap
import os
import aiohttp
import requests
import random
import asyncio
import time
import datetime
from datetime import datetime as dt
import typing
from colorama import Fore, init

init()

import database
import config


class Anticrash(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db = sqlite3.connect('data.db')
        self.cur = self.db.cursor()

    async def checkwl(self, guild, euser, action):
        if euser == guild.owner:
            return True
        if euser == guild.me:
            return True
        if euser.public_flags.verified_bot:
            return True
        if euser in config.default_wl:
            return True
        if self.cur.execute("SELECT * FROM whitelist WHERE guild_id = {} AND user_id = {} AND action = '{}'".format(guild.id, euser.id, action)).fetchone() != None:
            #print(self.cur.execute("SELECT * FROM whitelist WHERE guild_id = {} AND user_id = {} AND action = '{}'".format(guild.id, euser.id, action)).fetchone())
            return True
        return False

    async def checkac(self, guild, action):
        if self.cur.execute("SELECT * FROM anticrash WHERE guild_id = {} AND action = '{}'".format(guild.id, action)).fetchone() != None:
            return True
        return False

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        if await self.checkac(channel.guild, 'delete_channels') == True:
            async for entry in channel.guild.audit_logs(limit=1, action=disnake.AuditLogAction.channel_delete):
                if await self.checkwl(channel.guild, entry.user, 'delete_channels') == False:
                    try:
                        await entry.user.kick(reason='Попытка краша | Удаление каналов')
                    except: pass
                    if isinstance(channel, disnake.TextChannel):
                        if channel.category == None:
                            try: await channel.guild.create_text_channel(
                                name=channel.name,
                                topic=channel.topic,
                                position=channel.position,
                                nsfw=channel.nsfw,
                                slowmode_delay=channel.slowmode_delay,
                                overwrites=channel.overwrites
                            )
                            except: pass
                        else:
                            try: await channel.guild.create_text_channel(
                                name=channel.name,
                                topic=channel.topic,
                                position=channel.position,
                                nsfw=channel.nsfw,
                                slowmode_delay=channel.slowmode_delay,
                                overwrites=channel.overwrites,
                                category=disnake.utils.get(channel.guild.categories, name=channel.category.name)
                            )
                            except: pass
                    if isinstance(channel, disnake.VoiceChannel):
                        if channel.category == None:
                            try: await channel.guild.create_voice_channel(
                                name=channel.name,
                                position=channel.position,
                                overwrites=channel.overwrites
                            )
                            except: pass
                        else:
                            try: await channel.guild.create_voice_channel(
                                name=channel.name,
                                position=channel.position,
                                overwrites=channel.overwrites,
                                category=disnake.utils.get(channel.guild.categories, name=channel.category.name)
                            )
                            except: pass
                    if isinstance(channel, disnake.CategoryChannel):
                        try: await channel.guild.create_category(
                            name=channel.name,
                            position=channel.position,
                            overwrites=channel.overwrites
                        )
                        except: pass

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        if await self.checkac(role.guild, 'delete_roles') == True and not role.managed:
            async for entry in role.guild.audit_logs(limit=1, action=disnake.AuditLogAction.role_delete):
                if await self.checkwl(role.guild, entry.user, 'delete_roles') == False:
                    try:
                        await entry.user.kick(reason='Попытка краша | Удаление ролей')
                    except: pass
                    try: 
                        rolee2 = await role.guild.create_role(
                            name=role.name,
                            color=role.color,
                            hoist=role.hoist,
                            mentionable=role.mentionable,
                            permissions=role.permissions
                        )
                        await rolee2.edit(position=role.position)
                    except: pass

    @commands.Cog.listener()
    async def on_guild_update(self, before, after):
        if await self.checkac(after, 'update_server') == True:
            if after.name != before.name:
                async for entry in after.audit_logs(limit=1, action=disnake.AuditLogAction.guild_update):
                    if await self.checkwl(after, entry.user, 'update_server') == False:
                        try:
                            await entry.user.kick(reason='Попытка краша | Изменение названия сервера')
                        except: pass
                        try: await after.edit(name=before.name)
                        except: pass
            if after.icon  != before.icon:
                async for entry in after.audit_logs(limit=1, action=disnake.AuditLogAction.guild_update):
                    if await self.checkwl(after, entry.user, 'update_server') == False:
                        try:
                            await entry.user.kick(reason='Попытка краша | Изменение аватарки сервера')
                        except: pass
                
    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        if await self.checkac(channel.guild, 'create_channels') == True:
            async for entry in channel.guild.audit_logs(limit=1, action=disnake.AuditLogAction.channel_create):
                if await self.checkwl(channel.guild, entry.user, 'create_channels') == False:
                    try:
                        await entry.user.kick(reason='Попытка краша сервера | Создание каналов')
                    except: pass
                    try: await channel.delete()
                    except: pass
        
    @commands.Cog.listener()
    async def on_guild_role_create(self, role):
        if await self.checkac(role.guild, 'create_roles') == True and not role.managed:
            async for entry in role.guild.audit_logs(limit=1, action=disnake.AuditLogAction.role_create):
                if await self.checkwl(role.guild, entry.user, 'create_roles') == False:
                    try:
                        await entry.user.kick(reason='Попытка краша сервера | Создание ролей')
                    except: pass
                    try: await role.delete()
                    except: pass

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        guild = member.guild
        async for entry in guild.audit_logs(limit=1):
            if entry.action == disnake.AuditLogAction.kick:
                if await self.checkac(guild, 'kick_members') == True:
                    if await self.checkwl(guild, entry.user, 'kick_membes') == False:
                        try:
                            await entry.user.kick(reason='Попытка краша сервера | Создание ролей')
                        except: pass

    @commands.Cog.listener()
    async def on_member_ban(self, guild, member):
        if await self.checkac(guild, 'ban_members') == True:
            async for entry in guild.audit_logs(limit=1, action=disnake.AuditLogAction.ban):
                if await self.checkwl(guild, entry.user, 'ban_members') == False:
                    try:
                        await member.kick(reason='Попытка краша | бан участников')
                    except: pass
                    try: await member.unban()
                    except: pass

    @commands.Cog.listener()
    async def on_guild_channel_update(self, before, after):
        if await self.checkac(after.guild, 'update_channels') == True:
            if after.name != before.name:
                async for entry in after.guild.audit_logs(limit=1, action=disnake.AuditLogAction.channel_update):
                    if await self.checkwl(after.guild, entry.user, 'update_channels') == False:
                        try:
                            await entry.user.kick(reason='Попытка краша | Изменение каналов')
                        except: pass
                        if isinstance(after, disnake.TextChannel):
                            try: await after.edit(
                                name=before.name,
                                topic=before.topic,
                                nsfw=before.nsfw,
                                slowmode_delay=before.slowmode_delay
                            )
                            except: pass
                        else:
                            try: await after.edit(
                                name=before.name
                            )
                            except: pass
    
    @commands.Cog.listener()
    async def on_guild_role_update(self, before, after):
        if await self.checkac(after.guild, 'update_roles') == True:
            if after.name != before.name or after.permissions != before.permissions:
                async for entry in after.guild.audit_logs(limit=1, action=disnake.AuditLogAction.role_update):
                    if await self.checkwl(after.guild, entry.user, 'update_roles') == False:
                        try:
                            await entry.user.kick(reason='Попытка краша | Изменение ролей')
                        except: pass
                        try: await after.edit(
                            name=before.name,
                            color=before.color,
                            position=before.position,
                            permissions=before.permissions
                        )
                        except: pass

    @commands.Cog.listener()
    async def on_webhooks_update(self, channel):
        if await self.checkac(channel.guild, 'create_webhooks') == True:
            async for entry in channel.guild.audit_logs(limit=1, action=disnake.AuditLogAction.webhook_create):
                if await self.checkwl(channel.guild, entry.user, 'create_webhooks') == False:
                    try:
                        await entry.user.kick(reason='Попытка краша сервера | Создание вебхуков')
                    except: pass
                    for webhook in await channel.webhooks():
                        if webhook.id == entry.target.id:
                            try: await webhook.delete()
                            except: pass

    @commands.Cog.listener()
    async def on_member_join(self, member):
        if self.cur.execute("SELECT * FROM antibot WHERE guild_id = {}".format(member.guild.id)).fetchone() != None:
            if member.bot and not member.public_flags.verified_bot and member != member.guild.me:
                async for entry in member.guild.audit_logs(limit=1, action=disnake.AuditLogAction.bot_add):
                    if await self.checkwl(member.guild, entry.user, 'add_bots') == False:
                        try: await entry.user.kick(reason='Попытка краша | Добавил не верифицированного бота')
                        except: pass
                        try: await member.kick(reason='Не верифицированный бот')
                        except: pass


def setup(bot):
    bot.add_cog(Anticrash(bot))